using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak
{
	//public class PInfo : 
    //{ }
	public class MProjectile : GlobalProjectile 
	{
		//public override void AI(Projectile projectile)
		//{
		//	PInfo i = (PInfo)projectile.GetModInfo(mod, "PInfo");
		//}
	}
}