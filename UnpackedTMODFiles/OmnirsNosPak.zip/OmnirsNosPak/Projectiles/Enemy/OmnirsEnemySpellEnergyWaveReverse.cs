using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemySpellEnergyWaveReverse : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Energy Wave");
		}
		public override void SetDefaults()
		{
			projectile.width = 100;
			projectile.height = 70;
			projectile.penetrate = 50;
			projectile.timeLeft = 360;
			//projectile.alpha = 100;
			projectile.light = 1f;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.magic = true;
			projectile.ignoreWater = true;
			projectile.tileCollide = false;
			Main.projFrames[projectile.type] = 17;
		}
		public override void AI() 
		{
			projectile.frameCounter++;
			if (projectile.frameCounter > 2)
			{
				projectile.frame++;
				projectile.frameCounter = 0;
			}
			if (projectile.frame >= 17)
			{
				projectile.Kill();
				return;
			}
		}
	}
}