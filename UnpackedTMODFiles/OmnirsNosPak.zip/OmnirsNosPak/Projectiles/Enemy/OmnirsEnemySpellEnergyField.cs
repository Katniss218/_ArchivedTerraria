using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
    public class OmnirsEnemySpellEnergyField : ModProjectile
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Energy Field");
		}
        public override void SetDefaults()
        {
            projectile.width = 40;
            projectile.height = 40;
            projectile.penetrate = 50;
            projectile.timeLeft = 360;
            projectile.alpha = 100;
            projectile.light = 1f;
            projectile.friendly = false;
            projectile.hostile = true;
            projectile.magic = true;
            projectile.ignoreWater = true;
            projectile.tileCollide = false;
            Main.projFrames[projectile.type] = 12;
        }
        public override void AI()
        {
            projectile.frameCounter++;

            if (projectile.frameCounter > 4)
            {
                //Main.NewText("Testframe.", 175, 75, 255);
                projectile.frame++;
                projectile.frameCounter = 0;
            }
            if (projectile.frame >= 12)
            {
                projectile.frame = 0;
                return;
            }
            if (projectile.timeLeft > 360)
            {
                projectile.timeLeft = 360;
            }
            return;
        }
    }
}