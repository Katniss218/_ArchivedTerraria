using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemySpellFire3Flame1 : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Fire 3");
		}
		public override void SetDefaults()
		{
			projectile.width = 62;
			projectile.height = 62;
			projectile.penetrate = 8;
			projectile.timeLeft = 75;
			//projectile.alpha = 100;
			projectile.light = 1f;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.magic = true;
			projectile.ignoreWater = true;
			projectile.tileCollide = false;
			Main.projFrames[projectile.type] = 3;
		}
        public override void AI()
        {
            projectile.frameCounter++;

            if (projectile.frameCounter > 4)
            {
                projectile.frame++;
                projectile.frameCounter = 0;
            }
            if (projectile.frame >= 3)
            {
                projectile.frame = 0;
                return;
            }
            return;
        }
    }
}