using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemySpellDoomStrike : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Doom");
		}
		public override void SetDefaults()
		{
			projectile.width = 60;
			projectile.height = 60;
			projectile.penetrate = 50;
			projectile.knockBack = 9;
			//projectile.timeLeft = 200;
			//projectile.alpha = 100;
			projectile.light = 1f;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.magic = true;
			projectile.ignoreWater = true;
			projectile.tileCollide = false;
			Main.projFrames[projectile.type] = 10;
		}
        #region AI
        public override void AI()
        {
            Lighting.AddLight(projectile.Center, 1f, 1f, 1f);
            Rectangle projrec = new Rectangle((int)projectile.position.X + (int)projectile.velocity.X, (int)projectile.position.Y + (int)projectile.velocity.Y, projectile.width, projectile.height);
            Rectangle prec = new Rectangle((int)Main.player[Main.myPlayer].position.X, (int)Main.player[Main.myPlayer].position.Y, (int)Main.player[Main.myPlayer].width, (int)Main.player[Main.myPlayer].height);
            if (projrec.Intersects(prec))
            {
                if (Main.player[Main.myPlayer].statLife < 100)
                {
                    Main.player[Main.myPlayer].statLife -= 100;
                    if (Main.player[Main.myPlayer].statLife < 0)
                    {
                        Main.player[Main.myPlayer].statLife = 0;
                        //Main.player[Main.myPlayer].KillMe(PlayerDeathReason.ByCustomReason("was instantly killed by the spell 'Doom'"), 10.0, 0, false);
                    }
                }
            }
            projectile.frameCounter++;

            if (projectile.frameCounter > 4)
            {
                //Main.NewText("Testframe.", 175, 75, 255);
                projectile.frame++;
                projectile.frameCounter = 0;
            }
            if (projectile.frame >= 10)
            {
                projectile.Kill();
                projectile.frame = 0;
                return;
            }
            if (projectile.timeLeft > 60)
            {
                projectile.timeLeft = 60;
            }
            return;

        }
    }
    #endregion
}
