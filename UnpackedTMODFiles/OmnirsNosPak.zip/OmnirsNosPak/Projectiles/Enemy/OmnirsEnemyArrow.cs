using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemyArrow : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Arrow");
		}
		public override void SetDefaults()
		{
			projectile.width = 5;
			projectile.height = 14;
			//projectile.damage = 20;
			projectile.penetrate = 3;
			//projectile.light = 1f;
			projectile.timeLeft=3000;
			projectile.aiStyle = 1;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.ranged = true;
			projectile.tileCollide = true;
            projectile.scale = 0.8f;
		}
	}
}