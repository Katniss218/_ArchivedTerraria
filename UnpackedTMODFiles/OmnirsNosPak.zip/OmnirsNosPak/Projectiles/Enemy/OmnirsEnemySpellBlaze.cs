using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemySpellBlaze : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Blaze");
		}
		public override void SetDefaults()
		{
			projectile.width = 86;
			projectile.height = 66;
			projectile.penetrate = 50;
			projectile.knockBack = 9;
			projectile.timeLeft = 100;
			projectile.light = 1f;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.magic = true;
			projectile.ignoreWater = true;
			projectile.tileCollide = false;
			Main.projFrames[projectile.type] = 5;
		}
        #region AI
        public override void AI()
        {
            Lighting.AddLight(projectile.Center, 1f, 1f, 1f);
            projectile.frameCounter++;

            if (projectile.frameCounter > 4)
            {
                //Main.NewText("Testframe.", 175, 75, 255);
                projectile.frame++;
                projectile.frameCounter = 0;
            }
            if (projectile.frame >= 5)
            {
                projectile.Kill();
                projectile.frame = 0;
                return;
            }
            if (projectile.timeLeft > 60)
            {
                projectile.timeLeft = 60;
            }
            projectile.rotation += 0.3f * (float)projectile.direction;
            return;
        }
    }
    #endregion
}