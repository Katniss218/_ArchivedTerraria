using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemySpellBubble : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Bubble");
		}
		public override void SetDefaults()
		{
			projectile.width = 20;
			projectile.height = 20;
			//projectile.damage = 100;
			projectile.penetrate = 2;
			projectile.light = 1f;
			projectile.timeLeft= 300;
			projectile.aiStyle = 12;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.magic = true;
			projectile.tileCollide = false;
            projectile.alpha = 150;
		}
	}
}