using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemySpellArmageddon : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Armageddon");
		}
		public override void SetDefaults()
		{
			projectile.width = 240;
			projectile.height = 240;
			projectile.penetrate = 50;
			projectile.knockBack = 9;
			//projectile.timeLeft = 200;
			projectile.light = 1f;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.magic = true;
			projectile.ignoreWater = true;
			projectile.tileCollide = false;
			Main.projFrames[projectile.type] = 8;
		}
		public override void AI() 
		{
			projectile.frameCounter++;
			if (projectile.frameCounter > 3)
			{
				projectile.frame++;
				projectile.frameCounter = 0;
			}
			if (projectile.frame >= 8)
			{
				projectile.Kill();
				return;
			}
		}
	}
}