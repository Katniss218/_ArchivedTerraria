using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemySpear : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Spear");
		}
		public override void SetDefaults()
		{
			projectile.width = 14;
			projectile.height = 14;
			//projectile.damage = 20;
			projectile.penetrate = 1;
			//projectile.light = 1f;
			projectile.timeLeft=3000;
			projectile.aiStyle = 2;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.ranged = true;
			projectile.tileCollide = true;
            projectile.scale = 0.8f;
		}
	}
}