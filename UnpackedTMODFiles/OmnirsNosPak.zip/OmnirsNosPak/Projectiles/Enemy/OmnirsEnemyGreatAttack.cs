using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemyGreatAttack : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Great Attack");
		}
		public override void SetDefaults()
		{
			projectile.width = 60;
			projectile.height = 34;
			projectile.knockBack = 9;
			projectile.penetrate = 4;
			projectile.alpha = 100;
			projectile.light = 1.4f;
			projectile.timeLeft=10;
			projectile.aiStyle = 1;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.melee = true;
			projectile.tileCollide = false;
		}
	}
}