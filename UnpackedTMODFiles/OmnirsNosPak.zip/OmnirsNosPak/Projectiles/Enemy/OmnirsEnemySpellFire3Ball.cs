using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemySpellFire3Ball : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Fire 3");
		}
		public override void SetDefaults()
		{
			projectile.width = 16;
			projectile.height = 16;
			projectile.knockBack = 9;
			projectile.penetrate = 8;
			projectile.light = 1f;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.magic = true;
			projectile.tileCollide = true;
		}
		public override void Kill(int timeLeft) 
		{
			if (!projectile.active)
			{
				return;
			}
            projectile.timeLeft = 0;
            {
                int proj1 = Projectile.NewProjectile(projectile.position.X + (float)(projectile.width / 2), projectile.position.Y + (float)(projectile.height - 15), 3, 0, mod.ProjectileType("OmnirsEnemySpellFire3Flame1"), 45, 3f, projectile.owner);
                Main.projectile[proj1].friendly = projectile.friendly;
                Main.projectile[proj1].hostile = projectile.hostile;
                int proj2 = Projectile.NewProjectile(projectile.position.X + (float)(projectile.width / 2), projectile.position.Y + (float)(projectile.height - 15), -3, 0, mod.ProjectileType("OmnirsEnemySpellFire3Flame2"), 45, 3f, projectile.owner);
                Main.projectile[proj2].friendly = projectile.friendly;
                Main.projectile[proj2].hostile = projectile.hostile;
                Main.PlaySound(2, (int)projectile.position.X, (int)projectile.position.Y, 10);
            }
            projectile.active = false;
		}
	}
}