using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemySlipWind : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Slip Wind");
		}
		public override void SetDefaults()
		{
			projectile.width = 5;
			projectile.height = 5;
			projectile.knockBack = 9;
			projectile.penetrate = 4;
			projectile.alpha = 150;
			projectile.light = 0f;
			projectile.timeLeft= 10;
			projectile.aiStyle = 1;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.magic = true;
			projectile.tileCollide = false;
		}
	}
}