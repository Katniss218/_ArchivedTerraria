using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Projectiles.Enemy
{
	public class OmnirsEnemySpellFireBreath : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Fire Breath");
		}
		public override void SetDefaults()
		{
			projectile.width = 38;
			projectile.height = 36;
			projectile.damage = 100;
			projectile.penetrate = 10;
			projectile.light = 1f;
			projectile.timeLeft=3000;
			projectile.aiStyle = 23;
			projectile.friendly = false;
			projectile.hostile = true;
			projectile.magic = true;
			projectile.tileCollide = false;
		}
	}
}