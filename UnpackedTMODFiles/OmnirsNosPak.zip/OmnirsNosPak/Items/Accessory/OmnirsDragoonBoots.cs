using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	public class OmnirsDragoonBoots : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dragoon Boots");
			Tooltip.SetDefault("Steel Boots made for Dragoons. \nNo damage from falling. \nStomp enemies for damage based on fall height. \nPress z to toggle high jump.");
		}
		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 26;
			item.value = 150000;
			item.rare = 3;
			item.accessory = true;
		}
		private float fall = -1;
		private float fs = -1;
		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.noFallDmg = true;
			MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
			if(p.dJump)player.jumpSpeedBoost += 10f;
			p.stomp = 10;
		}
	}
}