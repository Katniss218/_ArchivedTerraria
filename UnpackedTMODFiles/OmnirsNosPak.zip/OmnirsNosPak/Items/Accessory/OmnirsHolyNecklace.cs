using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	[AutoloadEquip(EquipType.Neck)]
	public class OmnirsHolyNecklace : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Holy Necklace");
			Tooltip.SetDefault("Constantly emits a pale blue light.\nCauses stars to fall and increases length of invincibility after taking damage.");
		}
		public override void SetDefaults()
		{
			item.width = 24;
			item.height = 24;
			item.value = 200000;
			item.rare = 3;
			item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			Lighting.AddLight(player.Center, new Vector3(0.4f, 0.8f, 1f) * Main.essScale * 2);
		}
	}
}