using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	[AutoloadEquip(EquipType.Shield)]
	public class OmnirsAncientDemonShield : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Ancient Demon Shield");
			Tooltip.SetDefault("Grants immunity to knockback and returns 50% damage, but slows movement by 25%.");
		}
		public override void SetDefaults()
		{
			item.width = 28;
			item.height = 38;
			item.value = 10000;
			item.rare = 4;
			item.accessory = true;
			item.defense = 10;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.noKnockback = true;
			player.moveSpeed -= 0.25f;
			player.thorns = .5f;
		}

	}
}