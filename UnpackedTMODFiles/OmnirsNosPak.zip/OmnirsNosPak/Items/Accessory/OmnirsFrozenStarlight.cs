using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	public class OmnirsFrozenStarlight : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Frozen Starlight");
			Tooltip.SetDefault("Constantly emits a pale blue light.");
		}
		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 26;
			item.value = 50000;
			item.rare = 1;
			item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			Lighting.AddLight(player.Center, new Vector3(0.4f, 0.8f, 1f) * Main.essScale);
		}

	}
}