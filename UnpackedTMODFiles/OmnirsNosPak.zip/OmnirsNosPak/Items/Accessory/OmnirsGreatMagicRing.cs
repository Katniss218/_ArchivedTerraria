using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	[AutoloadEquip(EquipType.HandsOn)]
	public class OmnirsGreatMagicRing : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Ring of Power");
			Tooltip.SetDefault("A strange magic ring.\nWill summon Sauron.");
		}
		public override void SetDefaults()
		{
			item.width = 22;
			item.height = 22;
			item.value = 27000000;
			item.rare = 9;
			item.accessory = true;
            item.useAnimation = 45;
            item.useTime = 45;
            item.useStyle = 4;
            item.UseSound = SoundID.Item44;
            item.consumable = true;
        }

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.noKnockback = true;
			player.AddBuff(BuffID.Darkness, 500, false);
			player.AddBuff(BuffID.Battle, 500, false);
            //player.AddBuff(BuffID.Invisible, 500, false);
        }

        public override bool CanUseItem(Player player)
        {
            return !NPC.AnyNPCs(mod.NPCType("OmnirsSauron"));
        }

        public override bool UseItem(Player player)
        {
            NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType("OmnirsSauron"));
            Main.PlaySound(SoundID.Roar, player.position, 0);
            return true;
        }
    }
}