using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	public class OmnirsGoldHairpin : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Gold Hairpin");
			Tooltip.SetDefault("Solid gold hairpin brimming with magical energy.\nHalves the mana cost of all magic.");
		}
		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 26;
			item.value = 340000;
			item.rare = 4;
			item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.manaCost *= 0.50f;
		}
	}
}