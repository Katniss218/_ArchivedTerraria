using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	[AutoloadEquip(EquipType.HandsOn)]
	public class OmnirsRingofPower : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Ring of Power");
			Tooltip.SetDefault("A great ring of power gifted to men.\nBlinds user and draws in enemies.\nNo knockback, +50 percent critical chance.");
		}
		public override void SetDefaults()
		{
			item.width = 22;
			item.height = 22;
			item.value = 270000;
			item.rare = 5;
			item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.noKnockback = true;
			player.AddBuff(BuffID.Darkness, 500, false);
			player.AddBuff(BuffID.Battle, 500, false);
			player.rangedCrit += 50;
			player.meleeCrit += 50;
			player.magicCrit += 50;
		}
	}
}