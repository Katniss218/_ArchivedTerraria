using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	[AutoloadEquip(EquipType.HandsOn)]
	public class OmnirsMythrilGlove : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Mythril Glove");
			Tooltip.SetDefault("Lightweight glove made of mythril.\nCasts Protect when the wearer is critically wounded.(+50 Defense when life is below 25%).");
		}
		public override void SetDefaults()
		{
			item.width = 22;
			item.height = 22;
			item.value = 50000;
			item.rare = 4;
			item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			if (player.statLife <= (player.statLifeMax*0.25f))
			{
				MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
				bool buffed = false;
				for(int i = 0; i < 22; i++)
				{
					if (player.buffType[i] == mod.BuffType("OmnirsProtect"))
					{
						if ((player.buffTime[i] <= 2 && p.protect > 50) || p.protect <= 50)
						{
							p.protect = 50;
							player.AddBuff(mod.BuffType("OmnirsProtect"), 2, false);
						}
						buffed = true;
					}
				}
				if(!buffed)
				{
					p.protect = 50;
					player.AddBuff(mod.BuffType("OmnirsProtect"), 120, false);
				}
			}
		}
	}
}