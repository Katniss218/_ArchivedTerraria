using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	[AutoloadEquip(EquipType.HandsOn)]
	public class OmnirsBarrierRing : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Barrier Ring");
			Tooltip.SetDefault("Casts Barrier when wearer is critically wounded. \n+20 defense when below 25% life.");
		}
		public override void SetDefaults()
		{
			item.width = 28;
			item.height = 38;
			item.value = 7000;
			item.rare = 3;
			item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			if (player.statLife <= (player.statLifeMax*0.25f))
			{
				MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
				bool buffed = false;
				for(int i = 0; i < 22; i++)
				{
					if (player.buffType[i] == mod.BuffType("OmnirsProtect"))
					{
						if ((player.buffTime[i] <= 2 && p.protect > 20) || p.protect <= 20)
						{
							p.protect = 20;
							player.AddBuff(mod.BuffType("OmnirsProtect"), 2, false);
						}
						buffed = true;
					}
				}
				if(!buffed)
				{
					p.protect = 20;
					player.AddBuff(mod.BuffType("OmnirsProtect"), 120, false);
				}
			}
		}
	}
}