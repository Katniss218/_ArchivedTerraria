using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	[AutoloadEquip(EquipType.Shield)]
	public class OmnirsBeholderShield : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Beholder Shield");
			Tooltip.SetDefault("Grants immunity to knockback and +6% melee damage. \n Reduces ranged and magic damage by 150%. \n +70% mana cost -15% move speed.");
		}
		public override void SetDefaults()
		{
			item.width = 28;
			item.height = 38;
			item.value = 3000000;
			item.rare = 3;
			item.accessory = true;
			item.defense = 40;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.noKnockback = true;
			player.fireWalk=true;
			player.moveSpeed -= 0.15f;
			player.manaCost += 0.70f;
			player.magicDamage -= 1.5f;
			player.rangedDamage -= 1.5f;
			player.meleeDamage += 0.06f;
		}
	}
}