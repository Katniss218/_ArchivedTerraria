using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	public class OmnirsGemBox : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Gem Box");
			Tooltip.SetDefault("Ancient Thamasan orb enshrining a wondrous power housed within an ornate box.\nSpells are now dual-cast.");
		}
		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 26;
			item.value = 800000;
			item.rare = 5;
			item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
			p.dualCast = true;
		}
	}
}