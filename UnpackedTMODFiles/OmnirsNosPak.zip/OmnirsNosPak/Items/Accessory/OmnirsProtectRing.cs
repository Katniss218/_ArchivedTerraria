using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	[AutoloadEquip(EquipType.HandsOn)]
	public class OmnirsProtectRing : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Protect Ring");
			Tooltip.SetDefault("Ring that guards against death.\nCasts protect while worn (+30 Defense).");
		}
		public override void SetDefaults()
		{
			item.width = 22;
			item.height = 22;
			item.value = 75000;
			item.rare = 5;
			item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
			bool buffed = false;
			for(int i = 0; i < 22; i++)
			{
				if (player.buffType[i] == mod.BuffType("OmnirsProtect"))
				{
					if ((player.buffTime[i] <= 2 && p.protect > 30) || p.protect <= 30)
					{
						p.protect = 30;
						player.AddBuff(mod.BuffType("OmnirsProtect"), 2, false);
					}
					buffed = true;
				}
			}
			if(!buffed)
			{
				p.protect = 30;
				player.AddBuff(mod.BuffType("OmnirsProtect"), 120, false);
			}
		}
	
	}
}