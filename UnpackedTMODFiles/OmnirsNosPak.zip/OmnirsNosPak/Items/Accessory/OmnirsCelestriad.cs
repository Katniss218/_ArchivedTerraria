using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	public class OmnirsCelestriad : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Celestriad");
			Tooltip.SetDefault("Necklace with three star-shaped bangles on its chain.\nNegates mana usage.");
		}
		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 26;
			item.value = 20000000;
			item.rare = 5;
			item.accessory = true;
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.manaCost = -1f;
		}
	}
}