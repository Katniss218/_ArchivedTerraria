using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Accessory
{
	public class OmnirsDragonHorn : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dragon Horn");
			Tooltip.SetDefault("Horn inhabited by the spirit of a dragon. \n200% melee damage while falling.");
		}
		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 26;
			item.value = 250000;
			item.rare = 4;
			item.accessory = true;
		}
		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.noFallDmg = true;
			if (player.velocity.Y * player.gravDir > 0) player.meleeDamage *= 2;
		}
	}
}