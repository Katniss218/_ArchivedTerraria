using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Ammo
{
	public class OmnirsArrowofBard : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Arrow of Bard");
			Tooltip.SetDefault("The arrow which slew Smaug.");
		}
		public override void SetDefaults()
		{
			item.width = 10;
			item.height = 28;
			item.maxStack = 9999;
			item.damage = 500;
			item.knockBack = 4;
			item.useAnimation = 100;
			item.useTime = 100;
			item.rare = 3;
			item.value = 500000;
			item.consumable = true;
			item.ranged = true;
			item.ammo = 40;
			item.shoot = mod.ProjectileType("OmnirsArrowofBard");
			item.shootSpeed = 3.5f;
		}
	}
}