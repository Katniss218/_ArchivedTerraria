using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Vanity.FinalFantasy
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsEdgarBlackandGoldTop : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Black and Gold Top");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 5000;
            item.rare = 3;
        }


	}
}