using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Vanity.FinalFantasy
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsDarkKnightHelmet : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dark Knight's Helmet");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 550;
			item.rare = 3;
		}
    }
}