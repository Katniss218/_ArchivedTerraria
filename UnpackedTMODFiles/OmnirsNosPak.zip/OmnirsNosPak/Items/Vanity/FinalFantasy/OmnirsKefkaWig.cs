using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Vanity.FinalFantasy
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsKefkaWig : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Kefka's Wig");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 550;
			item.rare = 3;
		}
    }
}