using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Vanity.FinalFantasy
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsThiefPants : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Thief Pants");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 5000;
            item.rare = 3;
        }
    }
}