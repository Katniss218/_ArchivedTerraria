using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Vanity.FinalFantasy
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsBlackMageHatAlone : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Black Mage Hat(No Face)");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 550;
			item.rare = 3;
		}
    }
}