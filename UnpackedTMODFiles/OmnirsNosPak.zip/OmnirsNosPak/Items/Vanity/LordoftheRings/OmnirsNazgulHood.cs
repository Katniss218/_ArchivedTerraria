using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Vanity.LordoftheRings
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsNazgulHood : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Nazgul's Hood");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 550;
			item.rare = 3;
		}
    }
}