using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Crafting
{
	public class OmnirsWindCrystal : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Wind Crystal");
			Tooltip.SetDefault("The Crystal of Wind, revived. \nNeeded to summon Chaos");
		}
		public override void SetDefaults()
		{
			base.SetDefaults();
            item.maxStack = 999;
            item.rare = 7;
        }
	}
}