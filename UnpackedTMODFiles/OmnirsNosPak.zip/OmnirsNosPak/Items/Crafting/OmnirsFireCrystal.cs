using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Crafting
{
	public class OmnirsFireCrystal : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Fire Crystal");
			Tooltip.SetDefault("The Crystal of Fire, revived. \nNeeded to summon Chaos");
		}
		public override void SetDefaults()
		{
			base.SetDefaults();
            item.maxStack = 999;
            item.rare = 7;
        }
	}
}