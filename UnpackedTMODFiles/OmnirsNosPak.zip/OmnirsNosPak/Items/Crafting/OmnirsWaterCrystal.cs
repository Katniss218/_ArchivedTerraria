using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Crafting
{
	public class OmnirsWaterCrystal : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Water Crystal");
			Tooltip.SetDefault("The Crystal of Water, revived. \nNeeded to summon Chaos");
		}
		public override void SetDefaults()
		{
			base.SetDefaults();
            item.maxStack = 999;
            item.rare = 7;
        }
	}
}