using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Magic
{
	public class OmnirsBarrierTome : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Barrier Tome");
			Tooltip.SetDefault("A lost tome for artisans, adding 16 to defense for 10 seconds.");
		}
		public override void SetDefaults()
		{
			item.width = 34;
			item.height = 10;
			item.useTime = 10;
			item.useAnimation = 10;
			item.useStyle = 5;
            item.UseSound = SoundID.Item21;
            item.mana = 20;
			item.noMelee = true;
			item.magic = true;
			item.value = 42000;
			item.rare = 4;
			item.buffTime = 600;
			item.buffType = mod.BuffType("OmnirsBarrier");
		}
		//public override bool CanUseItem(Player player)
		//{
		//	MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
		//	for(int i = 0; i < 22; i++)
		//	{
		//		if (player.buffType[i] == mod.BuffType("OmnirsBarrier") && p.protect > 8) return false;
		//	}
		//	p.protect = 8;
		//	return true;
		//}
	}
}