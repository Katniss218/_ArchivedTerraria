using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Magic
{
	public class OmnirsEsunaTome : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Esuna Tome");
			Tooltip.SetDefault("A lost tome known to cure all but the rarest of ailments.");
		}
		public override void SetDefaults()
		{
			item.width = 34;
			item.height = 10;
			item.useTime = 10;
			item.useAnimation = 10;
			item.useStyle = 5;
			item.mana = 40;
			item.noMelee = true;
			item.magic = true;
			item.value = 1000000;
			item.rare = 2;
            item.UseSound = SoundID.Item21;
        }
		public override bool UseItem(Player p)
		{
			for(int i = 0; i < 22; i++)
			{
				if (p.buffType[i] == 20) p.buffTime[i] = 0;
				if (p.buffType[i] == 22) p.buffTime[i] = 0;
				if (p.buffType[i] == 23) p.buffTime[i] = 0;
				if (p.buffType[i] == 24) p.buffTime[i] = 0;
				if (p.buffType[i] == 25) p.buffTime[i] = 0;
				if (p.buffType[i] == 30) p.buffTime[i] = 0;
				if (p.buffType[i] == 31) p.buffTime[i] = 0;
				if (p.buffType[i] == 32) p.buffTime[i] = 0;
				if (p.buffType[i] == 33) p.buffTime[i] = 0;
				if (p.buffType[i] == 35) p.buffTime[i] = 0;
				if (p.buffType[i] == 36) p.buffTime[i] = 0;
				if (p.buffType[i] == 39) p.buffTime[i] = 0;
				if (p.buffType[i] == 44) p.buffTime[i] = 0;
				if (p.buffType[i] == 46) p.buffTime[i] = 0;
				if (p.buffType[i] == 47) p.buffTime[i] = 0;
				if (p.buffType[i] == 69) p.buffTime[i] = 0;
				if (p.buffType[i] == 70) p.buffTime[i] = 0;
				if (p.buffType[i] == 80) p.buffTime[i] = 0;
				if (p.buffType[i] == 144) p.buffTime[i] = 0;
				if (p.buffType[i] == 148) p.buffTime[i] = 0;
				if (p.buffType[i] == 149) p.buffTime[i] = 0;
				if (p.buffType[i] == 153) p.buffTime[i] = 0;
			}
			return true;
		}
	}
}