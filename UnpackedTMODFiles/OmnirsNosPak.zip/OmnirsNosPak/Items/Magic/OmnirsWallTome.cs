using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Magic
{
	public class OmnirsWallTome : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Wall Tome");
			Tooltip.SetDefault("A lost tome fabled to grant great defense, adding 32 to defense for 10 seconds.");
		}
		public override void SetDefaults()
		{
			item.width = 34;
			item.height = 10;
			item.useTime = 10;
			item.useAnimation = 10;
			item.useStyle = 5;
            item.UseSound = SoundID.Item21;
            item.mana = 40;
			item.noMelee = true;
			item.magic = true;
			item.value = 2000000;
			item.rare = 7;
			item.buffTime = 600;
			item.buffType = mod.BuffType("OmnirsWall");
		}
	}
}