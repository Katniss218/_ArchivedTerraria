using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Magic
{
	public class OmnirsProtectTome : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Protect Tome");
			Tooltip.SetDefault("Casts Protect, adding 8 defense for 10 seconds.");
		}
		public override void SetDefaults()
		{
			item.width = 34;
			item.height = 10;
			item.useTime = 10;
			item.useAnimation = 10;
			item.useStyle = 5;
            item.UseSound = SoundID.Item21;
            item.mana = 20;
			item.noMelee = true;
			item.magic = true;
			item.value = 1400;
			item.rare = 3;
			item.buffTime = 600;
			item.buffType = mod.BuffType("Protect");
		}
		//public override bool CanUseItem(Player player)
		//{
		//	MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
		//	for(int i = 0; i < 22; i++)
		//	{
		//		if (player.buffType[i] == mod.BuffType("OmnirsProtect") && p.protect > 8) return false;
		//	}
		//	p.protect = 8;
		//	return true;
		//}
	}
}