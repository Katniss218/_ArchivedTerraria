using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Magic
{
	public class OmnirsHeal4Tome : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Heal 4 Tome");
			Tooltip.SetDefault("A lost legendary tome for healing others.");
		}
		public override void SetDefaults()
		{
			item.width = 34;
			item.height = 10;
			item.useTime = 15;
			item.useAnimation = 15;
			item.useStyle = 5;
            item.UseSound = SoundID.Item21;
			item.mana = 40;
			item.damage = 0;
			item.noMelee = true;
			item.magic = true;
			item.value = 25000000;
			item.rare = 10;
			item.shoot = mod.ProjectileType("OmnirsSpellHeal4Ball");
			item.shootSpeed = 0;
		}
         /* ai[0] : The hostility of the projectile.
         *             0 -> use default projectile hostility
         *             1 -> hurt NPCS but not Players/Townies
         *            -1 -> hurt Players/Townies but not NPCs
         *             2 -> hurt BOTH Players/Townies and NPCs
         *             3 -> hurt NEITHER Players/Townies and NPCs (inert projectile)
         */
		public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
		{
			MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
			if(p.dualCast)
				Projectile.NewProjectile(position.X,position.Y-20,speedX*.9f,speedY*.9f,type,damage,knockBack,Main.myPlayer,1,mod.ProjectileType("OmnirsSpellHeal4Ball"));
			Projectile.NewProjectile(position.X,position.Y,speedX,speedY,type,damage,knockBack,Main.myPlayer,1,mod.ProjectileType("OmnirsSpellHeal4Ball"));
			return false;
		}
	}
}