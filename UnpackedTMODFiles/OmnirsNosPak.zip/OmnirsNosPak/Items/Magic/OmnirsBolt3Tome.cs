using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Magic
{
	public class OmnirsBolt3Tome : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Bolt 3 Tome");
			Tooltip.SetDefault("A lost tome fabled to deal great damage.");
		}
		public override void SetDefaults()
		{
			item.width = 28;
			item.height = 30;
			item.useTime = 25;
			item.useAnimation = 25;
			item.useStyle = 5;
            item.UseSound = SoundID.Item21;
            item.mana = 30;
			item.damage = 35;
			item.noMelee = true;
			item.magic = true;
			item.autoReuse = true;
			item.channel = true;
			item.value = 20000;
			item.rare = 2;
			item.shoot = mod.ProjectileType("OmnirsBoltBall");
			item.shootSpeed = 6;
		}
         /* ai[0] : The hostility of the projectile.
         *             0 -> use default projectile hostility
         *             1 -> hurt NPCS but not Players/Townies
         *            -1 -> hurt Players/Townies but not NPCs
         *             2 -> hurt BOTH Players/Townies and NPCs
         *             3 -> hurt NEITHER Players/Townies and NPCs (inert projectile)
         */
		public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
		{
			MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
			if(p.dualCast)
				Projectile.NewProjectile(position.X,position.Y-20,speedX*.9f,speedY*.9f,type,damage,knockBack,Main.myPlayer,1,mod.ProjectileType("OmnirsBolt3"));
			Projectile.NewProjectile(position.X,position.Y,speedX,speedY,type,damage,knockBack,Main.myPlayer,1,mod.ProjectileType("OmnirsBolt3"));
			return false;
		}
	}
}