using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Magic
{
	public class OmnirsShieldTome : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Shield Tome");
			Tooltip.SetDefault("A lost legendary tome, adding 62 to defense for 10 seconds.");
		}
		public override void SetDefaults()
		{
			item.width = 34;
			item.height = 10;
			item.useTime = 10;
			item.useAnimation = 10;
			item.useStyle = 5;
            item.UseSound = SoundID.Item21;
            item.mana = 80;
			item.noMelee = true;
			item.magic = true;
			item.value = 25000000;
			item.rare = 10;
			item.buffTime = 600;
			item.buffType = mod.BuffType("OmnirsShield");
		}
	}
}