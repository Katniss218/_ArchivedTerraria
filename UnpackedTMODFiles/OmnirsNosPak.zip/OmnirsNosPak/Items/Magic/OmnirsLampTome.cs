using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Magic
{
	public class OmnirsLampTome : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Lamp Tome");
			Tooltip.SetDefault("A lost tome known to cure blindness.");
		}
		public override void SetDefaults()
		{
			item.width = 34;
			item.height = 10;
			item.useTime = 10;
			item.useAnimation = 10;
			item.useStyle = 5;
			item.mana = 5;
			item.noMelee = true;
			item.magic = true;
			item.value = 1400;
			item.rare = 2;
            item.shoot = mod.ProjectileType("OmnirsSpellEffectBuff");
            item.UseSound = SoundID.Item21;
        }
		public override bool UseItem(Player p)
		{
			for(int i = 0; i < 22; i++)
			{
				if (p.buffType[i] == 22) p.buffTime[i] = 0;
            }
			return true;
		}
	}
}