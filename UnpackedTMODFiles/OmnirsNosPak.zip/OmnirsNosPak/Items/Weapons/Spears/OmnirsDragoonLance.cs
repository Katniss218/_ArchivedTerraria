using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Spears
{
	public class OmnirsDragoonLance : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dragoon Lance");
			Tooltip.SetDefault("A spear forged from the fang of the Dragoon Serpent.");
		}
		public override void SetDefaults()
		{
			item.width = 50;
			item.height = 50;
			item.damage = 100;
			item.knockBack = 15f;
			item.rare = 5;
			item.value = 200000;
            item.UseSound = SoundID.Item1;
            item.useStyle = 5;
			item.useTime = 1;
			item.useAnimation = 11;
			item.melee = true;
			item.noMelee = true;
			item.noUseGraphic = true;
			item.shoot = mod.ProjectileType("OmnirsDragoonLance");
			item.shootSpeed = 8;
		}
	}
}