using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Spears
{
	public class OmnirsRadiantLance : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Radiant Lance");
			Tooltip.SetDefault("A light glows from this great spear.");
		}
		public override void SetDefaults()
		{
			item.width = 52;
			item.height = 52;
			item.damage = 60;
			item.knockBack = 3;
			item.rare = 3;
			item.value = 1500000;
            item.UseSound = SoundID.Item1;
            item.useStyle = 5;
			item.useTime = 1;
			item.useAnimation = 11;
			item.melee = true;
			item.noMelee = true;
			item.noUseGraphic = true;
			item.shoot = mod.ProjectileType("OmnirsRadiantLance");
			item.shootSpeed = 10;
		}
	}
}