using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
    public class OmnirsWereBane : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Were Bane");
			Tooltip.SetDefault("A sword used to kill were-beasts.");
		}
        public override void SetDefaults()
        {
            item.width = 42;
            item.height = 42;
            item.damage = 18;
            item.knockBack = 5;
            item.rare = 2;
            item.value = 40000;
            item.UseSound = SoundID.Item1;
            item.useStyle = 1;
            item.useTime = 21;
            item.useAnimation = 21;
            item.melee = true;
            item.scale = 1f;
        }
        //public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        //{
        //    if (npc.type == 104 || npc.type == 343)
        //    {
        //        damage *= 4;
        //    }
        //        catch
        //    {
        //        Main.NewText("Your mom", 255, 30, 30);
        //    }
        //}
    }
}