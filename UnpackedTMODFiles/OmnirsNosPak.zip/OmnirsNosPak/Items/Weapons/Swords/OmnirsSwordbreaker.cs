using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords
{
	public class OmnirsSwordbreaker : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Swordbreaker");
			Tooltip.SetDefault("Sometimes deflects attacks.");
		}
		public override void SetDefaults()
		{
			item.width = 28;
			item.height = 28;
			item.damage = 26;
			item.knockBack = 3.5f;
			item.rare = 2;
			item.value = 9060000;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 15;
			item.useAnimation = 15;
			item.melee = true;
			item.material = true;
		}
		public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
		{
            //if (Main.rand.Next(20) == 0)
            //{
            //    try
            //    {
            //        target.AddBuff(mod.BuffType("OmnirsInvincible"), 30, false);
            //    }
            //    catch
            //    {
            //        Main.NewText("Test", 255, 30, 30);
            //        target.AddBuff(BuffID.Ichor, 10000, false);
            //    }
            //}
		}
	}
}