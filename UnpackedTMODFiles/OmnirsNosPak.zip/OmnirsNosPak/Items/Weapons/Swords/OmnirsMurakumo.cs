using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
	public class OmnirsMurakumo : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Murakumo");
		}
		public override void SetDefaults() 
		{
			item.width = 42;
			item.height = 72;
			item.damage = 135;
			item.knockBack = 7;
			item.rare = 10;
			item.value = 3200000;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 21;
			item.useAnimation = 16;
			item.melee = true;
            item.scale = 1.05f;
		}
	}
}