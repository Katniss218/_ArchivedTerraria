using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
	public class OmnirsOrcishShortsword : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Orcish Shortsword");
		}
		public override void SetDefaults() 
		{
			item.width = 22;
			item.height = 22;
			item.damage = 9;
			item.knockBack = 4.5f;
			item.value = 450;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 15;
			item.useAnimation = 9;
			item.melee = true;
            item.scale = 1.05f;
		}
	}
}