using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
	public class OmnirsGiantSword : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Giant Sword");
			Tooltip.SetDefault("Has been forged by ancient giants.");
		}
		public override void SetDefaults() 
		{
			item.width = 46;
			item.height = 46;
			item.damage = 97;
			item.knockBack = 10;
			item.rare = 7;
			item.value = 170000;
            item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 21;
			item.useAnimation = 30;
			item.melee = true;
            item.scale = 1.25f;
		}
    }
}