using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
    public class OmnirsCoralSword : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Coral Sword");
			Tooltip.SetDefault("Edged to slay those of the sea.");
		}
        public override void SetDefaults()
        {
            item.width = 36;
            item.height = 36;
            item.damage = 19;
            item.knockBack = 5;
            item.rare = 3;
            item.value = 11000;
            item.UseSound = SoundID.Item1;
            item.useStyle = 1;
            item.useTime = 23;
            item.useAnimation = 23;
            item.melee = true;
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            if (NPC.AnyNPCs(mod.NPCType("OmnirsSahaginChief")) || NPC.AnyNPCs(mod.NPCType("OmnirsSahaginPrince")) || NPC.AnyNPCs(mod.NPCType("OmnirsQuaraConstrictor")) || NPC.AnyNPCs(mod.NPCType("OmnirsQuaraHydromancer")) || NPC.AnyNPCs(mod.NPCType("OmnirsQuaraMantassin")) || NPC.AnyNPCs(mod.NPCType("OmnirsQuaraPincher")) || NPC.AnyNPCs(mod.NPCType("OmnirsQuaraPredator")) || NPC.AnyNPCs(mod.NPCType("OmnirsTheWaterFiendKraken")))
                try
                {
                    damage *= 4;
                }
                catch
                {
                    Main.NewText("Your mom", 255, 30, 30);
                }
        }
    }
}