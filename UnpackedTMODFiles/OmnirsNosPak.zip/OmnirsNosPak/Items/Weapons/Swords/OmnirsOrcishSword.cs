using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
	public class OmnirsOrcishSword : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Orcish Sword");
		}
		public override void SetDefaults() 
		{
			item.width = 24;
			item.height = 24;
			item.damage = 14;
			item.knockBack = 6;
			item.rare = 1;
			item.value = 1500;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 21;
			item.useAnimation = 15;
			item.melee = true;
            //item.scale = 1.1f;
		}
	}
}