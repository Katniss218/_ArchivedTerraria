using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
	public class OmnirsFireSword : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Fire Sword");
			Tooltip.SetDefault("The blade is a magic flame.");
		}
		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 32;
			item.damage = 52;
			item.knockBack = 5.5f;
			item.rare = 4;
			item.value = 90000;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 15;
			item.useAnimation = 21;
			item.melee = true;
            item.scale = 1.05f;
		}
        public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            if (Main.rand.Next(2) == 0)
            {
                target.AddBuff(24, 360, false);
            }
        }
    }
}