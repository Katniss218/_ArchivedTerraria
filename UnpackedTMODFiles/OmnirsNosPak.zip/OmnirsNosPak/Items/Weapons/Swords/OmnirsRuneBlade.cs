using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
    public class OmnirsRuneBlade : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Rune Sword");
			Tooltip.SetDefault("Effective against magic-users.");
		}
        public override void SetDefaults()
        {
            item.width = 36;
            item.height = 36;
            item.damage = 55;
            item.knockBack = 5;
            item.rare = 8;
            item.value = 140000;
            item.UseSound = SoundID.Item1;
            item.useStyle = 1;
            item.useTime = 21;
            item.useAnimation = 21;
            item.melee = true;
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            if (NPC.AnyNPCs(mod.NPCType("OmnirsEvilPriestess")) || NPC.AnyNPCs(mod.NPCType("OmnirsNecromancer")) || NPC.AnyNPCs(mod.NPCType("OmnirsWitch")) || NPC.AnyNPCs(mod.NPCType("OmnirsOrcShaman")) || NPC.AnyNPCs(mod.NPCType("OmnirsMinotaurMage")) || NPC.AnyNPCs(mod.NPCType("OmnirsMindflayer")) || NPC.AnyNPCs(mod.NPCType("OmnirsPiscodemon")) || NPC.AnyNPCs(mod.NPCType("OmnirsWarlock")))
                try
                {
                    damage *= 4;
                }
                catch
                {
                    Main.NewText("Your mom", 255, 30, 30);
                }

            //if (npc.type == 29 || npc.type == 32 || npc.type == 45 || npc.type == 172 || npc.type == 281 || npc.type == 282 || npc.type == 283 || npc.type == 284 || npc.type == 285 || npc.type == 286 || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsOrcShaman"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsMinotaurMage"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsMindflayer"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsPiscodemon"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsWitch"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsWarlock"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsNecromancer"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsEvilPriestess"].type))) damage *= 4;
        }
    }
}