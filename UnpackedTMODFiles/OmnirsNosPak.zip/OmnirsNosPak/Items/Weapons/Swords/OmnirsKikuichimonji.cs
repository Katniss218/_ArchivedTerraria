using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
	public class OmnirsKikuichimonji : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Kikuichimonji");
			Tooltip.SetDefault("It's scabbard is adorned with a chrysanthemum.");
		}
		public override void SetDefaults() 
		{
			item.width = 38;
			item.height = 52;
			item.damage = 35;
			item.knockBack = 4;
			item.rare = 6;
			item.value = 38000;
            item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 21;
			item.useAnimation = 15;
			item.melee = true;
		}
    }
}