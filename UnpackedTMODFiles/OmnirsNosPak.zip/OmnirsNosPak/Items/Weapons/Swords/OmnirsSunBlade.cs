using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
    public class OmnirsSunBlade : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Sun Sword");
			Tooltip.SetDefault("A sword used to kill the undead.");
		}
        public override void SetDefaults()
        {
            item.width = 36;
            item.height = 36;
            item.damage = 43;
            item.knockBack = 9;
            item.rare = 7;
            item.value = 160000;
            item.UseSound = SoundID.Item1;
            item.useStyle = 1;
            item.useTime = 21;
            item.useAnimation = 23;
            item.melee = true;
        }
        public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            if (NPC.AnyNPCs(mod.NPCType("OmnirsCryptShambler")) || NPC.AnyNPCs(mod.NPCType("OmnirsTheEarthFiendLich")) || NPC.AnyNPCs(mod.NPCType("OmnirsRottingGhoul")))
                try
                {
                    damage *= 4;
                }
                catch
                {
                    Main.NewText("Your mom", 255, 30, 30);
                }
        }
    }
}