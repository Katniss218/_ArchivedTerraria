using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
	public class OmnirsMurasame : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Murasame");
			Tooltip.SetDefault("Heals nearby allies.");
		}
		public override void SetDefaults() 
		{
			item.width = 32;
			item.height = 36;
			item.damage = 50;
			item.knockBack = 11;
			item.rare = 9;
			item.value = 15000000;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 21;
			item.useAnimation = 11;
			item.melee = true;
            item.scale = 1.05f;
            //item.shoot = mod.ProjectileType("OmnirsSpellHeal1Ball");

        }
        //public override bool PreShoot(Player player, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        //{
        //    if ((Main.rand.Next(10) == 0))
        //    {
        //        int Otype = ProjDef.byName["OmnirsNosPak:OmnirsSpellHeal1Ball"].type;
        //        int damNum = 20;
        //        Projectile.NewProjectile(player.Center.X, player.Center.Y, velocity.X, velocity.Y, Otype, damNum, knockback, player.whoAmI);
        //        return false;
        //    }
        //    return false;
        //}
    }
}