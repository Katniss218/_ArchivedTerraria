using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords
{
	public class OmnirsBarrowBlade : ModItem
	{public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Barrow Blade");
			Tooltip.SetDefault("Wrought with spells of a fierce power.\nDispels the defensive shields of Artorias and the Witchking.");
		}
		public override void SetDefaults()
		{
			item.width = 32;
			item.height = 32;
			item.damage = 26;
			item.knockBack = 5;
			item.rare = 2;
			item.value = 140000;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 21;
			item.useAnimation = 21;
			item.melee = true;
			item.material = true;
		}
		public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
		{
            if (NPC.AnyNPCs(mod.NPCType("Witchking")) || NPC.AnyNPCs(mod.NPCType("Nazgul")) || NPC.AnyNPCs(mod.NPCType("Sauron")))
            {
                try
                {
                    target.AddBuff(mod.BuffType("Vulnerable"), 10000, false);
                }
                catch
                {
                    Main.NewText("Vulnerable Buff still needs to be made!", 255, 30, 30);
                    target.AddBuff(BuffID.Ichor, 10000, false);
                }
            }
		}
	}
}