using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
    public class OmnirsWyrmkiller : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Wyrmkiller");
			Tooltip.SetDefault("A sword used to kill dragon-kind.");
		}
        public float damageMultiplier = 1f; // Damage Multiplier of the weapon.
        public override void SetDefaults()
        {
            item.width = 32;
            item.height = 32;
            item.damage = 19;
            item.knockBack = 5;
            item.rare = 5;
            item.value = 140000;
            item.UseSound = SoundID.Item1;
            item.useStyle = 1;
            item.useTime = 19;
            item.useAnimation = 19;
            item.melee = true;
            item.scale = 0.95f;
        }
        //public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        //{
        //    if (NPC.AnyNPCs(mod.NPCType("Dragon")) || (NPC.AnyNPCs(mod.NPCType("Wyvern")) || (NPC.AnyNPCs(mod.NPCType("Hydra")) || (NPC.AnyNPCs(mod.NPCType("Tiamat")))
        //    {
        //        damageMultiplier = 4f;
        //    }
        //    else
        //    {
        //        damageMultiplier = 1f;
        //    }
        //}
    }
}