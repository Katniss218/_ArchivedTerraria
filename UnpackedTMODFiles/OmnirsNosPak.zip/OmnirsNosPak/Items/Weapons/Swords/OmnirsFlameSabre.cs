using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Swords // Code modified from Zero-Exodus's code :)
{
	public class OmnirsFlameSabre : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Flame Saber");
			Tooltip.SetDefault("Randomly casts Fire 2.");
		}
		public override void SetDefaults() 
		{
			item.width = 36;
			item.height = 48;
			item.damage = 63;
			item.knockBack = 5;
			item.rare = 8;
			item.value = 1500000;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 15;
			item.useAnimation = 21;
            //item.shoot = mod.ProjectileType("OmnirsSpellFire2Ball");
            item.melee = true;
		}
        //public override bool PreShoot(Player player, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        //{
        //    if ((Main.rand.Next(10) == 0))
        //    {
        //        int Otype = ProjDef.byName["OmnirsNosPak:OmnirsSpellFire2Ball"].type;
        //        int damNum = 20;
        //        Projectile.NewProjectile(player.Center.X, player.Center.Y, velocity.X, velocity.Y, Otype, damNum, knockback, player.whoAmI);
        //        return false;
        //    }
        //    return false;
        //}
    }
}