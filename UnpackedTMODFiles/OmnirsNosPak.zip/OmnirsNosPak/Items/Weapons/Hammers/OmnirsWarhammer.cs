using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Hammers
{
    public class OmnirsWarhammer : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Warhammer");
		}
        public override void SetDefaults()
        {
            item.width = 38;
            item.height = 38;
            item.damage = 67;
            item.knockBack = 8;
            item.scale = 1.25f;
            item.hammer = 130;
            item.rare = 5;
            item.value = 100000;
            item.UseSound = SoundID.Item1;
            item.useStyle = 1;
            item.useTime = 20;
            item.useAnimation = 45;
            item.melee = true;
        }
    }
}