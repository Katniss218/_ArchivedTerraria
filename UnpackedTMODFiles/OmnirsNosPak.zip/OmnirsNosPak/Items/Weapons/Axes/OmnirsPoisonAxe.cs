using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Axes // Code modified from Zero-Exodus's code :)
{
    public class OmnirsPoisonAxe : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Poison Axe");
			Tooltip.SetDefault("The blade has been dipped in poison.");
		}
		public override void SetDefaults() 
		{
			item.width = 50;
			item.height = 46;
			item.damage = 76;
			item.knockBack = 7;
			item.scale = 1.2f;
			item.axe = 120;
			item.rare = 7;
			item.value = 450000;
            item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 15;
			item.useAnimation = 25;
			item.melee = true;
		}
        public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            target.AddBuff(20, 360, false);
        }
    }
}