using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Axes // Code modified from Zero-Exodus's code :)
{
    public class OmnirsHandAxe : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Hand Axe");
		}
		public override void SetDefaults() 
		{
			item.width = 32;
			item.height = 26;
			item.damage = 5;
			item.knockBack = 4f;
			item.scale = 1;
			item.axe = 5; // Real axe power is this * 5
			item.value = 800;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
            item.useTime = 28;
			item.useAnimation = 31;
			item.melee = true;
		}
	}
}