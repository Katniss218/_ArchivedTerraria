using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Axes // Code modified from Zero-Exodus's code :)
{
	public class OmnirsFireAxe : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Fire Axe");
			Tooltip.SetDefault("The blade is a magical flame.");
		}
		public override void SetDefaults()
		{
			item.width = 40;
			item.height = 32;
			item.damage = 47;
			item.knockBack = 6;
			item.rare = 4;
			item.value = 98000;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 15;
			item.useAnimation = 29;
			item.melee = true;
		}
        public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
            if (Main.rand.Next(2) == 0)
            {
                target.AddBuff(24, 360, false);
            }
        }
    }
}