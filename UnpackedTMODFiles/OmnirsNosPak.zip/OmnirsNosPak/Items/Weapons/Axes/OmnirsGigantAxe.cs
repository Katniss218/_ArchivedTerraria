using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Axes // Code modified from Zero-Exodus's code :)
{
    public class OmnirsGigantAxe : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Gigant Axe");
			Tooltip.SetDefault("An axe used to kill giant-kind.");
		}
		public override void SetDefaults() 
		{
			item.width = 46;
			item.height = 44;
			item.damage = 35;
			item.knockBack = 11;
			item.scale = 1f;
			item.axe = 80;
			item.rare = 4;
			item.value = 12000;
            item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 23;
			item.useAnimation = 27;
			item.melee = true;
		}
	}
}