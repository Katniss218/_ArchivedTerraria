using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Axes // Code modified from Zero-Exodus's code :)
{
    public class OmnirsHalberd : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Halberd");
		}
		public override void SetDefaults() 
		{
			item.width = 60;
			item.height = 60;
			item.damage = 17;
			item.knockBack = 6.5f;
			item.scale = 1.05f;
			item.axe = 70;
			item.rare = 3;
			item.value = 400;
            item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 15;
			item.useAnimation = 25;
			item.melee = true;
		}
    }
}