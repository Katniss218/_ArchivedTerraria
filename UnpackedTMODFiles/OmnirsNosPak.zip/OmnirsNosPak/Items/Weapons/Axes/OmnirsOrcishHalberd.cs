using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Axes // Code modified from Zero-Exodus's code :)
{
    public class OmnirsOrcishHalberd : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Orcish Halberd");
		}
		public override void SetDefaults() 
		{
			item.width = 48;
			item.height = 48;
			item.damage = 24;
			item.knockBack = 6f;
			item.scale = 1;
			item.axe = 40; // Real axe power is this * 5
			item.value = 1400;
			item.UseSound = SoundID.Item1;
			item.useStyle = 1;
            item.useTime = 24;
			item.useAnimation = 24;
			item.melee = true;
		}
	}
}