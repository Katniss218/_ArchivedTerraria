using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Axes // Code modified from Zero-Exodus's code :)
{
    public class OmnirsRuneAxe : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Rune Axe");
			Tooltip.SetDefault("One of the strongest axes.");
		}
		public override void SetDefaults() 
		{
			item.width = 56;
			item.height = 46;
			item.damage = 95;
			item.knockBack = 10;
			item.scale = 1.1f;
			item.axe = 150;
			item.rare = 9;
			item.value = 1800000;
            item.UseSound = SoundID.Item1;
			item.useStyle = 1;
			item.useTime = 15;
			item.useAnimation = 25;
			item.melee = true;
		}
        public override void OnHitNPC(Player player, NPC target, int damage, float knockBack, bool crit)
        {
//            if (npc.type == 29 || npc.type == 32 || npc.type == 45 || npc.type == 172 || npc.type == 281 || npc.type == 282 || npc.type == 283 || npc.type == 284 || npc.type == 285 || npc.type == 286 || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsOrcShaman"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsMinotaurMage"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsMindflayer"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsPiscodemon"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsWitch"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsWarlock"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsNecromancer"].type)) || (NPC.AnyNPCs(NPCDef.byName["OmnirsNosPak:OmnirsEvilPriestess"].type))) damage *= 4;
        }
    }
}