using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Bows // Code modified from Zero-Exodus's code :)
{
	public class OmnirsChainBolter : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Chain Bolter");
		}
		public override void SetDefaults()
		{
			item.width = 34;
			item.height = 20;
			item.useTime = 45;
			item.useAnimation = 45;
			item.reuseDelay = 15;
			item.useStyle = 5;
			item.UseSound = SoundID.Item5;
			item.useAmmo = 40;
			item.damage = 56;
			item.knockBack = 8;
			item.noMelee = true;
			item.ranged = true;
			item.autoReuse = true;
			item.value = 135000;
			item.rare = 6;
			item.shoot = ProjectileID.WoodenArrowFriendly;
			item.shootSpeed = 33;
		}
	}
}