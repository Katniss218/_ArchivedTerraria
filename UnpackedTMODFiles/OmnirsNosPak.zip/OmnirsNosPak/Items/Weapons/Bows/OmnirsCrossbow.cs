using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Bows // Code modified from Zero-Exodus's code :)
{
	public class OmnirsCrossbow : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Old Crossbow");
		}
		public override void SetDefaults()
		{
			item.width = 12;
			item.height = 28;
			item.useTime = 30;
			item.useAnimation = 30;
			item.reuseDelay = 15;
			item.useStyle = 5;
			item.UseSound = SoundID.Item5;
			item.useAmmo = 40;
			item.damage = 19;
			item.knockBack = 4;
			item.noMelee = true;
			item.ranged = true;
			item.autoReuse = true;
			item.value = 5000;
			item.rare = 1;
			item.shoot = ProjectileID.WoodenArrowFriendly;
			item.shootSpeed = 10;
		}
	}
}