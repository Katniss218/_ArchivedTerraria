using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Bows // Code modified from Zero-Exodus's code :)
{
	public class OmnirsArbalest : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Arbalest");
			Tooltip.SetDefault("The iron mounting makes it heavy.");
		}
		public override void SetDefaults()
		{
			item.width = 30;
			item.height = 16;
			item.useTime = 30;
			item.useAnimation = 30;
			item.reuseDelay = 15;
			item.useStyle = 5;
			item.UseSound = SoundID.Item5;
			item.damage = 66;
			item.knockBack = 19;
			item.noMelee = true;
			item.ranged = true;
			item.autoReuse = true;
			item.value = 140000;
			item.rare = 8;
            item.useAmmo = 40;
            item.shoot = ProjectileID.WoodenArrowFriendly;
            item.shootSpeed = 30;
		}
	}
}