using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Bows // Code modified from Zero-Exodus's code :)
{
	public class OmnirsIceBow : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Ice Bow");
			Tooltip.SetDefault("Randomly casts Ice 2.");
		}
		public override void SetDefaults()
		{
			item.width = 16;
			item.height = 58;
            item.useTime = 22;
			item.useAnimation = 22;
			item.useStyle = 5;
			item.UseSound = SoundID.Item5;
			item.useAmmo = 40;
			item.damage = 50;
			item.knockBack = 5;
			item.noMelee = true;
			item.ranged = true;
			item.value = 1500000;
			item.rare = 8;

			item.shoot = ProjectileID.WoodenArrowFriendly;
			item.shootSpeed = 11;
            item.scale = 0.9f;
		}
        //public override bool PreShoot(Player player, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        //{
        //    if ((Main.rand.Next(10) == 0))
        //    {
        //        int Otype = ProjDef.byName["OmnirsNosPak:OmnirsSpellIce2Ball"].type;
        //        int damNum = 15;
        //        Projectile.NewProjectile(player.Center.X, player.Center.Y, velocity.X, velocity.Y, Otype, damNum, knockback, player.whoAmI);
        //        return false;
        //    }
        //    return false;
        //}
    }
}