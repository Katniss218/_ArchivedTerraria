using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Weapons.Guns // Code modified from Zero-Exodus's code :)
{
	public class OmnirsLionheartGunblade : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Lionheart Gunblade");
			Tooltip.SetDefault("Of gunblades, the finest model is the Lionheart.");
		}
		public override void SetDefaults()
		{
			item.width = 56;
			item.height = 62;
			item.useTime = 45;
			item.useAnimation = 15;
            item.autoReuse = true;
            item.reuseDelay = 15;
			item.useStyle = 5;
			item.UseSound = SoundID.Item5;
			item.useAmmo = 97;
			item.damage = 150;
			item.knockBack = 4;
            item.melee = true;
            item.ranged = true;
			item.value = 4600000;
			item.rare = 7;
			item.shoot = ProjectileID.WoodenArrowFriendly;
			item.shootSpeed = 10;
        }
	}
}