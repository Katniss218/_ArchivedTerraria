using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsRedLeggings : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Red Leggings");
			Tooltip.SetDefault("Red Equipment made from the strongest leather. \n+10% movement, +5% ranged damage.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 7000000;
            item.rare = 10;
            item.defense = 13;
        }
        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.1f;
            player.rangedDamage += 0.05f;
        }
    }
}