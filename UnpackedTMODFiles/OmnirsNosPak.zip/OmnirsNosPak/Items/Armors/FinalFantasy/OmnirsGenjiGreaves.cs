using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsGenjiGreaves : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Genji Greaves");
			Tooltip.SetDefault("Armor from the East. \n+25% movement.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 900000;
            item.rare = 7;
            item.defense = 10;
        }
        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.25f;
        }
    }
}