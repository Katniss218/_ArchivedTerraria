using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsGenjiArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Genji Armor");
			Tooltip.SetDefault("Armor from the East. \n+25% melee speed.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 1200000;
            item.rare = 7;
            item.defense = 15;
        }

        public override void UpdateEquip(Player player)
        {
            player.meleeSpeed += 0.25f;
        }
	}
}