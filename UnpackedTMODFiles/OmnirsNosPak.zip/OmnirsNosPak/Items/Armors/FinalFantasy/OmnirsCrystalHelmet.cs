using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsCrystalHelmet : ModItem
	{
        /// <summary>
        /// All the Armors are to be placed in the Armors Subfolder.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="texture"></param>
        /// <param name="equips"></param>
        /// <returns>Armors</returns>
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Crystal Helmet");
			Tooltip.SetDefault("Dazzling armor cut from crystal. \n+20% Melee crit chance.");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
            item.value = 7000000;
			item.rare = 10;
			item.defense = 18;
		}

        public override void UpdateEquip(Player player)
        {
            player.meleeCrit += 20;
        }

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
            return body.type == mod.ItemType("OmnirsCrystalArmor") && legs.type == mod.ItemType("OmnirsCrystalGreaves");
		}

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+30% melee damage";
            player.meleeDamage += 0.30f;
        }
	}
}