using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsBardsTunicBottoms : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Bards Tunic Bottoms");
			Tooltip.SetDefault("Tunic with ancient verse embroidered in its sleeves. \n+3% movement, -7% mana cost.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 1000000;
            item.rare = 8;
            item.defense = 9;
        }
        public override void UpdateEquip(Player player)
        {
            player.manaCost -= 0.07f;
            player.moveSpeed += 0.03f;
        }
    }
}