using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsWhiteRobeBottoms : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("White Robe Bottoms");
			Tooltip.SetDefault("Robe made for those who use white magic. \n+10% movement, -5% mana cost, fire walking.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 7000000;
            item.rare = 10;
            item.defense = 12;
        }
        public override void UpdateEquip(Player player)
        {
            player.manaCost -= 0.05f;
            player.moveSpeed += 0.10f;
            player.fireWalk = true;
        }
    }
}