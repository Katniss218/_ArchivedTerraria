using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsDragoonArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dragoon Armor");
			Tooltip.SetDefault("Dragon armor that the Dragoons wear. \n+ 20% melee speed.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 550000;
            item.rare = 5;
            item.defense = 10;
        }

        public override void UpdateEquip(Player player)
        {
            player.meleeSpeed += 0.20f;
        }
	}
}