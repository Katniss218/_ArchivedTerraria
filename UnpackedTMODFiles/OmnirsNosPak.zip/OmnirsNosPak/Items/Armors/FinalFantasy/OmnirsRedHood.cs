using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsRedHood : ModItem
	{
        /// <summary>
        /// All the Armors are to be placed in the Armors Subfolder.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="texture"></param>
        /// <param name="equips"></param>
        /// <returns>Armors</returns>
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Red Hood");
			Tooltip.SetDefault("Red Equipment made from the strongest leather. \n+20% ranged critical chance.");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
            item.value = 7000000;
			item.rare = 10;
			item.defense = 13;
		}

        public override void UpdateEquip(Player player)
        {
            player.rangedCrit += 20;
        }

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
            return body.type == mod.ItemType("OmnirsRedJacket") && legs.type == mod.ItemType("OmnirsRedLeggings");
		}

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+30% ranged damage";
            player.rangedDamage += 0.30f;
        }
	}
}