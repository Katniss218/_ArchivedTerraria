using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsGrandCirclet : ModItem
	{
        /// <summary>
        /// All the Armors are to be placed in the Armors Subfolder.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="texture"></param>
        /// <param name="equips"></param>
        /// <returns>Armors</returns>
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Grand Circlet");
			Tooltip.SetDefault("Headwear infused with magical power. \n+20% magic critical chance, +100 max mana.");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
            item.value = 7000000;
			item.rare = 10;
			item.defense = 12;
            //hairType =2;
		}

        public override void UpdateEquip(Player player)
        {
            player.magicCrit += 20;
            player.statManaMax2 += 100;
        }
	}
}