using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsBlackRobeBottoms : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Black Robe Bottoms");
			Tooltip.SetDefault("Robe made for those who use black magic. \n+5% movement, -10% mana cost.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 7000000;
            item.rare = 10;
            item.defense = 10;
        }

        public override void UpdateEquip(Player player)
        {
            player.manaCost *= 0.9f;
            player.moveSpeed += 0.05f;
        }
    }
}