using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsCrystalArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Crystal Armor");
			Tooltip.SetDefault("Dazzling armor cut from crystal. \n+ 30 % melee speed.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 9000000;
            item.rare = 10;
            item.defense = 20;
        }

        public override void UpdateEquip(Player player)
        {
            player.meleeSpeed += 0.30f;
        }
	}
}