using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsCrystalGreaves : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Crystal Greaves");
			Tooltip.SetDefault("Dazzling armor cut from crystal. \n+30% movement.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 7000000;
            item.rare = 10;
            item.defense = 18;
        }
        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.3f;
        }
    }
}