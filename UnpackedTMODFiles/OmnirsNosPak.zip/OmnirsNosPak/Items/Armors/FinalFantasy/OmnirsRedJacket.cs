using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsRedJacket : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Red Jacket");
			Tooltip.SetDefault("Red Equipment made from the strongest leather. \n+25% chance not to consume ammo.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 9000000;
            item.rare = 10;
            item.defense = 14;
        }

        public override void UpdateEquip(Player player)
        {
            player.ammoCost75 = true;
        }
	}
}