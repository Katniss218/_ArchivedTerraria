using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsDragoonHelmet : ModItem
	{
        /// <summary>
        /// All the Armors are to be placed in the Armors Subfolder.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="texture"></param>
        /// <param name="equips"></param>
        /// <returns>Armors</returns>
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dragoon Helmet");
			Tooltip.SetDefault("Dragon armor that the Dragoons wear. \n+10% melee critical chance.");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
            item.value = 350000;
			item.rare = 5;
			item.defense = 7;
		}

        public override void UpdateEquip(Player player)
        {
            player.meleeCrit += 10;
        }

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
            return body.type == mod.ItemType("OmnirsDragoonArmor") && legs.type == mod.ItemType("OmnirsDragoonGreaves");
		}

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+15% melee damage, +10 defense.";
            player.meleeDamage += 0.15f;
            player.statDefense += 10;
        }
	}
}