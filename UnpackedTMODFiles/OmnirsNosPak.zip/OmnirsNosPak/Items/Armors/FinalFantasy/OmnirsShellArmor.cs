using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsShellArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Shell Armor");
			Tooltip.SetDefault("Armor made from the shell of a legenadry creature. \n20% chance not to consume ammo");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 200000;
            item.rare = 7;
            item.defense = 11;
        }

        public override void UpdateEquip(Player player)
        {
            player.ammoCost80 = true;
        }
	}
}