using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsBlackRobeTop : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Black Robe Top");
			Tooltip.SetDefault("Robe made for those who use black magic. \n-15% mana cost, +5% magic damage.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 9000000;
            item.rare = 10;
            item.defense = 11;
        }

        public override void UpdateEquip(Player player)
        {
            player.manaCost *= 0.85f;
            player.magicDamage += 0.05f;
        }
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return head.type == mod.ItemType("OmnirsGrandCirclet") && legs.type == mod.ItemType("OmnirsBlackRobeBottoms");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.manaCost -= 0.15f;
            player.magicDamage += 0.05f;
        }
    }
}