using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsBardsTunicTop : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Bards Tunic Top");
			Tooltip.SetDefault("Tunic with ancient verse embroidered in its sleeves. \n-12% mana cost, +5% magic damage.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 1000000;
            item.rare = 8;
            item.defense = 10;
        }

        public override void UpdateEquip(Player player)
        {
            player.manaCost -= 0.12f;
            player.magicDamage += 0.05f;
        }
	}
}