using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsDragoonGreaves : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dragoon Greaves");
			Tooltip.SetDefault("Dragon armor that the Dragoons wear. \n+20% movement.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 350000;
            item.rare = 5;
            item.defense = 8;
        }
        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.20f;
        }
    }
}