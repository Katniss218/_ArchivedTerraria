using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsShellGreaves : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Shell Greaves");
			Tooltip.SetDefault("Armor made from the shell of a legenadry creature. \n+8% movement, +3% ranged damage.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 900000;
            item.rare = 7;
            item.defense = 10;
        }
        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.08f;
            player.rangedDamage += 0.03f;
        }
    }
}