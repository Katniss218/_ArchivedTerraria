using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsShellHelmet : ModItem
	{
        /// <summary>
        /// All the Armors are to be placed in the Armors Subfolder.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="texture"></param>
        /// <param name="equips"></param>
        /// <returns>Armors</returns>
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Shell Helmet");
			Tooltip.SetDefault("Armor made from the shell of a legenadry creature. \n+15% ranged critical chance.");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
            item.value = 900000;
			item.rare = 7;
			item.defense = 10;
		}

        public override void UpdateEquip(Player player)
        {
            player.rangedCrit += 15;
        }

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
            return body.type == mod.ItemType("OmnirsShellArmor") && legs.type == mod.ItemType("OmnirsShellGreaves");
		}

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+20% ranged damage";
            player.rangedDamage += 0.20f;
        }
	}
}