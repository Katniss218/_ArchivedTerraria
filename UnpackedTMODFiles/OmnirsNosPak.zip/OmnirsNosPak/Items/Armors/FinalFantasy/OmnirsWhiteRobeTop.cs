using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.FinalFantasy
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsWhiteRobeTop : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("White Robe Top");
			Tooltip.SetDefault("Robe made for those who use white magic. \n-20% mana cost.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 9000000;
            item.rare = 10;
            item.defense = 13;
        }

        public override void UpdateEquip(Player player)
        {
            player.manaCost -= 0.20f;
        }

        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return head.type == mod.ItemType("OmnirsGrandCirclet") && legs.type == mod.ItemType("OmnirsWhiteRobeBottoms");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+25% magic damage";
            player.magicDamage += 0.25f;
        }
    }
}