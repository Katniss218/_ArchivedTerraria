using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Halo
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsMkVIArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Mark VI Armor");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 960;
            item.rare = 10;
            item.defense = 25;
        }
	}
}