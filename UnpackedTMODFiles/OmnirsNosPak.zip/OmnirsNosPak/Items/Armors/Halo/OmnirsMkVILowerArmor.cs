using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Halo
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsMkVILowerArmor : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Mark VI Lower Armor");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 720;
            item.rare = 10;
            item.defense = 30;
        }
    }
}