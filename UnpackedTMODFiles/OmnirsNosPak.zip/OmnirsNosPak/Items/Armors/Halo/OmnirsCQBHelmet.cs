using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Halo
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsCQBHelmet : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("CQB Helmet");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 1200;
			item.rare = 10;
			item.defense = 15;
		}
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("OmnirsCQBArmor") && legs.type == mod.ItemType("OmnirsMkVILowerArmor");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+50 Defense";
            player.statDefense += 50;
        }
	}
}