using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Halo
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsCQBArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("CQB Armor");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 960;
            item.rare = 10;
            item.defense = 25;
        }
	}
}