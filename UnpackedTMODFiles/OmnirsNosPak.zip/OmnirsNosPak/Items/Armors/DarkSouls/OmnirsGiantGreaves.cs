using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.DarkSouls
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsGiantGreaves : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Giant Greaves");
			Tooltip.SetDefault("Become unnnstopable! \nAdds 6% to melee damage");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 100000;
            item.rare = 8;
            item.defense = 21;
        }
        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.06f;
        }
    }
}