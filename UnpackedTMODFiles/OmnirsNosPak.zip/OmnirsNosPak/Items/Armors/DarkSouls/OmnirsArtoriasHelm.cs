using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.DarkSouls
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsArtoriasHelm : ModItem
	{
        /// <summary>
        /// All the Armors are to be placed in the Armors Subfolder.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="texture"></param>
        /// <param name="equips"></param>
        /// <returns>Armors</returns>
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Helmet of Artorias");
			Tooltip.SetDefault("The helmet of the lost knight. \nAdds 5% to melee damage");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
            item.value = 10000;
			item.rare = 8;
			item.defense = 9;
		}

        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.05f;

        }

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
            return body.type == mod.ItemType("OmnirsArtoriasArmor") && legs.type == mod.ItemType("OmnirsArtoriasGreaves");
		}

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+10% melee damage, +10% movement speed";
            player.meleeDamage += 0.10f;
            player.moveSpeed += 0.20f;
        }
	}
}