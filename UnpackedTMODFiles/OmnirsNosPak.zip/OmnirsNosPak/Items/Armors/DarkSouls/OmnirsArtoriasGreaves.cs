using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.DarkSouls
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsArtoriasGreaves : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Greaves of Artorias");
			Tooltip.SetDefault("Greaves of the one who challenged Manus. \n+20% to movement speed");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 100000;
            item.rare = 8;
            item.defense = 21;
        }
        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.20f;
        }
    }
}