using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.DarkSouls
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsArtoriasArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Armor of Artorias");
			Tooltip.SetDefault("Armor of the great knight Artorias. \nAdds 12% to melee damage");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 170000;
            item.rare = 8;
            item.defense = 22;
        }

        public override void UpdateEquip(Player player)
        {
            player.meleeDamage += 0.12f;
        }
	}
}