using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.DarkSouls
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsFathersMask : ModItem
	{
        /// <summary>
        /// All the Armors are to be placed in the Armors Subfolder.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="texture"></param>
        /// <param name="equips"></param>
        /// <returns>Armors</returns>
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Father's Mask");
			Tooltip.SetDefault("Best looking mask in the game. \n+23% to movement speed");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
            item.value = 10000;
			item.rare = 8;
			item.defense = 9;
		}

        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.20f;
        }

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
            return body.type == mod.ItemType("OmnirsGiantArmor") && legs.type == mod.ItemType("OmnirsGiantGreaves");
		}

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+15% melee damage";
            player.meleeDamage += 0.15f;
        }
	}
}