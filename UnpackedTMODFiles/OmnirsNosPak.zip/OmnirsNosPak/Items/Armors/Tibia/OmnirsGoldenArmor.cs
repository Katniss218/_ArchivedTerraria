using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsGoldenArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Golden Armor");
			Tooltip.SetDefault("A lost prince's armor. \n+7% melee speed, 20% not to consume ammo.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 640000;
            item.rare = 7;
            item.defense = 15;
        }

        public override void UpdateEquip(Player player)
        {
            player.meleeSpeed += 0.07f;
            player.ammoCost80 = true;
        }
	}
}