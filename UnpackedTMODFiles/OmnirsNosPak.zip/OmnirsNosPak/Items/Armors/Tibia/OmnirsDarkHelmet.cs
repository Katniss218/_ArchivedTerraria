using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsDarkHelmet : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dark Helmet");
			Tooltip.SetDefault("Can be used with either the dark armor or the plate armor, and the plate legs.");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 350;
            item.rare = 2;
			item.defense = 3;
		}
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return (body.type == mod.ItemType("OmnirsDarkArmor")|| body.type == mod.ItemType("OmnirsPlateArmor")) && legs.type == mod.ItemType("OmnirsPlateGreaves");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+4 Defense";
            player.statDefense += 4;
        }
	}
}