using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsDemonArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Demon Armor");
			Tooltip.SetDefault("Given to those who brave Annihilation. \n-15% mana cost.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 2000000;
            item.rare = 8;
            item.defense = 16;
        }

        public override void UpdateEquip(Player player)
        {
            player.manaCost -= 0.15f;
        }
	}
}