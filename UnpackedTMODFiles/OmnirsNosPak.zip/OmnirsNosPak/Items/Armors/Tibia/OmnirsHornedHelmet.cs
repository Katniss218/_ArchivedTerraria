using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsHornedHelmet : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Horned Helmet");
			Tooltip.SetDefault("Part of the Magic Plate set. \n+10% critical chance.");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 8000000;
			item.rare = 10;
			item.defense = 11;
            
		}

        public override void UpdateEquip(Player player)
        {
            player.rangedCrit += 10;
            player.meleeCrit += 10;
            player.magicCrit += 10;
        }

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
            return body.type == mod.ItemType("OmnirsMagicPlateArmor") && legs.type == mod.ItemType("OmnirsMagicPlateGreaves");
		}

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+20% damage, +80 mana";
            player.meleeDamage += 0.20f;
            player.magicDamage += 0.20f;
            player.rangedDamage += 0.20f;
            player.statManaMax2 += 80;
        }
	}
}