using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsChainArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Chain Mail");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 160;
            item.defense = 2;
        }


	}
}