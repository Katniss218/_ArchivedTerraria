using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsGoldenGreaves : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Golden Leggings");
			Tooltip.SetDefault("A lost prince's greaves. \n+10% movement.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 180000;
            item.rare = 8;
            item.defense = 9;
        }
        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += .10f;
        }
    }
}