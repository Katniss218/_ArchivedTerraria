using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsBeholderHelmet : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Beholder Helmet");
			Tooltip.SetDefault("+2 Critical Chance. \nCan be used with the crown armor and legs.");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 300000;
			item.rare = 3;
			item.defense = 7;
		}

        public override void UpdateEquip(Player player)
        {
            player.rangedCrit += 2;
            player.meleeCrit += 2;
            player.magicCrit += 2;
        }

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
            return body.type == mod.ItemType("OmnirsCrownArmor") && legs.type == mod.ItemType("OmnirsCrownGreaves");
		}

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+15% melee damage";
            player.meleeDamage *= 1.15f;
        }
	}
}