using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsDarkArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dark Armor");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 12060;
            item.rare = 2;
            item.defense = 4;
        }
	}
}