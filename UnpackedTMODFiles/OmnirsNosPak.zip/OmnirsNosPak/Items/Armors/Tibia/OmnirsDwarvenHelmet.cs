using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsDwarvenHelmet : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dwarven Helmet");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 40000;
			item.rare = 2;
			item.defense = 4;
		}

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
            return body.type == mod.ItemType("OmnirsDwarvenArmor") && legs.type == mod.ItemType("OmnirsDwarvenGreaves");
		}

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+4 Defense";
            player.statDefense += 4;
        }
	}
}