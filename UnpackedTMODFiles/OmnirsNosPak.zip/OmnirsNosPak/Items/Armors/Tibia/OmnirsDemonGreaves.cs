using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsDemonGreaves : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Demon Leggings");
			Tooltip.SetDefault("A rare piece, indeed. Be warely of lakes. \n+25% movement, can walk on heated grounds.");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 1500000;
            item.rare = 9;
            item.defense = 9;
        }
        public override void UpdateEquip(Player player)
        {
            player.moveSpeed += 0.25f;
            player.fireWalk = true;
        }
    }
}