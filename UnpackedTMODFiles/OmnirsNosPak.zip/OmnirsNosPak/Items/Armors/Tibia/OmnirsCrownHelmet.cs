using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsCrownHelmet : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Crown Helmet");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 120000;
			item.rare = 2;
			item.defense = 6;
		}
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("OmnirsCrownArmor") && legs.type == mod.ItemType("OmnirsCrownGreaves");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+5% run speed, +3 defense";
            player.statDefense += 3;
            player.moveSpeed += 0.05f;
        }
    }
}