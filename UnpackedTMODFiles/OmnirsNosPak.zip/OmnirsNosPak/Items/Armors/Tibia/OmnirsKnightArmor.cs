using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Body)]
    public class OmnirsKnightArmor : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Knight Armor");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 4000;
            item.rare = 1;
            item.defense = 6;
        }
	}
}