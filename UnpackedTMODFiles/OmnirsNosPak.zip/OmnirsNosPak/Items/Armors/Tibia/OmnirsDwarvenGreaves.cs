using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Legs)]
    public class OmnirsDwarvenGreaves : ModItem
    {
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dwarven Leggings");
		}
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.value = 24000;
            item.rare = 3;
            item.defense = 4;
        }
    }
}