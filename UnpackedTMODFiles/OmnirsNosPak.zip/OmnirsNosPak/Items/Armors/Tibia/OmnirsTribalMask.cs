using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsTribalMask : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Tribal Mask");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 100;
			item.defense = 1;
		}
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("OmnirsBastSkirtTop") && legs.type == mod.ItemType("OmnirsBastSkirtBottom");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+3 Defense";
            player.statDefense += 3;
        }
    }
}