using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsRoyalHelmet : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Royal Helmet");
			Tooltip.SetDefault("An excellent masterpiece of a smith. \n+4% critical chance.");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
            //AddTooltip3("Can be used with the golden and dragonscale armor and legs");
            item.value = 300000;
			item.rare = 6;
			item.defense = 7;
            
		}

        public override void UpdateEquip(Player player)
        {
            player.rangedCrit += 4;
            player.meleeCrit += 4;
            player.magicCrit += 4;
        }

		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
            return body.type == mod.ItemType("OmnirsDragonScaleMail") && legs.type == (mod.ItemType("OmnirsDragonScaleGreaves"));
		}

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+5% melee and ranged damage";
            player.meleeDamage += 0.05f;
            player.rangedDamage += 0.05f;
        }
	}
}
