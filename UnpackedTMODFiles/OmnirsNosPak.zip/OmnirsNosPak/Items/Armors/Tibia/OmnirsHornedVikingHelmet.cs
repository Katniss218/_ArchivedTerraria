using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsHornedVikingHelmet : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Horned Viking Helmet");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 1500;
			item.rare = 1;
			item.defense = 2;
		}
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("OmnirsChainArmor") && legs.type == mod.ItemType("OmnirsChainGreaves");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+3 Defense";
            player.statDefense += 3;
        }
	}
}