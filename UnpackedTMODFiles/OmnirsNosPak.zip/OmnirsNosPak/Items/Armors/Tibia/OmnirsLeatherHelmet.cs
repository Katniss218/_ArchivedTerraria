using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Armors.Tibia
{
	[AutoloadEquip(EquipType.Head)]
    public class OmnirsLeatherHelmet : ModItem
	{
        public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Leather Helmet");
		}
		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 26;
			item.value = 35;
			item.defense = 0;
		}
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("OmnirsLeatherArmor") && legs.type == mod.ItemType("OmnirsLeatherGreaves");
        }

        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+2 Defense";
            player.statDefense += 2;
        }
    }
}