using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Items.Summoning
{
	public class OmnirsJeweloftheDepths : ModItem
    {
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Jewel of the Depths");
			Tooltip.SetDefault("An ancient jewel resembling the deep ocean. \nUse to summon Ultima Weapon.");
		}
		public override void SetDefaults()
		{
			item.width = 12;
			item.height = 12;
			item.maxStack = 999;
            item.rare = 9;
			item.useAnimation = 45;
			item.useTime = 45;
			item.useStyle = 4;
			item.UseSound = SoundID.Item44;
			item.consumable = true;
		}

		public override bool CanUseItem(Player player)
		{
			return !NPC.AnyNPCs(mod.NPCType("OmnirsUltimaWeapon"));
		}

		public override bool UseItem(Player player)
		{
			NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType("OmnirsUltimaWeapon"));
			Main.PlaySound(SoundID.Roar, player.position, 0);
			return true;
		}
	}
}