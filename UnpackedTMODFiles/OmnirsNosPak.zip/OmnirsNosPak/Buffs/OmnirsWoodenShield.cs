using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Buffs
{
    public class OmnirsWoodenShield : ModBuff
	{
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Wooden Shield");
            Description.SetDefault("Adds 12 to defense");
            Main.debuff[Type] = false;
            Main.pvpBuff[Type] = true;
        }
        public override void Update(Player player, ref int buffIndex)
        {
            player.statDefense += 12;
        }
	}
}

