using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Buffs
{
	public class OmnirsProtect : ModBuff
	{
		public override void SetDefaults()
		{
			DisplayName.SetDefault("Protect");
			Main.debuff[Type] = false;
			Main.pvpBuff[Type] = true;
		}

		public override void Update(Player player, ref int buffIndex)
		{
			MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
			Description.SetDefault("Defense is increased by +"+p.protect);
			player.statDefense +=p.protect;
			bool canSpawn = true;
			if (player.ownedProjectileCounts[mod.ProjectileType("OmnirsProtect")] > 0)
				canSpawn = false;
			if (canSpawn && player.whoAmI == Main.myPlayer)
				Projectile.NewProjectile(player.Center.X, player.Center.Y, 0f, 0f, mod.ProjectileType("OmnirsProtect"), 0, 0f, player.whoAmI, 0f, 0f);
		}
	}
}

		
