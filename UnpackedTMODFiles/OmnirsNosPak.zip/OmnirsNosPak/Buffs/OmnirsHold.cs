using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.Buffs
{
	public class OmnirsHold : ModBuff
	{
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Hold Spell");
            Description.SetDefault("Jerk enemy cast spell that limits your movment");
            Main.debuff[Type] = false;
            Main.pvpBuff[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            player.controlUp = false;
            player.controlDown = false;
            player.controlLeft = false;
            player.controlRight = false;
            player.controlJump = false;
		}
	}
}

