using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using OmnirsNosPak;

namespace OmnirsNosPak
{
	public class MItem : GlobalItem
	{

		public override bool Shoot(Item item, Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
		{
			MPlayer p = (MPlayer)player.GetModPlayer(mod, "MPlayer");
			bool special = (type == mod.ProjectileType("BoltBall") || type == mod.ProjectileType("IceBall") || type == mod.ProjectileType("FireBall"));
			if(item.magic && p.dualCast && !special)Projectile.NewProjectile(position.X, position.Y-20, speedX*.9f, speedY*.9f, type, damage, knockBack, Main.myPlayer);
			return true;
		}
	}
}

		
