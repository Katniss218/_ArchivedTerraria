﻿//using System;
//using System.Collections.Generic;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.Graphics;

//using TAPI;
//using Terraria;
//using Terraria.DataStructures;
//using BaseMod;

//namespace OmnirsNosPak
//{
//    public class ModProjectileShield : ModProjectile// Code by Yorai
//    {
//        public virtual int DefenseBonus()
//        {
//            return 0;
//        }
//    }
//}
