using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OmnirsNosPak.NPCs.Tibia.Humans
{
	public class OmnirsManHunter : ModNPC
	{
        float customAi1;
        int OTimeLeft = 2000;
        bool walkAndShoot = true;

        bool canDrown = true;
        int drownTimerMax = 2000;
        int drownTimer = 2000;
        int drowningRisk = 1200;

        float npcAcSPD = 0.6f; //How fast they accelerate.
        float npcSPD = 2.5f; //Max speed

        float npcEnrAcSPD = .8f; //How fast they accelerate.
        float npcEnrSPD = 2.8f; //Max speed

        bool tooBig = false;
        bool lavaJumping = false;

        int shot_rate = 120;  //  rate at which archers/bombers fire; 70 for skeleton archer, 180 for goblin archer, 450 for clown; atm must be an even # or won't fire at shot_rate/2
        int fuse_time = 300;  //  fuse time on bombs, 300 for clown bombs
        int projectile_damage = 25;  //  projectile dmg: 35 for Skeleton Archer, 11 for Goblin Archer
        int projectile_id = 81; // projectile id: 82(Flaming Arrow) for Skeleton Archer, 81(Wooden Arrow) for Goblin Archer, 75(Happy Bomb) for Clown
        float projectile_velocity = 11; // initial velocity? 11 for Skeleton Archers, 9 for Goblin Archers, bombs have fixed speed & direction atm
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Man Hunter");
			Main.npcFrameCount[npc.type] = 20;
		}
        public override void SetDefaults()
		{
			npc.width = 18;
			npc.height = 48;
			npc.damage = 5;
			npc.defense = 10;
			npc.lifeMax = 150;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
            npc.value = 800f;
			npc.npcSlots = 100;
            npc.scale = 1f;
			npc.knockBackResist = 0.3f;
			animationType = 110;
		}
        public override float SpawnChance(NPCSpawnInfo s)
        {
            int x = s.spawnTileX;
            int y = s.spawnTileY;
            bool oSky = (y < (Main.maxTilesY * 0.1f));
            bool oSurface = (y >= (Main.maxTilesY * 0.1f) && y < (Main.maxTilesY * 0.2f));
            bool oUnderSurface = (y >= (Main.maxTilesY * 0.2f) && y < (Main.maxTilesY * 0.3f));
            bool oUnderground = (y >= (Main.maxTilesY * 0.3f) && y < (Main.maxTilesY * 0.4f));
            bool oCavern = (y >= (Main.maxTilesY * 0.4f) && y < (Main.maxTilesY * 0.6f));
            bool oMagmaCavern = (y >= (Main.maxTilesY * 0.6f) && y < (Main.maxTilesY * 0.8f));
            bool oUnderworld = (y >= (Main.maxTilesY * 0.8f));
            bool oBorders = (y < (Main.maxTilesY * 0.03f) || x < (Main.maxTilesX * 0.03f) || y > (Main.maxTilesY * 0.97f) || x > (Main.maxTilesX * 0.97f));
            int tile = (int)Main.tile[x, y].type;
            Player p = s.player;
            if (Main.pumpkinMoon || Main.snowMoon || p.townNPCs > 0f || p.ZoneDungeon || p.ZoneMeteor || oBorders)
            {
                return 0f;
            }
            if (oSurface || oUnderSurface || oUnderground)
            {
                if ((x < Main.maxTilesX * 0.35f || x > Main.maxTilesX * 0.65f) && Main.rand.Next(60) == 1) return 1f;
                else if (Main.hardMode && Main.rand.Next(60) == 1) return 1f;
                return 0f;
            }
            return 0f;
        }
        //Spawns on the Surface and Underground, before 3.5/10th and after 6.5/10th (Width). Does not spawn in the Dungeon, Meteor, or if there are Town NPCs.

		public override void AI()  //  warrior ai
		{


            bool enraged = (npc.life < (float)npc.lifeMax*.2f);  //  speed up at low life
			int shotRate = enraged?100:70;
			float accel=enraged? npcEnrAcSPD:npcAcSPD;  //  how fast it can speed up
			float topSpeed=enraged? npcEnrSPD:npcSPD;  //  max walking speed, also affects jump length
			MNPC.fighterAI
			(
				npc, 
				ref npc.ai,
				false,		// nocturnal  	If true, flees when it is daytime.
				true,		// focused 		If true, npc wont get interrupted when hit or confused.
				60, 		// boredom 		The amount of ticks until the npc gets 'bored' following a target.
				2, 			// knockPower 	0 == do not interact with doors, attempt to open the doors by this value, negative numbers will break instead
				accel, 		// accel 		The rate velocity X increases by when moving.
				topSpeed,	// topSpeed 	the maximum velocity on the X axis.
				2, 			// leapReq 		-1 npc wont jump over gaps, more than 0 npc will leap at players
				5, 			// leapSpeed	The max tiles it can jump across and over, horizontally. 
				9, 			// leapHeight 	The max tiles it can jump across and over, vertically. 
				100,		// leapRangeX 	The distance from a player before the npc initiates leap, horizontally. 
				50,			// leapRangeY 	The distance from a player before the npc initiates leap, vertically. 
				0, 			// shotType 	If higher than 0, allows an npc to fire a projectile, archer style.
				40,			// shotRate 	The rate of fire of the projectile, if there is one.
				70,			// shotPow 		The projectile's damage, if -1 it will use the projectile's default.
				14			// shotSpeed	The projectile's velocity.
			);
            Vector2 angle = Main.player[npc.target].Center - npc.Center;
            angle.Y = angle.Y - (Math.Abs(angle.X) * .1f);
            angle.X += (float)Main.rand.Next(-20, 21);
            angle.Y += (float)Main.rand.Next(-20, 21);
            angle.Normalize();
			float distance = npc.Distance(Main.player[npc.target].Center);
            #region shoot and walk
            if (Main.netMode != 1 && !Main.player[npc.target].dead) // can generalize this section to moving+projectile code // can generalize this section to moving+projectile code
            {
                //if (npc.justHit)
                //    npc.ai[2] = 0f; // reset throw countdown when hit
                //#region Projectiles
                //customAi1 += (Main.rand.Next(2, 5) * 0.1f) * npc.scale;
                //if (customAi1 >= 10f)
                //{
                //    npc.TargetClosest(true);
                //    if (Collision.CanHit(npc.position, npc.width, npc.height, Main.player[npc.target].position, Main.player[npc.target].width, Main.player[npc.target].height))
                //    {
                //        if (Main.rand.Next(40) == 1)
                //        {
                //            float num48 = 8f;
                //            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                //            float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                //            float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                //            if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                //            {
                //                Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                //                float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                //                num51 = num48 / num51;
                //                speedX *= num51;
                //                speedY *= num51;
                //                int damage = 33;
                //                int type = mod.ProjectileType("OmnirsEnemySpear");
                //                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                //                Main.projectile[num54].timeLeft = 100;
                //                Main.projectile[num54].aiStyle = 1;
                //                customAi1 = 1f;
                //            }
                //            npc.netUpdate = true;
                //        }
                //    }
                //}
                //#endregion


                if (npc.justHit)
                    npc.ai[2] = 0f; // reset throw countdown when hit
                if (npc.confused)
                    npc.ai[2] = 0f; // won't try to stop & aim if confused
                else // not confused
                {
                    if (npc.ai[1] > 0f)
                        npc.ai[1] -= 1f; // decrement fire & reload counter

                    if (npc.justHit) // was just hit?
                    {
                        npc.ai[1] = 30f; // shot on .5 sec cooldown
                        npc.ai[2] = 0f; // not aiming
                    }
                    if (npc.ai[2] > 0f) // if aiming: adjust aim and fire if needed
                    {
                        npc.TargetClosest(true); // target and face closest player
                        if (npc.ai[1] == (float)(shot_rate / 2))  //  fire at halfway through; first half of delay is aim, 2nd half is cooldown
                        { // firing:

                            Vector2 npc_center = new Vector2(npc.position.X + (float)npc.width * 0.5f, npc.position.Y + (float)npc.height * 0.5f); // npc position
                            float npc_to_target_x = Main.player[npc.target].position.X + (float)Main.player[npc.target].width * 0.5f - npc_center.X; // x vector to target
                            float num16 = Math.Abs(npc_to_target_x) * 0.1f; // 10% of x distance to target: to aim high if farther?
                            float npc_to_target_y = Main.player[npc.target].position.Y + (float)Main.player[npc.target].height * 0.5f - npc_center.Y - num16; // y vector to target (aiming high at distant targets)
                            npc_to_target_x += (float)Main.rand.Next(-40, 41); //  targeting error: 40 pix=2.5 blocks
                            npc_to_target_y += (float)Main.rand.Next(-40, 41); //  targeting error: 40 pix=2.5 blocks
                            float target_dist = (float)Math.Sqrt((double)(npc_to_target_x * npc_to_target_x + npc_to_target_y * npc_to_target_y)); // distance to target
                            npc.netUpdate = true; // ??
                            target_dist = projectile_velocity / target_dist; // to normalize by projectile_velocity
                            npc_to_target_x *= target_dist; // normalize by projectile_velocity
                            npc_to_target_y *= target_dist; // normalize by projectile_velocity
                            npc_center.X += npc_to_target_x;  //  initial projectile position includes one tick of initial movement
                            npc_center.Y += npc_to_target_y;  //  initial projectile position includes one tick of initial movement
                            if (Main.netMode != 1)  //  is server
                                Projectile.NewProjectile(npc_center.X, npc_center.Y, npc_to_target_x, npc_to_target_y, projectile_id, projectile_damage, 0f, Main.myPlayer);

                            if (Math.Abs(npc_to_target_y) > Math.Abs(npc_to_target_x) * 2f) // target steeply above/below NPC
                            {
                                if (npc_to_target_y > 0f)
                                    npc.ai[2] = 1f; // aim downward
                                else
                                    npc.ai[2] = 5f; // aim upward
                            }
                            else if (Math.Abs(npc_to_target_x) > Math.Abs(npc_to_target_y) * 2f) // target on level with NPC
                                npc.ai[2] = 3f;  //  aim straight ahead
                            else if (npc_to_target_y > 0f) // target is below NPC
                                npc.ai[2] = 2f;  //  aim slight downward
                            else // target is not below NPC
                                npc.ai[2] = 4f;  //  aim slight upward
                        } // END firing
                        if (npc.velocity.Y != 0f || npc.ai[1] <= 0f) // jump/fall or firing reload
                        {
                            npcAcSPD = 0.6f; //How fast they accelerate.
                            npcSPD = 2.5f; //Max speed

                            npcEnrAcSPD = .8f; //How fast they accelerate.
                            npcEnrSPD = 2.8f; //Max speed
                            npc.ai[2] = 0f; // not aiming
                            npc.ai[1] = 0f; // reset firing/reload counter (necessary? nonzero maybe)
                        }
                        else // no jump/fall and no firing reload
                        {
                            //npc.velocity.X = npc.velocity.X * 0.9f; // decelerate to stop & shoot
                            npcAcSPD = 0f; //How fast they accelerate.
                            npcSPD = 0f; //Max speed

                            npcEnrAcSPD = 0f; //How fast they accelerate.
                            npcEnrSPD = 0f; //Max speed
                            npc.spriteDirection = npc.direction; // match animation to facing
                        }
                    } // END if aiming: adjust aim and fire if needed
                    if (npc.ai[2] <= 0f && npc.velocity.Y == 0f && npc.ai[1] <= 0f && !Main.player[npc.target].dead && Collision.CanHit(npc.position, npc.width, npc.height, Main.player[npc.target].position, Main.player[npc.target].width, Main.player[npc.target].height))
                    { // not aiming & no jump/fall & fire/reload ctr is 0 & target is alive and LOS to target: start aiming
                        float num21 = 10f; // dummy vector length in place of initial velocity? not sure why this is needed
                        Vector2 npc_center = new Vector2(npc.position.X + (float)npc.width * 0.5f, npc.position.Y + (float)npc.height * 0.5f);
                        float npc_to_target_x = Main.player[npc.target].position.X + (float)Main.player[npc.target].width * 0.5f - npc_center.X;
                        float num23 = Math.Abs(npc_to_target_x) * 0.1f; // 10% of x distance to target: to aim high if farther?
                        float npc_to_target_y = Main.player[npc.target].position.Y + (float)Main.player[npc.target].height * 0.5f - npc_center.Y - num23; // y vector to target (aiming high at distant targets)
                        npc_to_target_x += (float)Main.rand.Next(-40, 41);
                        npc_to_target_y += (float)Main.rand.Next(-40, 41);
                        float target_dist = (float)Math.Sqrt((double)(npc_to_target_x * npc_to_target_x + npc_to_target_y * npc_to_target_y));
                        if (target_dist < 700f) // 700 pix = 43.75 blocks
                        { // target is in range
                            npc.netUpdate = true; // ??
                            npc.velocity.X = npc.velocity.X * 0.5f; // hard brake
                            target_dist = num21 / target_dist; // to normalize by num21
                            npc_to_target_x *= target_dist; // normalize by num21
                            npc_to_target_y *= target_dist; // normalize by num21
                            npc.ai[2] = 3f; // aim straight ahead
                            npc.ai[1] = (float)shot_rate; // start fire & reload counter
                            if (Math.Abs(npc_to_target_y) > Math.Abs(npc_to_target_x) * 2f) // target steeply above/below NPC
                            {
                                if (npc_to_target_y > 0f)
                                    npc.ai[2] = 1f; // aim downward
                                else
                                    npc.ai[2] = 5f; // aim upward
                            }
                            else if (Math.Abs(npc_to_target_x) > Math.Abs(npc_to_target_y) * 2f) // target on level with NPC
                                npc.ai[2] = 3f; // aim straight ahead
                            else if (npc_to_target_y > 0f)
                                npc.ai[2] = 2f; // aim slight downward
                            else
                                npc.ai[2] = 4f; // aim slight upward
                        } // END target is in range
                    } // END start aiming
                }
            }
            #endregion
            if (npc.velocity.Y == 0f && Main.rand.Next(550) == 1)
            {
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                float rotation = (float)Math.Atan2(vector8.Y - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), vector8.X - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                npc.velocity.X = (float)(Math.Cos(rotation) * 7) * -1;
                npc.velocity.Y = (float)(Math.Sin(rotation) * 7) * -1;
                npc.localAI[3] = 1f;
                npc.netUpdate = true;
            }
		}
        #region Gore
        public override void NPCLoot()
        {
            Color color = new Color();
            Rectangle rectangle = new Rectangle((int)npc.position.X, (int)(npc.position.Y + ((npc.height - npc.width) / 2)), npc.width, npc.width);
            int count = 30;
            for (int i = 1; i <= count; i++)
            {
                int dust = Dust.NewDust(npc.position, rectangle.Width, rectangle.Height, 6, 0, 0, 100, color, 1.5f);
                Main.dust[dust].noGravity = false;
            }
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsManHunterGore1"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsManHunterGore2"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsManHunterGore2"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsManHunterGore3"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsManHunterGore3"), 1f);

            if (Main.rand.Next(13) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsLongBow"));
            }
        }
        #endregion
    }
}
