using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OmnirsNosPak.NPCs.Tibia.Quara
{
	public class OmnirsQuaraPredator : ModNPC
	{
        float customAi1;
        int OTimeLeft = 2000;
        bool walkAndShoot = false;

        bool canDrown = false;
        int drownTimerMax = 2000;
        int drownTimer = 2000;
        int drowningRisk = 1200;

        float npcAcSPD = 0.8f; //How fast they accelerate.
        float npcSPD = 1.5f; //Max speed

        bool tooBig = true;
        bool lavaJumping = false;

        float npcEnrAcSPD = 1.0f; //How fast they accelerate.
        float npcEnrSPD = 2.0f; //Max speed
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Quara Predator");
			Main.npcFrameCount[npc.type] = 15;
		}
        public override void SetDefaults()
		{
			npc.width = 18;
			npc.height = 45;
			npc.damage = 45;
			npc.defense = 12;
			npc.lifeMax = 2200;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
            npc.value = 1800f;
			npc.npcSlots = 100;
            npc.scale = 1.2f;
			npc.knockBackResist = 0.8f;
			animationType = 21;
		}
        public override float SpawnChance(NPCSpawnInfo s)
        {
            int x = s.spawnTileX;
            int y = s.spawnTileY;
            bool oSky = (y < (Main.maxTilesY * 0.1f));
            bool oSurface = (y >= (Main.maxTilesY * 0.1f) && y < (Main.maxTilesY * 0.2f));
            bool oUnderSurface = (y >= (Main.maxTilesY * 0.2f) && y < (Main.maxTilesY * 0.3f));
            bool oUnderground = (y >= (Main.maxTilesY * 0.3f) && y < (Main.maxTilesY * 0.4f));
            bool oCavern = (y >= (Main.maxTilesY * 0.4f) && y < (Main.maxTilesY * 0.6f));
            bool oMagmaCavern = (y >= (Main.maxTilesY * 0.6f) && y < (Main.maxTilesY * 0.8f));
            bool oUnderworld = (y >= (Main.maxTilesY * 0.8f));
            bool oOcean = (x <= (Main.maxTilesX * .2f) && x < (Main.maxTilesX * 0.8f) && y < (Main.maxTilesY * 0.4f));
            int tile = (int)Main.tile[x, y].type;
            Player p = s.player;
            if (Main.pumpkinMoon || Main.snowMoon || p.townNPCs > 0f || p.ZoneDungeon)
            {
                return 0f;
            }
            if (oOcean)
            {
                if (oSurface || oUnderSurface || oUnderground)
                {
                    if (Main.rand.Next(450) == 1) return 1f;
                    else if ((oUnderSurface || oUnderground) && Main.rand.Next(145) == 1) return 1f;
                    if (Main.hardMode)
                    {
                        if (Main.rand.Next(19) == 1) return 1f;
                        else if ((oUnderSurface || oUnderground) && Main.rand.Next(12) == 1) return 1f;
                        return 0f;
                    }
                    return 0f;
                }
                return 0f;
            }
            return 0f;
        }
        //Spawns in the Ocean down into the Underground. Does not spawn in the Dungeon, Meteor, or if there are Town NPCs.

        public void teleport(bool pre)
		{
			if (Main.netMode != 2)
			{
				Main.PlaySound(2, (int)npc.Center.X, (int)npc.Center.Y, 8);
				for (int m = 0; m < 25; m++)
				{
					int dustID = Dust.NewDust(npc.position, npc.width, npc.height, 6, 0, 0, 100, Color.White, 2f);
					Main.dust[dustID].noGravity = true;
					Main.dust[dustID].velocity = new Vector2(MathHelper.Lerp(-1f, 1f, (float)Main.rand.NextDouble()), MathHelper.Lerp(-1f, 1f, (float)Main.rand.NextDouble()));
					Main.dust[dustID].velocity *= 7f;
				}
			}
		}
		public override void AI()  //  warrior ai
		{


            bool enraged = (npc.life < (float)npc.lifeMax*.2f);  //  speed up at low life
			int shotRate = enraged?100:70;
			float accel=enraged? npcEnrAcSPD:npcAcSPD;  //  how fast it can speed up
			float topSpeed=enraged? npcEnrSPD:npcSPD;  //  max walking speed, also affects jump length
			MNPC.teleporterAI
			(
				npc, 
				ref npc.ai, 
				false, 		// immobile		Whether or not this NPC should move while its teleporting.
				20, 		// tpRadius		Radius around the player where the NPC will try to move.
				13,			// distToPlayer	Minimum distance to keep from the player as the NPC teleports.
				60,			// tpInterval	How often the NPC will try to teleport, tied to npc.ai[3].
				true, 		// aerial		Whether or not an NPC will try to move to an airborne position.
				teleport	// tpEffect		The effect that the NPC will create as it moves.
			);
			MNPC.fighterAI
			(
				npc, 
				ref npc.ai,
				false,		// nocturnal  	If true, flees when it is daytime.
				true,		// focused 		If true, npc wont get interrupted when hit or confused.
				60, 		// boredom 		The amount of ticks until the npc gets 'bored' following a target.
				2, 			// knockPower 	0 == do not interact with doors, attempt to open the doors by this value, negative numbers will break instead
				accel, 		// accel 		The rate velocity X increases by when moving.
				topSpeed,	// topSpeed 	the maximum velocity on the X axis.
				2, 			// leapReq 		-1 npc wont jump over gaps, more than 0 npc will leap at players
				5, 			// leapSpeed	The max tiles it can jump across and over, horizontally. 
				9, 			// leapHeight 	The max tiles it can jump across and over, vertically. 
				100,		// leapRangeX 	The distance from a player before the npc initiates leap, horizontally. 
				50,			// leapRangeY 	The distance from a player before the npc initiates leap, vertically. 
				0, 			// shotType 	If higher than 0, allows an npc to fire a projectile, archer style.
				40,			// shotRate 	The rate of fire of the projectile, if there is one.
				70,			// shotPow 		The projectile's damage, if -1 it will use the projectile's default.
				14			// shotSpeed	The projectile's velocity.
			);
            Vector2 angle = Main.player[npc.target].Center - npc.Center;
            angle.Y = angle.Y - (Math.Abs(angle.X) * .1f);
            angle.X += (float)Main.rand.Next(-20, 21);
            angle.Y += (float)Main.rand.Next(-20, 21);
            angle.Normalize();
			float distance = npc.Distance(Main.player[npc.target].Center);
            #region shoot and walk
            if (Main.netMode != 1 && !Main.player[npc.target].dead) // can generalize this section to moving+projectile code // can generalize this section to moving+projectile code
            {
                if (npc.justHit)
                    npc.ai[2] = 0f; // reset throw countdown when hit
                #region Projectiles
                customAi1 += (Main.rand.Next(2, 5) * 0.1f) * npc.scale;
                if (customAi1 >= 10f)
                {
                    npc.TargetClosest(true);
                    if (Main.rand.Next(100) == 1)
                    {
                        npc.ai[3] = 1;
                        npc.life += 5;
                        if (npc.life > npc.lifeMax) npc.life = npc.lifeMax; npc.ai[3] = 1;
                        Main.player[npc.target].statLife -= 2;
                        float num48 = 8f;
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                        float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                        float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                        if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                        {
                            Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                            float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                            num51 = num48 / num51;
                            speedX *= num51;
                            speedY *= num51;
                            int damage = 0;
                            int type = mod.ProjectileType("OmnirsEnemySpellEffectHealing");
                            int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                            Main.projectile[num54].timeLeft = 1;
                            Main.projectile[num54].aiStyle = -1;
                            customAi1 = 1f;
                        }
                        npc.netUpdate = true;
                    }
                    //if (Collision.CanHit(npc.position, npc.width, npc.height, Main.player[npc.target].position, Main.player[npc.target].width, Main.player[npc.target].height))
                    //{
                    //    if (Main.rand.Next(300) == 1)
                    //    {
                    //        float num48 = 8f;
                    //        Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                    //        float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                    //        float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                    //        if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                    //        {
                    //            Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                    //            float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                    //            num51 = num48 / num51;
                    //            speedX *= num51;
                    //            speedY *= num51;
                    //            int damage = 50;
                    //            int type = mod.ProjectileType("OmnirsEnemySpellGreatEnergyBall");
                    //            int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                    //            Main.projectile[num54].timeLeft = 100;
                    //            Main.projectile[num54].aiStyle = -1;
                    //            customAi1 = 1f;
                    //        }
                    //        npc.netUpdate = true;
                    //    }
                    //    if (Main.rand.Next(100) == 1)
                    //    {
                    //        npc.ai[3] = 1;
                    //        npc.life += 5;
                    //        if (npc.life > npc.lifeMax) npc.life = npc.lifeMax; npc.ai[3] = 1;
                    //        Main.player[npc.target].statLife -= 2;
                    //        if (Main.player[npc.target].statLife < 0) Main.player[npc.target].statLife = 0;
                    //        float num48 = 8f;
                    //        Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                    //        float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                    //        float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                    //        if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                    //        {
                    //            Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                    //            float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                    //            num51 = num48 / num51;
                    //            speedX *= num51;
                    //            speedY *= num51;
                    //            int damage = 0;
                    //            int type = mod.ProjectileType("OmnirsEnemySpellEffectHealing");
                    //            int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                    //            Main.projectile[num54].timeLeft = 1;
                    //            Main.projectile[num54].aiStyle = -1;
                    //            customAi1 = 1f;
                    //        }
                    //        npc.netUpdate = true;
                    //    }
                    //    if (Main.rand.Next(100) == 1)
                    //    {
                    //        float num48 = 8f;
                    //        Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                    //        float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                    //        float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                    //        if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                    //        {
                    //            Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                    //            float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                    //            num51 = num48 / num51;
                    //            speedX *= num51;
                    //            speedY *= num51;
                    //            int damage = 90;
                    //            int type = mod.ProjectileType("OmnirsEnemySpellGreatEnergyBeamBall");
                    //            int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                    //            Main.projectile[num54].timeLeft = 1;
                    //            Main.projectile[num54].aiStyle = -1;
                    //            customAi1 = 1f;
                    //        }
                    //        npc.netUpdate = true;
                    //    }
                    //}
                }
                #endregion
                #region Charge
                if (npc.velocity.Y == 0f && Main.rand.Next(550) == 1)
                {
                    Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                    float rotation = (float)Math.Atan2(vector8.Y - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), vector8.X - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                    npc.velocity.X = (float)(Math.Cos(rotation) * 7) * -1;
                    npc.velocity.Y = (float)(Math.Sin(rotation) * 7) * -1;
                    npc.ai[1] = 1f;
                    npc.netUpdate = true;
                }
                #endregion
            }
            #endregion
            if (npc.velocity.Y == 0f && Main.rand.Next(550) == 1)
            {
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                float rotation = (float)Math.Atan2(vector8.Y - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), vector8.X - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                npc.velocity.X = (float)(Math.Cos(rotation) * 7) * -1;
                npc.velocity.Y = (float)(Math.Sin(rotation) * 7) * -1;
                npc.localAI[3] = 1f;
                npc.netUpdate = true;
            }
		}
        #region Gore
        public override void NPCLoot()
        {
            Color color = new Color();
            Rectangle rectangle = new Rectangle((int)npc.position.X, (int)(npc.position.Y + ((npc.height - npc.width) / 2)), npc.width, npc.width);
            int count = 30;
            for (int i = 1; i <= count; i++)
            {
                int dust = Dust.NewDust(npc.position, rectangle.Width, rectangle.Height, 6, 0, 0, 100, color, 1.5f);
                Main.dust[dust].noGravity = false;
            }
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsQuaraPredatorGore1"), 1.2f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsQuaraPredatorGore2"), 1.2f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsQuaraPredatorGore2"), 1.2f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsQuaraPredatorGore3"), 1.2f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsQuaraPredatorGore3"), 1.2f);

            //if (Main.rand.Next(3) == 0)
            //{
            //    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsGreatFireballRune"), Main.rand.Next(1, 20));
            //}
            if (Main.rand.Next(5) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsWarriorHelmet"));
            }
            if (Main.rand.Next(10) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsDoubleAxe"));
            }
        }
        #endregion
    }
}
