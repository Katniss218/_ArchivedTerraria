//using Microsoft.Xna.Framework;
//using Terraria;
//using Terraria.ID;
//using Terraria.ModLoader;
//using Microsoft.Xna.Framework.Graphics;
//using Microsoft.Xna.Framework.Input;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace OmnirsNosPak.NPCs.Tibia.Demons
//{
//	public class OmnirsOrshabaalsTunnel : ModNPC
//	{
//        float customAi1;
//        float customspawn1;
//        int oTStage = 0;
//        public override void SetDefaults()
//		{
//			npc.name = "Orshabaal's Tunnel";
//			npc.displayName = "Orshabaal's Tunnel";
//			npc.width = 100;
//			npc.height = 100;
//			npc.damage = 0;
//			npc.defense = 0;
//			npc.lifeMax = 500;
//            npc.HitSound = SoundID.NPCHit1;
//            npc.DeathSound = SoundID.NPCDeath5;
//            npc.value = 41000f;
//			npc.npcSlots = 100;
//			npc.knockBackResist = 0.1f;
//			Main.npcFrameCount[npc.type] = 7;
//			animationType = -1;
//			npc.lavaImmune = true;
//			npc.buffImmune[BuffID.Venom] = true;
//			npc.buffImmune[BuffID.Confused] = true;
//			npc.buffImmune[BuffID.CursedInferno] = true;
//			npc.buffImmune[BuffID.OnFire] = true;
//		}
//        public override float CanSpawn(NPCSpawnInfo s)
//        {
//            int x = s.spawnTileX;
//            int y = s.spawnTileY;
//            bool oSky = (y < (Main.maxTilesY * 0.1f));
//            bool oSurface = (y >= (Main.maxTilesY * 0.1f) && y < (Main.maxTilesY * 0.2f));
//            bool oUnderSurface = (y >= (Main.maxTilesY * 0.2f) && y < (Main.maxTilesY * 0.3f));
//            bool oUnderground = (y >= (Main.maxTilesY * 0.3f) && y < (Main.maxTilesY * 0.4f));
//            bool oCavern = (y >= (Main.maxTilesY * 0.4f) && y < (Main.maxTilesY * 0.6f));
//            bool oMagmaCavern = (y >= (Main.maxTilesY * 0.6f) && y < (Main.maxTilesY * 0.8f));
//            bool oUnderworld = (y >= (Main.maxTilesY * 0.8f));
//            if (player.townNPCs >= 2f || Main.pumpkinMoon || Main.snowMoon || !NPC.downedMechBossAny)
//            {
//                return 0f;
//            }
//            if ((oSurface || oUnderSurface) && (x > Main.maxTilesX * 0.70f && x < Main.maxTilesX * 0.80f))
//            {
//                if (Main.rand.Next(5000) == 1) return 1f;
//                else if (NPC.downedPlantBoss && Main.rand.Next(500) == 1) return 1f;
//                else if (NPC.downedGolemBoss && Main.rand.Next(50) == 1) return 1f;
//                return 0f;
//            }
//            return 0f;
//        }
//        //Spawns on the Hardmode Surface, between 7/10th and 8.5/10th (Width).

//        public void teleport(bool pre)
//		{
//			if (Main.netMode != 2)
//			{
//				Main.PlaySound(2, (int)npc.Center.X, (int)npc.Center.Y, 8);
//				for (int m = 0; m < 25; m++)
//				{
//					int dustID = Dust.NewDust(npc.position, npc.width, npc.height, 6, 0, 0, 100, Color.White, 2f);
//					Main.dust[dustID].noGravity = true;
//					Main.dust[dustID].velocity = new Vector2(MathHelper.Lerp(-1f, 1f, (float)Main.rand.NextDouble()), MathHelper.Lerp(-1f, 1f, (float)Main.rand.NextDouble()));
//					Main.dust[dustID].velocity *= 7f;
//				}
//			}
//		}
//		public override void AI()  //  warrior ai
//		{
//            #region Ogre/custom frames
//            int num = 1;
//            if (!Main.dedServ)
//            {
//                num = 114;
//            }
//            if (npc.velocity.Y == 0f)
//            {
//                if (npc.direction == 1)
//                {
//                    npc.spriteDirection = 1;
//                }
//                if (npc.direction == -1)
//                {
//                    npc.spriteDirection = -1;
//                }
//                if (npc.velocity.X == 0f)
//                {
//                    if (npc.type == 140)
//                    {
//                        npc.frame.Y = num;
//                        npc.frameCounter = 0.0;
//                    }
//                    else
//                    {
//                        npc.frame.Y = 0;
//                        npc.frameCounter = 0.0;
//                    }
//                }
//                else
//                {
//                    npc.frameCounter += (double)(Math.Abs(npc.velocity.X) * 2f);
//                    npc.frameCounter += 1.0;
//                    if (npc.frameCounter > 6.0)
//                    {
//                        npc.frame.Y = npc.frame.Y + num;
//                        npc.frameCounter = 0.0;
//                    }
//                    if (npc.frame.Y / num >= Main.npcFrameCount[npc.type])
//                    {
//                        npc.frame.Y = num * 2;
//                    }
//                }
//            }
//            else
//            {
//                npc.frameCounter = 0.0;
//                npc.frame.Y = num;
//                npc.frame.Y = 0;
//            }
//            #endregion
//            if (customspawn1 < 1)
//            {
//                oTStage++;
//                if (oTStage == 60)
//                {
//                    Main.NewText("A tunnel appeared, and begins to widen.", 175, 75, 255);
//                    Main.PlaySound(1, (int)npc.position.X, (int)npc.position.Y, 5);
//                }
//                else if (oTStage == 300)
//                {
//                    Main.NewText("The demon lord Orshabaal begins to tear through the tunnel.", 175, 75, 255);
//                    Main.PlaySound(1, (int)npc.position.X, (int)npc.position.Y, 5);
//                }
//                else if (oTStage == 600)
//                {
//                    int Spawned = NPC.NewNPC((int)npc.Center.X, (int)npc.Center.Y, "OmnirsOrshabaal", 0);
//                    npc.ai[0] = 20 - Main.rand.Next(80);
//                    customspawn1 += 1f;
//                    Main.NewText("The demon lord Orshabaal has come.", 175, 75, 255);
//                    Main.PlaySound(1, (int)npc.position.X, (int)npc.position.Y, 5);
//                }
//            }
//            return;
//        }
//    }
//}
