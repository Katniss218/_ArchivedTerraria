using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.NPCs.Tibia
{
    public class OmnirsPoisonSpider : ModNPC //amazing help from Cheezemaniac
    {
        float customAi1;
        int movedTowards = 0;
        int num94 = 0;
        int num95 = 0;
        int noJump = 0;
        int OTimeLeft = 2000;
        bool walkAndShoot = true;

        bool canDrown = false;
        int drownTimerMax = 10000;
        int drownTimer = 10000;
        int drowningRisk = 3000;

        float npcAcSPD = 0.05f; //How fast they accelerate.
        float npcSPD = 1.5f; //Max speed

        bool tooBig = true;
        bool lavaJumping = false;

        #region Spawn
        public override float SpawnChance(NPCSpawnInfo s)
        {
            int x = s.spawnTileX;
            int y = s.spawnTileY;
            bool oSky = (y < (Main.maxTilesY * 0.1f));
            bool oSurface = (y >= (Main.maxTilesY * 0.1f) && y < (Main.maxTilesY * 0.2f));
            bool oUnderSurface = (y >= (Main.maxTilesY * 0.2f) && y < (Main.maxTilesY * 0.3f));
            bool oUnderground = (y >= (Main.maxTilesY * 0.3f) && y < (Main.maxTilesY * 0.4f));
            bool oCavern = (y >= (Main.maxTilesY * 0.4f) && y < (Main.maxTilesY * 0.6f));
            bool oMagmaCavern = (y >= (Main.maxTilesY * 0.6f) && y < (Main.maxTilesY * 0.8f));
            bool oUnderworld = (y >= (Main.maxTilesY * 0.8f));
            bool oBorders = (y < (Main.maxTilesY * 0.03f) || x < (Main.maxTilesX * 0.03f) || y > (Main.maxTilesY * 0.97f) || x > (Main.maxTilesX * 0.97f));
            int tile = (int)Main.tile[x, y].type;
            Player p = s.player;
            if (Main.pumpkinMoon || Main.snowMoon || Main.hardMode || p.townNPCs > 0f || p.ZoneJungle || p.ZoneDungeon || p.ZoneMeteor || oBorders)
            {
                return 0f;
            }
            if ((oSurface || oUnderSurface || oUnderground) && Main.rand.Next(5) == 1) return 1f;
            return 0f;
        }
        //Spawns on the Surface and Underground in the Jungle. Does not spawn in Hardmode, if Town NPCs are nearby, or if Player reaches more than 140 health.
        #endregion

		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Poison Spider");
			Main.npcFrameCount[npc.type] = 9;
		}
		public override void SetDefaults()
        {
            npc.lifeMax = 26;
            npc.damage = 6;
            npc.defense = 3;
            npc.knockBackResist = 0.5f;
            npc.width = 20;
            npc.height = 40;
            npc.aiStyle = 3; // Copied Zombie AI to get behavior.
            npc.DeathSound = SoundID.NPCDeath1;
            npc.HitSound = SoundID.NPCHit1;
            npc.value = Item.buyPrice(0, 0, 0, 20);
            animationType = -1;
            //banner = npc.type;
            //bannerItem = mod.ItemType("Troll");
        }

        public override void AI()
        {
            #region Ogre/custom frames
            int num = 1;
            if (!Main.dedServ)
            {
                num = 36;
            }
            if (npc.velocity.Y == 0f)
            {
                if (npc.direction == 1)
                {
                    npc.spriteDirection = 1;
                }
                if (npc.direction == -1)
                {
                    npc.spriteDirection = -1;
                }
                if (npc.velocity.X == 0f)
                {
                    if (npc.type == 140)
                    {
                        npc.frame.Y = num;
                        npc.frameCounter = 0.0;
                    }
                    else
                    {
                        npc.frame.Y = 0;
                        npc.frameCounter = 0.0;
                    }
                }
                else
                {
                    npc.frameCounter += (double)(Math.Abs(npc.velocity.X) * 2f);
                    npc.frameCounter += 1.0;
                    if (npc.frameCounter > 6.0)
                    {
                        npc.frame.Y = npc.frame.Y + num;
                        npc.frameCounter = 0.0;
                    }
                    if (npc.frame.Y / num >= Main.npcFrameCount[npc.type])
                    {
                        npc.frame.Y = num * 2;
                    }
                }
            }
            else
            {
                npc.frameCounter = 0.0;
                npc.frame.Y = num;
                npc.frame.Y = 0;
            }
            #endregion
            npc.noGravity = false;
            npc.spriteDirection = npc.direction;
            #region shoot and walk
            if (walkAndShoot && Main.netMode != 1 && !Main.player[npc.target].dead) // can generalize this section to moving+projectile code // can generalize this section to moving+projectile code
            {
            }
            #endregion
            #region drown // code by Omnir
            if (canDrown)
            {
                if (!npc.wet)
                {
                    npc.TargetClosest(true);
                    drownTimer = drownTimerMax;
                }
                if (npc.wet)
                {
                    drownTimer--;
                }
                if (npc.wet && drownTimer > drowningRisk)
                {
                    npc.TargetClosest(true);
                }
                else if (npc.wet && drownTimer <= drowningRisk)
                {
                    npc.TargetClosest(false);
                    if (npc.timeLeft > 10)
                    {
                        npc.timeLeft = 10;
                    }
                    npc.directionY = -1;
                    if (npc.velocity.Y > 0f)
                    {
                        npc.direction = 1;
                    }
                    npc.direction = -1;
                    if (npc.velocity.X > 0f)
                    {
                        npc.direction = 1;
                    }
                }
                if (drownTimer <= 0)
                {
                    npc.life--;
                    if (npc.life <= 0)
                    {
                        Main.PlaySound(4, (int)npc.position.X, (int)npc.position.Y, 1);
                        npc.NPCLoot();
                        npc.netUpdate = true;
                    }
                }
            }
            #endregion
            #region Too Big and Lava Jumping
            if (tooBig)
            {
                if (npc.velocity.Y == 0f && (npc.velocity.X == 0f && npc.direction < 0))
                {
                    npc.velocity.Y -= 8f;
                    npc.velocity.X -= npcSPD;
                }
                else if (npc.velocity.Y == 0f && (npc.velocity.X == 0f && npc.direction > 0))
                {
                    npc.velocity.Y -= 8f;
                    npc.velocity.X += npcSPD;
                }
            }
            if (lavaJumping)
            {
                if (npc.lavaWet)
                {
                    npc.velocity.Y -= 2;
                }
            }
            #endregion
        }
        #region Gore
        public override void NPCLoot()
        {
            Color color = new Color();
            Rectangle rectangle = new Rectangle((int)npc.position.X, (int)(npc.position.Y + ((npc.height - npc.width) / 2)), npc.width, npc.width);
            int count = 30;
            for (int i = 1; i <= count; i++)
            {
                int dust = Dust.NewDust(npc.position, rectangle.Width, rectangle.Height, 6, 0, 0, 100, color, 1.5f);
                Main.dust[dust].noGravity = false;
            }
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsPoisonSpiderGore1"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsPoisonSpiderGore2"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsPoisonSpiderGore2"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsPoisonSpiderGore2"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsPoisonSpiderGore2"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsPoisonSpiderGore2"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsPoisonSpiderGore2"), 1f);
        }
        #endregion
    }
}