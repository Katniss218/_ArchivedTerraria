using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace OmnirsNosPak.NPCs.Generic
{
    public class OmnirsDwarvenAxeman : ModNPC //amazing help from Cheezemaniac
    {
        float customAi1;
        int OTimeLeft = 2000;
        bool walkAndShoot = false;

        bool canDrown = true;
        int drownTimerMax = 2000;
        int drownTimer = 2000;
        int drowningRisk = 1200;

        float npcAcSPD = 0.7f; //How fast they accelerate.
        float npcSPD = 1.6f; //Max speed

        bool tooBig = false;
        bool lavaJumping = false;
        float npcEnrAcSPD = 0.8f; //How fast they accelerate.
        float npcEnrSPD = 1.8f; //Max speed 

        #region Spawn
        public override float SpawnChance(NPCSpawnInfo s)
        {
            int x = s.spawnTileX;
            int y = s.spawnTileY;
            bool oSky = (y < (Main.maxTilesY * 0.1f));
            bool oSurface = (y >= (Main.maxTilesY * 0.1f) && y < (Main.maxTilesY * 0.2f));
            bool oUnderSurface = (y >= (Main.maxTilesY * 0.2f) && y < (Main.maxTilesY * 0.3f));
            bool oUnderground = (y >= (Main.maxTilesY * 0.3f) && y < (Main.maxTilesY * 0.4f));
            bool oCavern = (y >= (Main.maxTilesY * 0.4f) && y < (Main.maxTilesY * 0.6f));
            bool oMagmaCavern = (y >= (Main.maxTilesY * 0.6f) && y < (Main.maxTilesY * 0.8f));
            bool oUnderworld = (y >= (Main.maxTilesY * 0.8f));
            bool oOcean = (x <= (Main.maxTilesX * .2f) && x < (Main.maxTilesX * 0.8f) && y < (Main.maxTilesY * 0.4f));
            int tile = (int)Main.tile[x, y].type;
            Player p = s.player;
            if (Main.pumpkinMoon || Main.snowMoon || Main.hardMode || p.townNPCs > 0f || p.ZoneDungeon || p.ZoneJungle || p.ZoneMeteor)
            {
                return 0f;
            }
            if (oSurface || oUnderSurface || oUnderground || oCavern)
            {
                if (x > Main.maxTilesX * 0.65f && Main.rand.Next(28) == 1) return 1f;
                if (oUnderground && x > Main.maxTilesX * 0.65f && Main.rand.Next(12) == 1) return 1f;
                return 0f;
            }
            return 0f;
        }
        //Spawns on the Surface and into the Cavern past 6.9/10th (Width). Does not spawn in the Jungle, Hardmode, Dungeons, Meteor, or if there are Town NPCs.        
        #endregion
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Dwarven Axeman");
			Main.npcFrameCount[npc.type] = 15;
		}
        public override void SetDefaults()
        {
            npc.lifeMax = 80;
            npc.damage = 25;
            npc.defense = 12;
            npc.knockBackResist = 0.4f;
            npc.width = 18;
            npc.height = 36;
            npc.aiStyle = 3; // Copied Zombie AI to get behavior.
            npc.DeathSound = SoundID.NPCDeath1;
            npc.HitSound = SoundID.NPCHit1;
            npc.value = Item.buyPrice(0, 0, 10, 00);
            animationType = 21;
            //banner = npc.type;
            //bannerItem = mod.ItemType("Troll");
        }

        public override void AI()  //  warrior ai
        {
            bool enraged = (npc.life < (float)npc.lifeMax * .2f);  //  speed up at low life
            int shotRate = enraged ? 100 : 70;
            float accel = enraged ? npcEnrAcSPD : npcAcSPD;  //  how fast it can speed up
            float topSpeed = enraged ? npcEnrSPD : npcSPD;  //  max walking speed, also affects jump length
            MNPC.fighterAI
            (
                npc,
                ref npc.ai,
                false,      // nocturnal  	If true, flees when it is daytime.
                true,       // focused 		If true, npc wont get interrupted when hit or confused.
                60,         // boredom 		The amount of ticks until the npc gets 'bored' following a target.
                2,          // knockPower 	0 == do not interact with doors, attempt to open the doors by this value, negative numbers will break instead
                accel,      // accel 		The rate velocity X increases by when moving.
                topSpeed,   // topSpeed 	the maximum velocity on the X axis.
                2,          // leapReq 		-1 npc wont jump over gaps, more than 0 npc will leap at players
                5,          // leapSpeed	The max tiles it can jump across and over, horizontally. 
                9,          // leapHeight 	The max tiles it can jump across and over, vertically. 
                100,        // leapRangeX 	The distance from a player before the npc initiates leap, horizontally. 
                50,         // leapRangeY 	The distance from a player before the npc initiates leap, vertically. 
                0,          // shotType 	If higher than 0, allows an npc to fire a projectile, archer style.
                40,         // shotRate 	The rate of fire of the projectile, if there is one.
                70,         // shotPow 		The projectile's damage, if -1 it will use the projectile's default.
                14          // shotSpeed	The projectile's velocity.
            );
            Vector2 angle = Main.player[npc.target].Center - npc.Center;
            angle.Y = angle.Y - (Math.Abs(angle.X) * .1f);
            angle.X += (float)Main.rand.Next(-20, 21);
            angle.Y += (float)Main.rand.Next(-20, 21);
            angle.Normalize();
            float distance = npc.Distance(Main.player[npc.target].Center);
            #region shoot and walk
            if (Main.netMode != 1)
            {
                if (npc.justHit)
                    npc.ai[2] = 0f; // reset throw countdown when hit

                #region Projectiles
                customAi1 += (Main.rand.Next(2, 5) * 0.1f) * npc.scale;
                if (customAi1 >= 10f)
                {
                    npc.TargetClosest(true);
                    if (Collision.CanHit(npc.position, npc.width, npc.height, Main.player[npc.target].position, Main.player[npc.target].width, Main.player[npc.target].height))
                    {
                        //if (Main.rand.Next(400) == 1)
                        //{
                        //    float num48 = 8f;
                        //    float aNV1;
                        //    int aNV2;
                        //    if (npc.direction > 0)
                        //    {
                        //        aNV1 = (((npc.width) * 1.1f));
                        //    }
                        //    else
                        //    {
                        //        aNV1 = (((npc.width) * -.1f));
                        //    }
                        //    Vector2 vector8 = new Vector2((npc.position.X + aNV1), npc.position.Y + (npc.height - 75));
                        //    float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                        //    float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                        //    if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                        //    {
                        //        Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                        //        float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                        //        num51 = num48 / num51;
                        //        speedX *= num51;
                        //        speedY *= num51;
                        //        int damage = 0;
                        //        int type = mod.ProjectileType("OmnirsEnemySpellDoomBall");
                        //        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                        //        Main.projectile[num54].timeLeft = 100;
                        //        Main.projectile[num54].aiStyle = -1;
                        //        customAi1 = 1f;
                        //    }
                        //    npc.netUpdate = true;
                        //}
                    }
                }
                #endregion
            }
            #endregion
            if (npc.velocity.Y == 0f && Main.rand.Next(550) == 1)
            {
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                float rotation = (float)Math.Atan2(vector8.Y - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), vector8.X - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                npc.velocity.X = (float)(Math.Cos(rotation) * 7) * -1;
                npc.velocity.Y = (float)(Math.Sin(rotation) * 7) * -1;
                npc.localAI[3] = 1f;
                npc.netUpdate = true;
            }
            #region Too Big and Lava Jumping
            if (tooBig)
            {
                if (npc.velocity.Y == 0f && (npc.velocity.X == 0f && npc.direction < 0))
                {
                    npc.velocity.Y -= 8f;
                    npc.velocity.X -= npcSPD;
                }
                else if (npc.velocity.Y == 0f && (npc.velocity.X == 0f && npc.direction > 0))
                {
                    npc.velocity.Y -= 8f;
                    npc.velocity.X += npcSPD;
                }
            }
            if (lavaJumping)
            {
                if (npc.lavaWet)
                {
                    npc.velocity.Y -= 2;
                }
            }
            #endregion
        }

        #region Gore
        public override void NPCLoot()
        {
            Color color = new Color();
            Rectangle rectangle = new Rectangle((int)npc.position.X, (int)(npc.position.Y + ((npc.height - npc.width) / 2)), npc.width, npc.width);
            int count = 30;
            for (int i = 1; i <= count; i++)
            {
                int dust = Dust.NewDust(npc.position, rectangle.Width, rectangle.Height, 6, 0, 0, 100, color, 1.5f);
                Main.dust[dust].noGravity = false;
            }
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsDwarfGore1"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsDwarfGore2"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsDwarfGore2"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsDwarfGore3"), 1f);
            Gore.NewGore(npc.position, npc.velocity, mod.GetGoreSlot("Gores/OmnirsDwarfGore3"), 1f);

            //if (Main.rand.Next(15) == 0)
            //{
            //    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsSword"));
            //}
            //if (Main.rand.Next(12) == 0)
            //{
            //    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsSabre"));
            //}
            //if (Main.rand.Next(10) == 0)
            //{
            //    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsAxe"));
            //}
            //if (Main.rand.Next(16) == 0)
            //{
            //    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsMace"));
            //}
            //if (Main.rand.Next(20) == 0)
            //{
            //    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsBrassHelmet"));
            //}
            //if (Main.rand.Next(9) == 0)
            //{
            //    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsChainArmor"));
            //}
            //if (Main.rand.Next(9) == 0)
            //{
            //    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsChainGreaves"));
            //}
            //if (Main.rand.Next(9) == 0)
            //{
            //    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsChainCoif"));
            //}
            //if (Main.rand.Next(15) == 0)
            //{
            //    Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsPlateShield"));
            //}
        }
        #endregion
    }
}