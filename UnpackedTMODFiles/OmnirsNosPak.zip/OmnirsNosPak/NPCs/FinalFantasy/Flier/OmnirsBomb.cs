using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OmnirsNosPak.NPCs.FinalFantasy.Flier
{
    public class OmnirsBomb : ModNPC
    {
        float customAi1;
        bool oBombEx = false;
        int OTimeLeft = 2000;
        bool walkAndShoot = true;

        bool canDrown = true;
        int drownTimerMax = 200;
        int drownTimer = 200;
        int drowningRisk = 200;

        float npcAcSPD = 0.55f; //How fast they accelerate.
        float npcSPD = 1.1f; //Max speed

        bool tooBig = false;
        bool lavaJumping = false;

        float npcEnrAcSPD = 0.95f; //How fast they accelerate.
        float npcEnrSPD = 1.5f; //Max speed

        int num;
        int oProAmnt = 0;
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Bomb");
			Main.npcFrameCount[npc.type] = 4;
		}
        public override void SetDefaults()
        {
            npc.width = 38;
            npc.height = 40;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath6;
            npc.value = 500f;
            npc.npcSlots = 100;
            npc.scale = 1f;
            npc.aiStyle = -1;//22;
            npc.knockBackResist = 0.8f;
            animationType = -1;
            npc.damage = 30;
            npc.defense = 10;
            npc.lifeMax = 30;
            npc.lavaImmune = true;
            npc.buffImmune[BuffID.OnFire] = true;
        }
        #region Spawn
        public override float SpawnChance(NPCSpawnInfo s)
        {
            int x = s.spawnTileX;
            int y = s.spawnTileY;
            bool oSky = (y < (Main.maxTilesY * 0.1f));
            bool oSurface = (y >= (Main.maxTilesY * 0.1f) && y < (Main.maxTilesY * 0.2f));
            bool oUnderSurface = (y >= (Main.maxTilesY * 0.2f) && y < (Main.maxTilesY * 0.3f));
            bool oUnderground = (y >= (Main.maxTilesY * 0.3f) && y < (Main.maxTilesY * 0.4f));
            bool oCavern = (y >= (Main.maxTilesY * 0.4f) && y < (Main.maxTilesY * 0.6f));
            bool oMagmaCavern = (y >= (Main.maxTilesY * 0.6f) && y < (Main.maxTilesY * 0.8f));
            bool oUnderworld = (y >= (Main.maxTilesY * 0.8f));
            bool oBorders = (y < (Main.maxTilesY * 0.03f) || x < (Main.maxTilesX * 0.03f) || y > (Main.maxTilesY * 0.97f) || x > (Main.maxTilesX * 0.97f));
            int tile = (int)Main.tile[x, y].type;
            Player p = s.player;
            if (Main.pumpkinMoon || Main.snowMoon || Main.hardMode || p.townNPCs > 0f || p.ZoneDungeon || p.ZoneJungle || p.ZoneMeteor || oBorders)
            {
                return 0f;
            }
            if (((x > Main.maxTilesX * 0.3f && x < Main.maxTilesX * 0.4f) || (x > Main.maxTilesX * 0.7f && x < Main.maxTilesX * 0.8f)) && Main.rand.Next(100) == 1) return 1f;
            if (oCavern && x > Main.maxTilesX * 0.3f && x < Main.maxTilesX * 0.7f && Main.rand.Next(50) == 1) return 1f;
            return 0f;
        }
        //Does not spawn with Town NPCs. Spawns on the 3/10th to 4/10th and 7/10th to 8/10th parts of the Surface (Width). Also spawns between 3/10th and 7/10th of the Cavern(Width). Does not spawn in Dungeons, Jungle, or Meteor.
        #endregion

        public override void AI()  //  Floater ai
        {
            #region Ogre/custom frames


            int num = 1;
            if (!Main.dedServ)
            {
                num = Main.npcTexture[npc.type].Height / Main.npcFrameCount[npc.type];
            }
            if (npc.direction == 1)
            {
                npc.spriteDirection = 1;
            }
            if (npc.direction == -1)
            {
                npc.spriteDirection = -1;
            }
            npc.rotation = npc.velocity.X * 0.08f;
            npc.frameCounter += 1.0;
            if (npc.frameCounter >= 8.0)
            {
                npc.frame.Y = npc.frame.Y + num;
                npc.frameCounter = 0.0;
            }
            if (npc.frame.Y >= num * Main.npcFrameCount[npc.type])
            {
                npc.frame.Y = 0;
            }
            #endregion
            if ((npc.life <= 25) && (npc.life >= 18))
            {
                npc.scale = 1.2f;
                npc.netUpdate = true;
            }
            if ((npc.life <= 17) && (npc.life >= 11))
            {
                npc.scale = 1.5f;
                npc.netUpdate = true;
            }
            if ((npc.life <= 10) && (npc.life >= 6))
            {
                npc.scale = 1.7f;
                npc.netUpdate = true;
            }
            if (npc.life <= 5)
            {
                if (Main.rand.Next(3) == 1 && oBombEx == false)
                {
                    float num48 = 8f;
                    Vector2 vector8 = new Vector2((npc.position.X + 20), npc.position.Y + (npc.height - 20));
                    float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                    float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                    if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                    {
                        Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                        float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                        num51 = num48 / num51;
                        speedX *= num51;
                        speedY *= num51;
                        int damage = 30;
                        if (Main.expertMode) { damage = 60; }
                        int type = mod.ProjectileType("OmnirsEnemySpellGreatFireballBall");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                        Main.projectile[num54].timeLeft = 1;
                        Main.projectile[num54].aiStyle = -1;
                        customAi1 = 1f;
                        oBombEx = true;
                    }
                    npc.netUpdate = true;
                }
                if (oBombEx)
                {
                    npc.life = 0;
                    npc.netUpdate = true;
                }
            }
            bool flag19 = false;
            if (npc.justHit)
            {
                npc.ai[2] = 0f;
            }
            if (npc.ai[2] >= 0f)
            {
                int num283 = 16;
                bool flag21 = false;
                bool flag22 = false;
                if (npc.position.X > npc.ai[0] - (float)num283 && npc.position.X < npc.ai[0] + (float)num283)
                {
                    flag21 = true;
                }
                else if ((npc.velocity.X < 0f && npc.direction > 0) || (npc.velocity.X > 0f && npc.direction < 0))
                {
                    flag21 = true;
                }
                num283 += 24;
                if (npc.position.Y > npc.ai[1] - (float)num283 && npc.position.Y < npc.ai[1] + (float)num283)
                {
                    flag22 = true;
                }
                if (flag21 & flag22)
                {
                    npc.ai[2] += 1f;
                    if (npc.ai[2] >= 30f && num283 == 16)
                    {
                        flag19 = true;
                    }
                    if (npc.ai[2] >= 60f)
                    {
                        npc.ai[2] = -200f;
                        npc.direction *= -1;
                        npc.velocity.X = npc.velocity.X * -1f;
                        npc.collideX = false;
                    }
                }
                else
                {
                    npc.ai[0] = npc.position.X;
                    npc.ai[1] = npc.position.Y;
                    npc.ai[2] = 0f;
                }
                npc.TargetClosest(true);
            }
            else
            {
                npc.ai[2] += 1f;
                if (Main.player[npc.target].position.X + (float)(Main.player[npc.target].width / 2) > npc.position.X + (float)(npc.width / 2))
                {
                    npc.direction = -1;
                }
                else
                {
                    npc.direction = 1;
                }
            }
            int num284 = (int)((npc.position.X + (float)(npc.width / 2)) / 16f) + npc.direction * 2;
            int num285 = (int)((npc.position.Y + (float)npc.height) / 16f);
            bool flag23 = true;
            bool flag24 = false;
            int num286 = 3;
            if (npc.justHit)
            {
                npc.ai[3] = 0f;
                npc.localAI[1] = 0f;
            }
            float num287 = 7f;
            Vector2 vector33 = new Vector2(npc.position.X + (float)npc.width * 0.5f, npc.position.Y + (float)npc.height * 0.5f);
            float num288 = Main.player[npc.target].position.X + (float)(Main.player[npc.target].width / 2) - vector33.X;
            float num289 = Main.player[npc.target].position.Y + (float)(Main.player[npc.target].height / 2) - vector33.Y;
            float num290 = (float)Math.Sqrt((double)(num288 * num288 + num289 * num289));
            num290 = num287 / num290;
            num288 *= num290;
            num289 *= num290;
            int oDamage1 = 60;//damage
            int oType1 = mod.ProjectileType("OmnirsEnemySpellLightning3Ball");//type
            int oDamage2 = 10;//damage
            int oType2 = mod.ProjectileType("OmnirsEnemySpellDoomBall");//type
            int oDamage3 = 10;//damage
            int oType3 = mod.ProjectileType("OmnirsEnemySpellHoldBall");//type
            int oSpellCast = Main.rand.Next(3);
            if (Main.netMode != 1 && npc.ai[3] == 32f && !Main.player[npc.target].npcTypeNoAggro[npc.type])
            {

                if (oProAmnt == 1 && oSpellCast == 0)
                {
                    int num291 = oDamage1;//damage
                    int num292 = oType1;//type
                    Projectile.NewProjectile(vector33.X, vector33.Y, num288, num289, num292, num291, 0f, Main.myPlayer, 0f, 0f);
                }
                if (oProAmnt == 2 && oSpellCast == 1)
                {
                    int num291 = oDamage2;//damage
                    int num292 = oType2;//type
                    Projectile.NewProjectile(vector33.X, vector33.Y, num288, num289, num292, num291, 0f, Main.myPlayer, 0f, 0f);
                }
                if (oProAmnt == 3 && oSpellCast == 2)
                {
                    int num291 = oDamage3;//damage
                    int num292 = oType3;//type
                    Projectile.NewProjectile(vector33.X, vector33.Y, num288, num289, num292, num291, 0f, Main.myPlayer, 0f, 0f);
                }
            }
            num286 = 8;
            if (npc.ai[3] > 0f)
            {
                npc.ai[3] += 1f;
                if (npc.ai[3] >= 64f)
                {
                    npc.ai[3] = 0f;
                }
            }
            if (Main.netMode != 1 && npc.ai[3] == 0f)
            {
                npc.localAI[1] += 1f;
                if (npc.localAI[1] > 120f && Collision.CanHit(npc.position, npc.width, npc.height, Main.player[npc.target].position, Main.player[npc.target].width, Main.player[npc.target].height) && !Main.player[npc.target].npcTypeNoAggro[npc.type])
                {
                    npc.localAI[1] = 0f;
                    npc.ai[3] = 1f;
                    npc.netUpdate = true;
                }
            }

            for (int num309 = num285; num309 < num285 + num286; num309 = num + 1)
            {
                if (Main.tile[num284, num309] == null)
                {
                    Main.tile[num284, num309] = new Tile();
                }
                if ((Main.tile[num284, num309].nactive() && Main.tileSolid[(int)Main.tile[num284, num309].type]) || Main.tile[num284, num309].liquid > 0)
                {
                    if (num309 <= num285 + 1)
                    {
                        flag24 = true;
                    }
                    flag23 = false;
                    break;
                }
                num = num309;
            }
            if (Main.player[npc.target].npcTypeNoAggro[npc.type])
            {
                bool flag25 = false;
                for (int num310 = num285; num310 < num285 + num286 - 2; num310 = num + 1)
                {
                    if (Main.tile[num284, num310] == null)
                    {
                        Main.tile[num284, num310] = new Tile();
                    }
                    if ((Main.tile[num284, num310].nactive() && Main.tileSolid[(int)Main.tile[num284, num310].type]) || Main.tile[num284, num310].liquid > 0)
                    {
                        flag25 = true;
                        break;
                    }
                    num = num310;
                }
                npc.directionY = (!flag25).ToDirectionInt();
            }
            if (flag19)
            {
                flag24 = false;
                flag23 = true;
            }
            if (flag23)
            {
                npc.velocity.Y = npc.velocity.Y + 0.1f;
                if (npc.velocity.Y > 6f)
                {
                    npc.velocity.Y = 6f;
                }

            }
            else
            {
                if (npc.directionY < 0 && npc.velocity.Y > 0f)
                {
                    npc.velocity.Y = npc.velocity.Y - 0.1f;
                }
                if (npc.velocity.Y < -7f)
                {
                    npc.velocity.Y = -7f;
                }
            }
            if (npc.collideX)
            {
                npc.velocity.X = npc.oldVelocity.X * -0.4f;
                if (npc.direction == -1 && npc.velocity.X > 0f && npc.velocity.X < 1f)
                {
                    npc.velocity.X = 2f;
                }
                if (npc.direction == 1 && npc.velocity.X < 0f && npc.velocity.X > -1f)
                {
                    npc.velocity.X = -2f;
                }
            }
            if (npc.collideY)
            {
                npc.velocity.Y = npc.oldVelocity.Y * -0.25f;
                if (npc.velocity.Y > 0f && npc.velocity.Y < 1f)
                {
                    npc.velocity.Y = 2f;
                }
                if (npc.velocity.Y < 0f && npc.velocity.Y > -1f)
                {
                    npc.velocity.Y = -2f;
                }
            }
            float num312 = 2.5f;
            if (npc.direction == -1)
            {
                npc.velocity.X = npc.velocity.X - 0.2f;
                if (npc.velocity.X > num312)
                {
                    npc.velocity.X = npc.velocity.X - 0.2f;
                }
                else if (npc.velocity.X > 0f)
                {
                    npc.velocity.X = npc.velocity.X + 0.05f;
                }
                if (npc.velocity.X < -num312)
                {
                    npc.velocity.X = -num312;
                }
            }
            else if (npc.direction == 1)
            {
                npc.velocity.X = npc.velocity.X + 0.2f;
                if (npc.velocity.X < -num312)
                {
                    npc.velocity.X = npc.velocity.X + 0.2f;
                }
                else if (npc.velocity.X < 0f)
                {
                    npc.velocity.X = npc.velocity.X - 0.05f;
                }
                if (npc.velocity.X > num312)
                {
                    npc.velocity.X = num312;
                }
            }
            num312 = 1.2f;
            if (npc.direction == -1)
            {
                npc.velocity.Y = npc.velocity.Y - 0.04f;
                if (npc.velocity.Y > num312)
                {
                    npc.velocity.Y = npc.velocity.Y - 0.05f;
                }
                else if (npc.velocity.Y > 0f)
                {
                    npc.velocity.Y = npc.velocity.Y + 0.03f;
                }
                if (npc.velocity.Y < -num312)
                {
                    npc.velocity.Y = -num312;
                }
            }
            else if (npc.direction == 1)
            {
                npc.velocity.Y = npc.velocity.Y + 0.04f;
                if (npc.velocity.Y < -num312)
                {
                    npc.velocity.Y = npc.velocity.Y + 0.05f;
                }
                else if (npc.velocity.Y < 0f)
                {
                    npc.velocity.Y = npc.velocity.Y - 0.03f;
                }
                if (npc.velocity.Y > num312)
                {
                    npc.velocity.Y = num312;
                }
            }
            npc.noTileCollide = false;
            npc.noGravity = true;
            npc.TargetClosest(true);
            Player player = Main.player[npc.target];
            //for (int m = npc.oldPos.Length - 1; m > 0; m--)
            //{
            //    npc.oldPos[m] = npc.oldPos[m - 1];
            //}
            //npc.oldPos[0] = npc.position;
            bool seeplayer = npc.ai[0] >= 200 || Collision.CanHit(npc.position, npc.width, npc.height, player.position, player.width, player.height);
            //public static void AIFlier(NPC npc, ref float[] ai, bool sporadic = true, float moveIntervalX = 0.1f, float moveIntervalY = 0.04f, float maxSpeedX = 4f, float maxSpeedY = 1.5f, bool canBeBored = true, int timeUntilBoredom = 300)
            //npc.rotation = npc.velocity.X * 0.08f;
        }

        public override void NPCLoot()
        {
            if (Main.rand.Next(2) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsFireBullet"), Main.rand.Next(3, 25));
            }
            if (Main.rand.Next(33) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsLongSword"));
            }
            if (Main.rand.Next(33) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsFire1Tome"));
            }
            if (Main.rand.Next(33) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsEdgarTop"));
            }
            if (Main.rand.Next(12) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsEdgarMask"));
            }
            if (Main.rand.Next(12) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsEdgarBottoms"));
            }
            if (Main.rand.Next(12) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsSabinMask"));
            }
            if (Main.rand.Next(33) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsSabinTop"));
            }
            if (Main.rand.Next(33) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsSabinBottoms"));
            }
            if (Main.rand.Next(12) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsCyanMask"));
            }
            if (Main.rand.Next(12) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsCyanTop"));
            }
            if (Main.rand.Next(12) == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsCyanBottoms"));
            }
        }
    }
}
