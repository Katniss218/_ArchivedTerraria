using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OmnirsNosPak.NPCs.FinalFantasy.SuperBosses
{
    public class OmnirsUltimaWeapon : ModNPC
    {

        float customAi1;
        float customspawn1;
        float customspawn2;
        int chargeDamage = 0;
        bool chargeDamageFlag = false;

        int OTimeLeft = 2000;
        int movedTowards = 0;
        int num94 = 0;
        int num95 = 0;
        int noJump = 0;
        bool walkAndShoot = true;

        bool canDrown = false;
        int drownTimerMax = 2000;
        int drownTimer = 2000;
        int drowningRisk = 1200;

        float npcAcSPD = 1.2f; //How fast they accelerate.
        float npcSPD = 4.5f; //Max speed

        float npcEnrAcSPD = 2.95f; //How fast they accelerate.
        float npcEnrSPD = 6.0f; //Max speed

        bool tooBig = true;
        bool lavaJumping = true;

        bool oUltimaEx = false;
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Ultima Weapon");
			Main.npcFrameCount[npc.type] = 14;
		}
        public override void SetDefaults()
        {
            npc.lifeMax = 100000;
            npc.damage = 160;
            npc.defense = 45;
            npc.knockBackResist = 0.1f;
            npc.width = 20;
            npc.height = 110;
            npc.aiStyle = -1;
            npc.HitSound = SoundID.NPCHit4;
            npc.DeathSound = SoundID.NPCDeath5;
            npc.value = 15001000f;
            animationType = 28;
            npc.scale = 2f;
            npc.boss = true;
            npc.lavaImmune = true;
            npc.buffImmune[BuffID.Venom] = true;
            npc.buffImmune[BuffID.Confused] = true;
            npc.buffImmune[BuffID.CursedInferno] = true;
            npc.buffImmune[BuffID.OnFire] = true;
            //banner = npc.type;
            //bannerItem = mod.ItemType("");
        }

        public void teleport(bool pre)
        {
            if (Main.netMode != 2)
            {
                Main.PlaySound(2, (int)npc.Center.X, (int)npc.Center.Y, 8);
                for (int m = 0; m < 25; m++)
                {
                    int dustID = Dust.NewDust(npc.position, npc.width, npc.height, 6, 0, 0, 100, Color.White, 2f);
                    Main.dust[dustID].noGravity = true;
                    Main.dust[dustID].velocity = new Vector2(MathHelper.Lerp(-1f, 1f, (float)Main.rand.NextDouble()), MathHelper.Lerp(-1f, 1f, (float)Main.rand.NextDouble()));
                    Main.dust[dustID].velocity *= 7f;
                }
            }
        }
        public override void AI()  //  warrior ai
        {
            if (npc.life <= 0)
            {
                if (oUltimaEx == false)
                {
                    float num48 = 8f;
                    Vector2 vector8 = new Vector2((npc.position.X + 20), npc.position.Y + (npc.height - 20));
                    float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                    float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                    if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                    {
                        Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                        float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                        num51 = num48 / num51;
                        speedX *= num51;
                        speedY *= num51;
                        int damage = 150;
                        int type = mod.ProjectileType("OmnirsEnemySpellUltimaBall");
                        int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                        Main.projectile[num54].timeLeft = 1;
                        Main.projectile[num54].aiStyle = -1;
                        customAi1 = 1f;
                        oUltimaEx = true;
                    }
                    npc.netUpdate = true;
                }
                if (oUltimaEx)
                {
                    npc.life = 0;
                    npc.netUpdate = true;
                }
            }
            bool enraged = (npc.life < (float)npc.lifeMax * .2f);  //  speed up at low life
            int shotRate = enraged ? 100 : 70;
            float accel = enraged ? npcEnrAcSPD : npcAcSPD;  //  how fast it can speed up
            float topSpeed = enraged ? npcEnrSPD : npcSPD;  //  max walking speed, also affects jump length
            MNPC.teleporterAI
            (
                npc,
                ref npc.ai,
                false,      // immobile		Whether or not this NPC should move while its teleporting.
                20,         // tpRadius		Radius around the player where the NPC will try to move.
                13,         // distToPlayer	Minimum distance to keep from the player as the NPC teleports.
                60,         // tpInterval	How often the NPC will try to teleport, tied to npc.ai[3].
                true,       // aerial		Whether or not an NPC will try to move to an airborne position.
                teleport    // tpEffect		The effect that the NPC will create as it moves.
            );
            MNPC.fighterAI
            (
                npc,
                ref npc.ai,
                false,      // nocturnal  	If true, flees when it is daytime.
                true,       // focused 		If true, npc wont get interrupted when hit or confused.
                60,         // boredom 		The amount of ticks until the npc gets 'bored' following a target.
                2,          // knockPower 	0 == do not interact with doors, attempt to open the doors by this value, negative numbers will break instead
                accel,      // accel 		The rate velocity X increases by when moving.
                topSpeed,   // topSpeed 	the maximum velocity on the X axis.
                2,          // leapReq 		-1 npc wont jump over gaps, more than 0 npc will leap at players
                5,          // leapSpeed	The max tiles it can jump across and over, horizontally. 
                9,          // leapHeight 	The max tiles it can jump across and over, vertically. 
                100,        // leapRangeX 	The distance from a player before the npc initiates leap, horizontally. 
                50,         // leapRangeY 	The distance from a player before the npc initiates leap, vertically. 
                0,          // shotType 	If higher than 0, allows an npc to fire a projectile, archer style.
                40,         // shotRate 	The rate of fire of the projectile, if there is one.
                70,         // shotPow 		The projectile's damage, if -1 it will use the projectile's default.
                14          // shotSpeed	The projectile's velocity.
            );
            Vector2 angle = Main.player[npc.target].Center - npc.Center;
            angle.Y = angle.Y - (Math.Abs(angle.X) * .1f);
            angle.X += (float)Main.rand.Next(-20, 21);
            angle.Y += (float)Main.rand.Next(-20, 21);
            angle.Normalize();
            float distance = npc.Distance(Main.player[npc.target].Center);
            #region shoot and walk
            if (Main.netMode != 1)
            {
                if (npc.justHit)
                    npc.ai[2] = 0f; // reset throw countdown when hit
                //if (Main.rand.Next(200) == 1)
                //{
                //    chargeDamageFlag = true;
                //    Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                //    float rotation = (float)Math.Atan2(vector8.Y - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), vector8.X - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                //    npc.velocity.X = (float)(Math.Cos(rotation) * 14) * -1;
                //    npc.velocity.Y = (float)(Math.Sin(rotation) * 14) * -1;
                //    npc.ai[1] = 1f;
                //    npc.netUpdate = true;
                //}
                //if (chargeDamageFlag == true)
                //{
                //    npc.damage = 220;
                //    chargeDamage++;
                //}
                //if (chargeDamage >= 50)
                //{
                //    chargeDamageFlag = false;
                //    npc.damage = 50;
                //    chargeDamage = 0;
                //}
                #region Projectiles
                customAi1 += (Main.rand.Next(2, 5) * 0.1f) * npc.scale;
                if (customAi1 >= 10f)
                {
                    npc.TargetClosest(true);
                    if (Collision.CanHit(npc.position, npc.width, npc.height, Main.player[npc.target].position, Main.player[npc.target].width, Main.player[npc.target].height))
                    {
                        if (Main.rand.Next(100) == 1)
                        {
                            float num48 = 8f;
                            float aNV1;
                            //int aNV2;
                            if (npc.direction > 0)
                            {
                                aNV1 = (((npc.width) * 1.1f));
                            }
                            else
                            {
                                aNV1 = (((npc.width) * -.1f));
                            }
                            Vector2 vector8 = new Vector2((npc.position.X + aNV1), npc.position.Y + (npc.height));
                            float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                            float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                            if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                            {
                                Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                                float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                                num51 = num48 / num51;
                                speedX *= num51;
                                speedY *= num51;
                                int damage = 120;
                                int type = mod.ProjectileType("OmnirsEnemySpellGreatEnergyBeamBall");
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                                Main.projectile[num54].timeLeft = 200;
                                Main.projectile[num54].aiStyle = -1;
                                customAi1 = 1f;
                            }
                            npc.netUpdate = true;
                        }
                        if (Main.rand.Next(300) == 1)
                        {
                            float num48 = 8f;
                            float aNV1;
                            //int aNV2;
                            if (npc.direction > 0)
                            {
                                aNV1 = (((npc.width) * 1.1f));
                            }
                            else
                            {
                                aNV1 = (((npc.width) * -.1f));
                            }
                            Vector2 vector8 = new Vector2((npc.position.X + aNV1), npc.position.Y + (npc.height));
                            float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                            float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                            if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                            {
                                Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                                float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                                num51 = num48 / num51;
                                speedX *= num51;
                                speedY *= num51;
                                int damage = 100;
                                int type = mod.ProjectileType("OmnirsEnemySpellGreatEnergyBall");
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                                Main.projectile[num54].timeLeft = 200;
                                Main.projectile[num54].aiStyle = -1;
                                customAi1 = 1f;
                            }
                            npc.netUpdate = true;
                        }
                        if (Main.rand.Next(180) == 1)
                        {
                            float num48 = 8f;
                            float aNV1;
                            //int aNV2;
                            if (npc.direction > 0)
                            {
                                aNV1 = (((npc.width) * 1.1f));
                            }
                            else
                            {
                                aNV1 = (((npc.width) * -.1f));
                            }
                            Vector2 vector8 = new Vector2((npc.position.X + aNV1), npc.position.Y + (npc.height));
                            float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                            float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                            if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                            {
                                Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                                float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                                num51 = num48 / num51;
                                speedX *= num51;
                                speedY *= num51;
                                int damage = 140;
                                int type = mod.ProjectileType("OmnirsEnemySpellLightning4Ball");
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                                Main.projectile[num54].timeLeft = 200;
                                Main.projectile[num54].aiStyle = -1;
                                customAi1 = 1f;
                            }
                            npc.netUpdate = true;
                        }

                        if (Main.rand.Next(180) == 1)
                        {
                            float num48 = 8f;
                            float aNV1;
                            //int aNV2;
                            if (npc.direction > 0)
                            {
                                aNV1 = (((npc.width) * 1.1f));
                            }
                            else
                            {
                                aNV1 = (((npc.width) * -.1f));
                            }
                            Vector2 vector8 = new Vector2((npc.position.X + aNV1), npc.position.Y + (npc.height));
                            float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                            float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                            if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                            {
                                Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                                float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                                num51 = num48 / num51;
                                speedX *= num51;
                                speedY *= num51;
                                int damage = 140;
                                int type = mod.ProjectileType("OmnirsEnemySpellFire4Ball");
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                                Main.projectile[num54].timeLeft = 200;
                                Main.projectile[num54].aiStyle = -1;
                                customAi1 = 1f;
                            }
                            npc.netUpdate = true;
                        }
                        if (Main.rand.Next(180) == 1)
                        {
                            float num48 = 8f;
                            float aNV1;
                            //int aNV2;
                            if (npc.direction > 0)
                            {
                                aNV1 = (((npc.width) * 1.1f));
                            }
                            else
                            {
                                aNV1 = (((npc.width) * -.1f));
                            }
                            Vector2 vector8 = new Vector2((npc.position.X + aNV1), npc.position.Y + (npc.height));
                            float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                            float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                            if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                            {
                                Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                                float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                                num51 = num48 / num51;
                                speedX *= num51;
                                speedY *= num51;
                                int damage = 140;
                                int type = mod.ProjectileType("OmnirsEnemySpellIce4Ball");
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                                Main.projectile[num54].timeLeft = 200;
                                Main.projectile[num54].aiStyle = -1;
                                customAi1 = 1f;
                            }
                            npc.netUpdate = true;
                        }
                        if (Main.rand.Next(2000) == 1)
                        {
                            float num48 = 8f;
                            float aNV1;
                            //int aNV2;
                            if (npc.direction > 0)
                            {
                                aNV1 = (((npc.width) * 1.1f));
                            }
                            else
                            {
                                aNV1 = (((npc.width) * -.1f));
                            }
                            Vector2 vector8 = new Vector2((npc.position.X + aNV1), npc.position.Y + (npc.height));
                            float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                            float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                            if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                            {
                                Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                                float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                                num51 = num48 / num51;
                                speedX *= num51;
                                speedY *= num51;
                                int damage = 50;
                                int type = mod.ProjectileType("OmnirsEnemySpellGravity3Ball");
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                                Main.projectile[num54].timeLeft = 200;
                                Main.projectile[num54].aiStyle = -1;
                                customAi1 = 1f;
                            }
                            npc.netUpdate = true;
                        }
                        if (Main.rand.Next(600) == 1)
                        {
                            float num48 = 8f;
                            float aNV1;
                            //int aNV2;
                            if (npc.direction > 0)
                            {
                                aNV1 = (((npc.width) * 1.1f));
                            }
                            else
                            {
                                aNV1 = (((npc.width) * -.1f));
                            }
                            Vector2 vector8 = new Vector2((npc.position.X + aNV1), npc.position.Y + (npc.height));
                            float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                            float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                            if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                            {
                                Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                                float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                                num51 = num48 / num51;
                                speedX *= num51;
                                speedY *= num51;
                                int damage = 140;
                                int type = mod.ProjectileType("OmnirsEnemySpellBlazeBall");
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                                Main.projectile[num54].timeLeft = 200;
                                Main.projectile[num54].aiStyle = -1;
                                customAi1 = 1f;
                            }
                            npc.netUpdate = true;
                        }
                        if ((Main.rand.Next(1000) == 1) || (Main.rand.Next(900) == 1 && Main.expertMode))
                        {
                            float num48 = 8f;
                            float aNV1;
                            //int aNV2;
                            if (npc.direction > 0)
                            {
                                aNV1 = (((npc.width) * 1.1f));
                            }
                            else
                            {
                                aNV1 = (((npc.width) * -.1f));
                            }
                            Vector2 vector8 = new Vector2((npc.position.X + aNV1), npc.position.Y + (npc.height));
                            float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
                            float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
                            if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
                            {
                                Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
                                float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
                                num51 = num48 / num51;
                                speedX *= num51;
                                speedY *= num51;
                                int damage = 200;
                                int type = mod.ProjectileType("OmnirsEnemySpellUltimaBall");
                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
                                Main.projectile[num54].timeLeft = 1;
                                Main.projectile[num54].aiStyle = -1;
                                customAi1 = 1f;
                            }
                            npc.netUpdate = true;
                        }
                    }
                    #region Charge
                    if (npc.velocity.Y == 0f && Main.rand.Next(550) == 1)
                    {
                        Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                        float rotation = (float)Math.Atan2(vector8.Y - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), vector8.X - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                        npc.velocity.X = (float)(Math.Cos(rotation) * 7) * -1;
                        npc.velocity.Y = (float)(Math.Sin(rotation) * 7) * -1;
                        npc.ai[1] = 1f;
                        npc.netUpdate = true;
                    }
                    #endregion
                }
                #endregion
            }
            #endregion
            if (npc.velocity.Y == 0f && Main.rand.Next(550) == 1)
            {
                Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
                float rotation = (float)Math.Atan2(vector8.Y - (Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)), vector8.X - (Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)));
                npc.velocity.X = (float)(Math.Cos(rotation) * 7) * -1;
                npc.velocity.Y = (float)(Math.Sin(rotation) * 7) * -1;
                npc.localAI[3] = 1f;
                npc.netUpdate = true;
            }
            #region Too Big and Lava Jumping
            if (tooBig)
            {
                if (npc.velocity.Y == 0f && (npc.velocity.X == 0f && npc.direction < 0))
                {
                    npc.velocity.Y -= 8f;
                    npc.velocity.X -= npcSPD;
                }
                else if (npc.velocity.Y == 0f && (npc.velocity.X == 0f && npc.direction > 0))
                {
                    npc.velocity.Y -= 8f;
                    npc.velocity.X += npcSPD;
                }
            }
            if (lavaJumping)
            {
                if (npc.lavaWet)
                {
                    npc.velocity.Y -= 2;
                }
            }
            #endregion
        }

        public override void NPCLoot()
        {
            if (Main.netMode == 2)
            {
                return;
            }
            //generate particle effect
            Color color = new Color();
            Rectangle rectangle = new Rectangle((int)npc.position.X, (int)(npc.position.Y + ((npc.height - npc.width) / 2)), npc.width, npc.width);//npc.frame;
            int count = 50;
            float vectorReduce = .4f;
            for (int i = 1; i <= count; i++)
            {
                //int dust = Dust.NewDust(new Vector2((float) rectangle.X, (float) rectangle.Y), rectangle.Width, rectangle.Height, 6, (npc.velocity.X * 0.2f) + (npc.direction * 3), npc.velocity.Y * 0.2f, 100, color, 1.9f);
                int dust = Dust.NewDust(npc.position, rectangle.Width, rectangle.Height, 5, 0, 0, 100, color, 1.8f);
                Main.dust[dust].noGravity = false;
                Main.dust[dust].velocity.X = vectorReduce * (Main.dust[dust].position.X - (npc.position.X + (npc.width / 2)));
                Main.dust[dust].velocity.Y = vectorReduce * (Main.dust[dust].position.Y - (npc.position.Y + (npc.height / 2)));
            }
            int uLoot = (Main.rand.Next(3));
            int uLoot2 = (Main.rand.Next(4));
            int uLoot3 = (Main.rand.Next(4));
            if (uLoot == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsUltimaWeapon"));
            }
            if (uLoot == 1)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsAtmaWeapon"));
            }
            if (uLoot == 2)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsGuardianUltimaWeapon"));
            }
            if (uLoot2 == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsFire4Tome"));
            }
            if (uLoot2 == 1)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsIce4Tome"));
            }
            if (uLoot2 == 2)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsBolt4Tome"));
            }
            if (uLoot2 == 3)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsQuake4Tome"));
            }
            if (uLoot3 == 0)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsWarpTome"));
            }
            if (uLoot3 == 1)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsShieldTome"));
            }
            if (uLoot3 == 2)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsCure4Tome"));
            }
            if (uLoot3 == 3)
            {
                Item.NewItem((int)npc.position.X, (int)npc.position.Y, npc.width, npc.height, mod.ItemType("OmnirsHeal4Tome"));
            }
        }
    }
}