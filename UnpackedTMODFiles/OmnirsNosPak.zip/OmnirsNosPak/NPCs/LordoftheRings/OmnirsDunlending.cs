//using Microsoft.Xna.Framework;
//using Terraria;
//using Terraria.ID;
//using Terraria.ModLoader;
//using Microsoft.Xna.Framework.Graphics;
//using Microsoft.Xna.Framework.Input;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace OmnirsNosPak.NPCs.LordoftheRings
//{
//    public class OmnirsDunlending : ModNPC
//    {

//        float customAi1;
//        int OTimeLeft = 2000;
//        bool walkAndShoot = false;

//        bool canDrown = true;
//        int drownTimerMax = 1800;
//        int drownTimer = 1800;
//        int drowningRisk = 1100;

//        float npcAcSPD = 0.1f; //How fast they accelerate.
//        float npcSPD = 2.20f; //Max speed
//float npcEnrAcSPD = 0.95f; //How fast they accelerate.
//float npcEnrSPD = 2.0f; //Max speed

//        bool tooBig = false;
//        bool lavaJumping = false;

//        #region Spawn
//        public override void SetDefaults()
//		{
//			npc.name = "Dunlending";
//			npc.lifeMax = 100;
//			npc.damage = 30;
//			npc.defense = 2;
//			npc.knockBackResist = 0.6f;
//			npc.width = 20;
//			npc.height = 40;
//			npc.aiStyle = -1;
//			npc.soundHit = 1;
//			npc.soundKilled = 2;
//			Main.npcFrameCount[npc.type] = 15;
//			npc.value = 150f;
//			animationType = 21;
//			npc.scale = 1;
//			banner = npc.type;
//			bannerItem = mod.ItemType("");
//		}
//		public override bool CanSpawn(int x, int y, int type, Player player)
//        {
//int x = s.spawnTileX;
//int y = s.spawnTileY;
//bool oSky = (y < (Main.maxTilesY * 0.1f));
//bool oSurface = (y >= (Main.maxTilesY * 0.1f) && y < (Main.maxTilesY * 0.2f));
//bool oUnderSurface = (y >= (Main.maxTilesY * 0.2f) && y < (Main.maxTilesY * 0.3f));
//bool oUnderground = (y >= (Main.maxTilesY * 0.3f) && y < (Main.maxTilesY * 0.4f));
//bool oCavern = (y >= (Main.maxTilesY * 0.4f) && y < (Main.maxTilesY * 0.6f));
//bool oMagmaCavern = (y >= (Main.maxTilesY * 0.6f) && y < (Main.maxTilesY * 0.8f));
//bool oUnderworld = (y >= (Main.maxTilesY * 0.8f));
//int tile = (int)Main.tile[x, y].type;
//Player p = s.player;
//            if (Main.pumpkinMoon || Main.snowMoon || Main.hardMode || player.townNPCs > 4f || player.zone["Dungeon"] || player.zone["Jungle"] || player.zone["Meteor"])
//            { 
//                return false; 
//            }
//            if ((oSurface || oUnderSurface ) && (x > Main.maxTilesX * 0.1f && x < Main.maxTilesX * 0.5f))
//            {
//                if (Main.rand.Next(50) == 1) return true;
//                return false;
//            }
//            if ((oSurface || oUnderSurface || oUnderground) && (x > Main.maxTilesX * 0.1f && x < Main.maxTilesX * 0.9f))
//            {
//                if ((oUnderSurface || oUnderground) && Main.rand.Next(30) == 1) return true;
//                return false;
//            }
//            return false;
//        }
//        #endregion
//        //Spawns on the Surface down into the Underground. Mostly spawns after 6.2/10th (Width). Does not spawn in the Dungeon, Jungle, Meteor, or if there are Town NPCs.

//        public override void AI()
//        {
//            npc.noGravity = false;
//            BaseMod.BaseAI.AIZombie(npc, ref npc.ai, false, true, -1, npcAcSPD, npcSPD, 4, 3, 60);
//            npc.spriteDirection = npc.direction;
//            #region shoot and walk
//            if (walkAndShoot && Main.netMode != 1 && !Main.player[npc.target].dead) // can generalize this section to moving+projectile code // can generalize this section to moving+projectile code
//            {
//                if (npc.justHit)
//                    npc.ai[2] = 0f; // reset throw countdown when hit
//                #region Projectiles
//                customAi1 += (Main.rand.Next(2, 5) * 0.1f) * npc.scale;
//                if (customAi1 >= 10f)
//                {
//                    npc.TargetClosest(true);
//                    if (Collision.CanHit(npc.position, npc.width, npc.height, Main.player[npc.target].position, Main.player[npc.target].width, Main.player[npc.target].height))
//                    {
//                        if (Main.rand.Next(70) == 1)
//                        {
//                            npc.ai[3] = 1;
//                            npc.life += 5;
//                            if (npc.life > npc.lifeMax) npc.life = npc.lifeMax; npc.ai[3] = 1;
//                            Main.player[npc.target].statLife -= 2;
//                            float num48 = 8f;
//                            Vector2 vector8 = new Vector2(npc.position.X + (npc.width * 0.5f), npc.position.Y + (npc.height / 2));
//                            float speedX = ((Main.player[npc.target].position.X + (Main.player[npc.target].width * 0.5f)) - vector8.X) + Main.rand.Next(-20, 0x15);
//                            float speedY = ((Main.player[npc.target].position.Y + (Main.player[npc.target].height * 0.5f)) - vector8.Y) + Main.rand.Next(-20, 0x15);
//                            if (((speedX < 0f) && (npc.velocity.X < 0f)) || ((speedX > 0f) && (npc.velocity.X > 0f)))
//                            {
//                                Main.PlaySound(2, (int)npc.position.X, (int)npc.position.Y, 5);
//                                float num51 = (float)Math.Sqrt((double)((speedX * speedX) + (speedY * speedY)));
//                                num51 = num48 / num51;
//                                speedX *= num51;
//                                speedY *= num51;
//                                int damage = 20,
//                                type = ProjDef.byName["OmnirsNosPak:OmnirsEnemyThrowingKnife"].type;
//                                int num54 = Projectile.NewProjectile(vector8.X, vector8.Y, speedX, speedY, type, damage, 0f, Main.myPlayer);
//                                Main.projectile[num54].timeLeft = 100;
//                                Main.projectile[num54].aiStyle = 1;
//                                customAi1 = 1f;
//                            }
//                            npc.netUpdate = true;
//                        }
//                    }
//                }
//                #endregion
//            }
//            #endregion
//            #region drown // code by Omnir
//            if (canDrown)
//            {
//                if (!npc.wet)
//                {
//                    npc.TargetClosest(true);
//                    drownTimer = drownTimerMax;
//                }
//                if (npc.wet)
//                {
//                    drownTimer--;
//                }
//                if (npc.wet && drownTimer > drowningRisk)
//                {
//                    npc.TargetClosest(true);
//                }
//                else if (npc.wet && drownTimer <= drowningRisk)
//                {
//                    npc.TargetClosest(false);
//                    if (npc.timeLeft > 10)
//                    {
//                        npc.timeLeft = 10;
//                    }
//                    npc.directionY = -1;
//                    if (npc.velocity.Y > 0f)
//                    {
//                        npc.direction = 1;
//                    }
//                    npc.direction = -1;
//                    if (npc.velocity.X > 0f)
//                    {
//                        npc.direction = 1;
//                    }
//                }
//                if (drownTimer <= 0)
//                {
//                    npc.life--;
//                    if (npc.life <= 0)
//                    {
//                        Main.PlaySound(4, (int)npc.position.X, (int)npc.position.Y, 1);
//                        npc.NPCLoot();
//                        npc.netUpdate = true;
//                    }
//                }
//            }
//            #endregion
//            #region Too Big and Lava Jumping
//            if (tooBig)
//            {
//                if (npc.velocity.Y == 0f && (npc.velocity.X == 0f && npc.direction < 0))
//                {
//                    npc.velocity.Y -= 8f;
//                    npc.velocity.X -= npcSPD;
//                }
//                else if (npc.velocity.Y == 0f && (npc.velocity.X == 0f && npc.direction > 0))
//                {
//                    npc.velocity.Y -= 8f;
//                    npc.velocity.X += npcSPD;
//                }
//            }
//            if (lavaJumping)
//            {
//                if (npc.lavaWet)
//                {
//                    npc.velocity.Y -= 2;
//                }
//            }
//            #endregion
//        }

//        public override void NPCLoot()
//        {
//            BaseMod.BaseAI.DropItem(npc, ItemDef.byName["OmnirsNosPak:OmnirsOrcishSword"].type, 1, 1, 15, true);
//        }

//        #region Gore
//        public override void PostNPCLoot()
//        {
//            if (Main.netMode == 2)
//            {
//                return;
//            }
//            //generate particle effect
//            Color color = new Color();
//            Rectangle rectangle = new Rectangle((int)npc.position.X, (int)(npc.position.Y + ((npc.height - npc.width) / 2)), npc.width, npc.width);//npc.frame;
//            int count = 50;
//            float vectorReduce = .4f;
//            for (int i = 1; i <= count; i++)
//            {
//                //int dust = Dust.NewDust(new Vector2((float) rectangle.X, (float) rectangle.Y), rectangle.Width, rectangle.Height, 6, (npc.velocity.X * 0.2f) + (npc.direction * 3), npc.velocity.Y * 0.2f, 100, color, 1.9f);
//                int dust = Dust.NewDust(npc.position, rectangle.Width, rectangle.Height, 5, 0, 0, 100, color, 1.8f);
//                Main.dust[dust].noGravity = false;
//                Main.dust[dust].velocity.X = vectorReduce * (Main.dust[dust].position.X - (npc.position.X + (npc.width / 2)));
//                Main.dust[dust].velocity.Y = vectorReduce * (Main.dust[dust].position.Y - (npc.position.Y + (npc.height / 2)));
//            }
//            Gore.NewGore(npc.position, npc.velocity, "OmnirsNosPak:OmnirsDunlendingGore1", 1f, -1);
//            Gore.NewGore(npc.position, npc.velocity, "OmnirsNosPak:OmnirsDunlendingGore2", 1f, -1);
//            Gore.NewGore(npc.position, npc.velocity, "OmnirsNosPak:OmnirsDunlendingGore3", 1f, -1);
//            Gore.NewGore(npc.position, npc.velocity, "OmnirsNosPak:OmnirsDunlendingGore2", 1f, -1);
//            Gore.NewGore(npc.position, npc.velocity, "OmnirsNosPak:OmnirsDunlendingGore3", 1f, -1);
//        }
//        #endregion
//    }
//}