using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;
using OmnirsNosPak.NPCs;

namespace OmnirsNosPak
{
	public class MNPC : GlobalNPC
	{
		public override void ModifyHitPlayer(NPC npc, Player target, ref int damage, ref bool crit)
		{
			//if(M.HasEquipped(mod.ItemType("UndeadTalisman")) && 
			//(
			//	npc.name.Contains("Zombie") ||
			//	npc.name.Contains("Skeleton") ||
			//	npc.name.Contains("Undead") ||
			//	npc.name.Contains("Bone") ||
			//	npc.name.Contains("Tim") ||
			//	npc.name.Contains("Groom") ||
			//	npc.name.Contains("Bride") ||
			//	npc.name.Contains("Mummy") ||
			//	npc.name.Contains("Wraith") ||
			//	npc.name.Contains("Possessed") ||
			//	npc.name.Contains("Vampire") ||
			//	npc.name.Contains("Frankenstein") ||
			//	npc.name.Contains("Rune Wizard") ||
			//	npc.name.Contains("Caster") ||
			//	npc.name.Contains("Water Sphere") ||
			//	npc.name.Contains("Face Monster") ||
			//	npc.name.Contains("Floaty Gross") ||
			//	npc.name.Contains("Eyezor") ||
			//	npc.name.Contains("Reaper") ||
			//	npc.name.Contains("Necro") ||
			//	npc.name.Contains("Diabolist") ||
			//	npc.name.Contains("Spirit") ||
			//	npc.name.Contains("Skull") ||
			//	npc.name.Contains("Headless") ||
			//	npc.name.Contains("Poltergeist") ||
			//	npc.name.Contains("Soul") ||
			//	npc.name.Contains("Phantasm") ||
			//	npc.name.Contains("Ancient Doom") ||
			//	npc.name.Contains("Ghoul") ||
			//	npc.name.Contains("Wight") ||
			//	npc.name.Contains("Dungeon Mage") ||
			//	npc.name.Contains("Abysswalker") ||
			//	npc.name.Contains("Death") ||
			//	npc.name.Contains("Lich") ||
			//	npc.name.Contains("Shadow")
			//)) 
			//{
			//	damage -= 15;
			//	for(int i = 0; i < 22; i++)
			//	{
			//		if (target.buffType[i] == 23) target.buffTime[i] = 0;
			//		if (target.buffType[i] == 24) target.buffTime[i] = 0;
			//		if (target.buffType[i] == 36) target.buffTime[i] = 0;
			//	}
			//}
		}
		public static Random TempSyncedRand = new Random(0);
		public static int FireProjectile(Vector2 fireTarget, Vector2 position, int projectileType, int damage, float knockback, float speeMcalar = 1.0F, int hostility = 0, int aiStyle = 0)
		{
			//int projectileType = projectileTypeObj is string ? Defs.projectiles[(string)projectileTypeObj].type : (int)projectileTypeObj;
			Vector2 rotVec = RotateVector(position, position + new Vector2(speeMcalar, 0f), RotationTo(position, fireTarget));
			rotVec -= position;
			int projectileID = Projectile.NewProjectile(position.X, position.Y, rotVec.X, rotVec.Y, projectileType, damage, knockback, Main.myPlayer);
			Projectile proj = Main.projectile[projectileID];
			if (hostility != 0)
			{
				proj.friendly = (hostility == 1 || hostility == 2);
				proj.hostile = (hostility == -1 || hostility == 2);
			}

			if(aiStyle > 0) proj.aiStyle = aiStyle;
			return projectileID;
		}
		public static float RotationTo(Vector2 startPos, Vector2 endPos)
		{
			return (float)Math.Atan2(endPos.Y - startPos.Y, endPos.X - startPos.X);
		}

		public static Vector2 RotateVector(Vector2 origin, Vector2 vecToRot, float rot)
		{
			float newPosX = (float)(Math.Cos(rot) * (vecToRot.X - origin.X) - Math.Sin(rot) * (vecToRot.Y - origin.Y) + origin.X);
			float newPosY = (float)(Math.Sin(rot) * (vecToRot.X - origin.X) + Math.Cos(rot) * (vecToRot.Y - origin.Y) + origin.Y);
			return new Vector2(newPosX, newPosY);
		}
        /*
         * A heavily edited custom version of Grox's teleporter AI.
         * 
         * ai : 					A float array that stores AI data. (Note this array should be synced!)
         * immobile (true) : 		Whether or not this NPC should move while its teleporting.
         * tpRadius (20) : 			Radius around the player where the NPC will try to move.
         * distFromPlayer (4) : 	Minimum distance to keep from the player as the NPC teleports.
         * tpInterval (650) : 		How often the NPC will try to teleport, tied to npc.ai[3].
         * aerial (true) : 			Whether or not an NPC will try to move to an airborne position.
         * tpEffects (null) : 		The effect that the NPC will create as it moves.
         * tpConstant (false) : 	If true, the NPC will constantly teleport.  If false, it will only teleport if bored.
                                    NOTE: If an NPC has tpConstant = false and does not have fighter AI, it will never teleport!
         */
        public static void teleporterAI(NPC npc, ref float[] ai, bool immobile = true, int tpRadius = 20, int distFromPlayer = 4, int tpInterval = 650, bool aerial = true, Action<bool> tpEffects = null, bool tpConstant = false)
		{
            npc.TargetClosest(true);
			Vector2 telePos = new Vector2(0,0);
            if (immobile)
            {
                npc.velocity.X *= 0.93f;
                if ((double)Math.Abs(npc.velocity.X) > 0.1) npc.velocity.X = 0f;
            }
			if (tpConstant) ai[3]++;
            if (ai[3] >= tpInterval)
            {
                int playerTileX = (int)Main.player[npc.target].position.X / 16;
                int playerTileY = (int)Main.player[npc.target].position.Y / 16;
                int tileX = (int)npc.position.X / 16;
                int tileY = (int)npc.position.Y / 16;
                int tpCheck = 0;
                bool hasTP = false;
                if (Vector2.Distance(npc.Center, Main.player[npc.target].Center) > 2000f)
                {
                    tpCheck = 100;
                    hasTP = true;
                }
                while (!hasTP && tpCheck < 100)
                {
                    tpCheck++;
                    int tpTileX = TempSyncedRand.Next(playerTileX - tpRadius, playerTileX + tpRadius);
                    int tpTileY = TempSyncedRand.Next(playerTileY - tpRadius, playerTileY + tpRadius);
                    for (int tpY = tpTileY; tpY < playerTileY + tpRadius; tpY++)
                    {
                        if ((tpY < playerTileY - distFromPlayer || tpY > playerTileY + distFromPlayer || tpTileX < playerTileX - distFromPlayer || tpTileX > playerTileX + distFromPlayer) && (tpY < tileY - 1 || tpY > tileY + 1 || tpTileX < tileX - 1 || tpTileX > tileX + 1) && Main.tile[tpTileX, tpY].active())
                        {
							bool safe = true;
							if(Main.tile[tpTileX, tpY - 1].lava() && !npc.lavaImmune) safe = false;
                            if (safe && (Main.tileSolid[(int)Main.tile[tpTileX, tpY].type] || aerial) && !Collision.SolidTiles(tpTileX - 1, tpTileX + 1, tpY - 4, tpY - 1))
                            {
								telePos.X = (float)(tpTileX * 16f - (float)(npc.width / 2) + 8f);
								telePos.Y = (aerial)?(float)(tpY * 16f - (float)npc.height)-65:(float)(tpY * 16f - (float)npc.height);
								hasTP = true;
								ai[3] = -120f;
                                break;
                            }
                        }
                    }
                }
                npc.netUpdate = true;
            }
            if (ai[3] == -120f && telePos != new Vector2(0,0))
            {
                if (tpEffects != null) { tpEffects(true); }
				npc.position.X = telePos.X;
				npc.position.Y = telePos.Y;
                npc.velocity *= 0f;
				ai[3] = 0f;
                if (tpEffects != null) { tpEffects(false); }
            }
        }

        /*
         * A heavily edited custom version of aiStyle 3 (parenthesis indicate default values)
         * 
         * ai : 				    A float array that stores AI data. (Note this array should be synced!)
         * nocturnal (false) :	    If true, flees when it is daytime.
         * focused (false) : 	    If true, npc wont get interrupted when hit or confused.
         * boredom (60) : 		    The amount of ticks until the npc gets 'bored' following a target.
         * knockPower (0) :		    0 == do not interact with doors, attempt to open the doors by this value, negative numbers will break instead
         * accel (0.07f):   	    The rate velocity X increases by when moving.
         * topSpeed (1f) :	 	    The maximum velocity on the X axis.
         * leapReq (0) :	   	    -1 npc wont jump over gaps, more than 0 npc will leap at players
         * leapSpeed (3) :          The max tiles it can jump across. 
         * leapHeight (4) :         The max tiles it can jump over. 
         * leapRangeX (100) :       The X distance from a player before the npc initiates leap. 
         * leapRangeY (50) :  	    The Y distance from a player before the npc initiates leap. 
         * shotType (0) : 		   	If higher than 0, allows an npc to fire a projectile.
         * shotRate (70) : 			The rate of fire of the projectile, if there is one.
         * shotPow (-1) : 			The projectile's damage, if -1 it will use the projectile's default.
         * shotSpeed (11) : 		The projectile's velocity.
         */
        public static void fighterAI(NPC npc, ref float[] ai, bool nocturnal = true, bool focused = false, int boredom = 60,int knockPower = 0, float accel = 0.07f, float topSpeed = 1f, float leapReq = 0, float leapSpeed = 3, float leapHeight = 4, float leapRangeX = 100, float leapRangeY = 50, int shotType = 0, float shotRate = 70, int shotPow = -1, float shotSpeed = 11)
        {
            bool moonwalking = false;
            //This block of code checks for major X velocity/directional changes as well as periodically updates the npc.
			if (npc.velocity.Y == 0f && ((npc.velocity.X > 0f && npc.direction < 0) || (npc.velocity.X < 0f && npc.direction > 0)))
				moonwalking = true;
			if (shotType <= 0 || npc.ai[2] <= 0f)  //  loop to set ai[3] (boredom)
			{
				if (npc.position.X == npc.oldPosition.X || ai[3] >= (float)boredom || moonwalking)
					{ai[3] += 1f;}
				else if ((double)Math.Abs(npc.velocity.X) > 0.9 && ai[3] > 0f)
					{ai[3] -= 1f;}
				if ((npc.justHit && !focused) || ai[3] > (float)(boredom * 10)) //focused NPCs don't reset their boredom/teleport timer when hit
					{ai[3] = 0f;}
				if (ai[3] == (float)boredom)
					{npc.netUpdate = true;}
			}
			if(!focused && (npc.justHit || npc.confused))
			{
				if(shotType > 0)
					{npc.localAI[0] = (float)shotRate/3;} // shot on .5 sec cooldown
				npc.ai[2] = 0;
			}
            bool notBored = ai[3] < (float)boredom;
            //if npc does not flee when it's day, if is night, or npc is not on the surface and it hasn't updated projectile pass, update target.
            if ((!nocturnal || !Main.dayTime || (double)npc.position.Y > Main.worldSurface * 16.0) && notBored)
				{npc.TargetClosest(true);}
			else if (shotType <= 0 || ai[2] <= 0f)//if 'bored'
            {
                if (nocturnal && Main.dayTime && (double)(npc.position.Y / 16f) < Main.worldSurface && npc.timeLeft > 10)
					{npc.timeLeft = 10;}
                if (npc.velocity.X == 0f)
                {
                    if (npc.velocity.Y == 0f)
                    {
						if (npc.ai[0]==0f)
							{npc.ai[0]=1f;}
						else
						{
							npc.direction *= -1;
							npc.spriteDirection = npc.direction;
							npc.ai[0]=0f;
						}
                    }
                }
				else 
					{ai[0] = 0f;}
                if (npc.direction == 0)
					{npc.direction = 1;}
            }
            //if velocity is less than -1 or greater than 1...
			if (shotType <= 0 || (npc.ai[2] <= 0f && !npc.confused))  //  melee attack/movement. shotType > 0s only use while not aiming
			{
				if (Math.Abs(npc.velocity.X) > topSpeed)  //  running/flying faster than top speed
				{
					if (npc.velocity.Y == 0f)  //  and not jump/fall
						{npc.velocity *= .8f;}  //  decelerate
				}
				else if ((npc.velocity.X < topSpeed && npc.direction == 1)||(npc.velocity.X > -topSpeed && npc.direction == -1))
				{  //  running slower than top speed (forward), can be jump/fall
					npc.velocity.X = npc.velocity.X + (float)npc.direction*accel;  //  accellerate fwd; can happen midair
					if ((float)npc.direction*npc.velocity.X > topSpeed)
						{npc.velocity.X = (float)npc.direction*topSpeed;}  //  but cap at top speed
				}  //  END running slower than top speed (forward), can be jump/fall
			} // END shotType <= 0 or not aiming
			if (shotType > 0)
			{
				if(!npc.confused)
				{
					float distance = npc.Distance(Main.player[npc.target].Center);
					Vector2 angle = Main.player[npc.target].Center - npc.Center;
					angle.Y = angle.Y - (Math.Abs(angle.X)*.1f);
					angle.X += (float)Main.rand.Next(-40, 41);
					angle.Y += (float)Main.rand.Next(-40, 41);
					angle.Normalize();
					angle *= shotSpeed;
					if (npc.localAI[0] > 0f)
						{npc.localAI[0] -= 1f;} // decrement fire & reload counter
					if (npc.ai[2] > 0f) // if aiming: adjust aim and fire if needed
					{
						npc.TargetClosest(true); // target and face closest player
						if (npc.localAI[0] == (float)(shotRate / 2))  //  fire at halfway through; first half of delay is aim, 2nd half is cooldown
						{
							int proj = Projectile.NewProjectile(npc.Center.X, npc.Center.Y, angle.X, angle.Y, shotType, shotPow, 0f, Main.myPlayer,-1);
							Main.projectile[proj].netUpdate = true;
							if (Math.Abs(angle.Y) > Math.Abs(angle.X) * 2f) // target steeply above/below NPC
							{
								if (angle.Y > 0f)
									{npc.ai[2] = 1f;} // aim downward
								else
									{npc.ai[2] = 5f;} // aim upward
							}
							else if (Math.Abs(angle.X) > Math.Abs(angle.Y) * 2f) // target on level with NPC
								{npc.ai[2] = 3f;}  //  aim straight ahead
							else if (angle.Y > 0f) // target is below NPC
								{npc.ai[2] = 2f;}  //  aim slight downward
							else // target is not below NPC
								{npc.ai[2] = 4f;}  //  aim slight upward
						} // END firing
						if (npc.velocity.Y != 0f || npc.localAI[0] <= 0f) // jump/fall or firing reload
						{
							npc.ai[2] = 0f; // not aiming
							npc.localAI[0] = 0f; // reset firing/reload counter (necessary? nonzero maybe)
						}
						else // no jump/fall and no firing reload
						{
							npc.velocity.X *= 0.9f; // decelerate to stop & shoot
							npc.spriteDirection = npc.direction; // match animation to facing
						}
					} // END if aiming: adjust aim and fire if needed
					if (npc.ai[2] <= 0f && npc.velocity.Y == 0f && npc.localAI[0] <= 0f && !Main.player[npc.target].dead && Collision.CanHit(npc.position, npc.width, npc.height, Main.player[npc.target].position, Main.player[npc.target].width, Main.player[npc.target].height) && distance < 700f)
					{
						npc.netUpdate = true;
						npc.velocity.X *= 0.5f;
						npc.ai[2] = 3f;
						npc.localAI[0] = (float)shotRate;
					} // END start aiming
				} // END not confused
			}
			bool standingOnSolid = false;
			if (npc.velocity.Y == 0f) // no jump/fall
			{
				int yBelow = (int)(npc.position.Y + (float)npc.height + 7f) / 16;
				int xLeft = (int)npc.position.X / 16;
				int xRight = (int)(npc.position.X + (float)npc.width) / 16;
				for (int l = xLeft; l <= xRight; l++) // check every block under feet
				{
					if (Main.tile[l, yBelow] == null) // null tile means ??
						return;

					if (Main.tile[l, yBelow].nactive() && Main.tileSolid[(int)Main.tile[l, yBelow].type]) // tile exists and is solid
					{
						standingOnSolid = true;
						break; // one is enough so stop checking
					}
				} // END traverse blocks under feet
			} // END no jump/fall
			if (npc.velocity.Y >= 0f)
			{
				int offset = 0;
				if (npc.velocity.X < 0f) offset = -1;
				if (npc.velocity.X > 0f) offset = 1;
				Vector2 pos = npc.position;
				pos.X += npc.velocity.X;
				int tileX = (int)((pos.X + (float)(npc.width / 2) + (float)((npc.width / 2 + 1) * offset)) / 16f);
				int tileY = (int)((pos.Y + (float)npc.height - 1f) / 16f);
				if (Main.tile[tileX, tileY] == null) Main.tile[tileX, tileY] = new Tile();
				if (Main.tile[tileX, tileY - 1] == null) Main.tile[tileX, tileY - 1] = new Tile();
				if (Main.tile[tileX, tileY - 2] == null) Main.tile[tileX, tileY - 2] = new Tile();
				if (Main.tile[tileX, tileY - 3] == null) Main.tile[tileX, tileY - 3] = new Tile();
				if (Main.tile[tileX, tileY + 1] == null) Main.tile[tileX, tileY + 1] = new Tile();
				if (Main.tile[tileX - offset, tileY - 3] == null) Main.tile[tileX - offset, tileY - 3] = new Tile();
				if ((float)(tileX * 16) < pos.X + (float)npc.width && (float)(tileX * 16 + 16) > pos.X && ((Main.tile[tileX, tileY].nactive() && !Main.tile[tileX, tileY].topSlope() && !Main.tile[tileX, tileY - 1].topSlope() && Main.tileSolid[(int)Main.tile[tileX, tileY].type] && !Main.tileSolidTop[(int)Main.tile[tileX, tileY].type]) || (Main.tile[tileX, tileY - 1].halfBrick() && Main.tile[tileX, tileY - 1].nactive())) && (!Main.tile[tileX, tileY - 1].nactive() || !Main.tileSolid[(int)Main.tile[tileX, tileY - 1].type] || Main.tileSolidTop[(int)Main.tile[tileX, tileY - 1].type] || (Main.tile[tileX, tileY - 1].halfBrick() && (!Main.tile[tileX, tileY - 4].nactive() || !Main.tileSolid[(int)Main.tile[tileX, tileY - 4].type] || Main.tileSolidTop[(int)Main.tile[tileX, tileY - 4].type]))) && (!Main.tile[tileX, tileY - 2].nactive() || !Main.tileSolid[(int)Main.tile[tileX, tileY - 2].type] || Main.tileSolidTop[(int)Main.tile[tileX, tileY - 2].type]) && (!Main.tile[tileX, tileY - 3].nactive() || !Main.tileSolid[(int)Main.tile[tileX, tileY - 3].type] || Main.tileSolidTop[(int)Main.tile[tileX, tileY - 3].type]) && (!Main.tile[tileX - offset, tileY - 3].nactive() || !Main.tileSolid[(int)Main.tile[tileX - offset, tileY - 3].type]))
				{
					float tileWorldY = (float)(tileY * 16);
					if (Main.tile[tileX, tileY].halfBrick())
						{tileWorldY += 8f;}
					if (Main.tile[tileX, tileY - 1].halfBrick())
						{tileWorldY -= 8f;}
					if (tileWorldY < pos.Y + (float)npc.height)
					{
						float tileWorldYHeight = pos.Y + (float)npc.height - tileWorldY;
						float heightNeeded = 16.1f;
						// if (wallCrawler)
							// heightNeeded += 8f;
						if (tileWorldYHeight <= heightNeeded)
						{
							npc.gfxOffY += npc.position.Y + (float)npc.height - tileWorldY;
							npc.position.Y = tileWorldY - (float)npc.height;
							npc.stepSpeed = (double)tileWorldYHeight >= 9.0 ? 2f : 1f;
						}
					}
				}
			}
			if (standingOnSolid)  //  if standing on solid tile
			{
				int x2 = (int)((npc.position.X + (float)(npc.width / 2) + (float)(15 * npc.direction)) / 16f); // 15 pix in front of center of mass
				int y2 = (int)((npc.position.Y + (float)npc.height - 15f) / 16f); // 15 pix above feet
				if (leapReq > 1)
					{x2 = (int)((npc.position.X + (float)(npc.width / 2) + (float)((npc.width / 2 + 16) * npc.direction)) / 16f);} // 16 pix in front of edge
				if (Main.tile[x2, y2] == null)
					Main.tile[x2, y2] = new Tile();
				if (Main.tile[x2, y2 - 1] == null)
					Main.tile[x2, y2 - 1] = new Tile();
				if (Main.tile[x2, y2 - 2] == null)
					Main.tile[x2, y2 - 2] = new Tile();
				if (Main.tile[x2, y2 - 3] == null)
					Main.tile[x2, y2 - 3] = new Tile();
				if (Main.tile[x2, y2 + 1] == null)
					Main.tile[x2, y2 + 1] = new Tile();
				if (Main.tile[x2 + npc.direction, y2 - 1] == null)
					Main.tile[x2 + npc.direction, y2 - 1] = new Tile();
				if (Main.tile[x2 + npc.direction, y2 + 1] == null)
					Main.tile[x2 + npc.direction, y2 + 1] = new Tile();
				Main.tile[x2, y2 + 1].halfBrick();
				if (Main.tile[x2, y2 - 1].nactive() && (Main.tile[x2, y2 - 1].type == 10 || Main.tile[x2, y2 - 1].type == 388) && knockPower != 0)
				{
					npc.localAI[2] += 1f; // inc knock countdown
					npc.ai[3] = 0f; // not bored if working on breaking a door
					if (npc.localAI[2] >= 60f)  //  knock once per second
					{
						npc.velocity.X = 0.5f * (float)(-(float)npc.direction); //  slight recoil from hitting it
						npc.localAI[1] += Math.Abs(knockPower);  //  increase door damage counter
						npc.localAI[2] = 0f;  //  knock finished; start next knock
						bool doorBuster = false;  //  door break flag
						if (npc.localAI[1] >= 10f)  //  at 10 damage, set door as breaking (and cap at 10)
						{
							doorBuster = true;
							npc.localAI[1] = 10f;
						}
						WorldGen.KillTile(x2, y2 - 1, true, false, false);  //  knock sound
						if ((Main.netMode != 1 || !doorBuster) && doorBuster && Main.netMode != 1)  //  server and door breaking
						{
							if (knockPower < 0)  //  breaks doors rather than attempt to open
							{
								WorldGen.KillTile(x2, y2 - 1, false, false, false);  //  kill door
								if (Main.netMode == 2) // server
									NetMessage.SendData(17, -1, -1, null, 0, (float)x2, (float)(y2 - 1), 0f, 0); // ?? tile breaking and/or item drop probably
							}
							else  //  try to open without breaking
							{
								if (Main.tile[x2, y2 - 1].type == 10)
								{
									bool openDoor = WorldGen.OpenDoor(x2, y2 - 1, npc.direction);
									if (!openDoor)  //  door not opened successfully
									{
										npc.ai[3] = (float)boredom;  //  bored if door is stuck
										npc.netUpdate = true;
										// npc.velocity.X = 0; // cancel recoil so boredom wall reflection can trigger
									}
									if (Main.netMode == 2 && openDoor) // is server & door was just opened
										NetMessage.SendData(19, -1, -1, null, 0, (float)x2, (float)(y2 - 1), (float)npc.direction, 0, 0, 0);
								}
								if (Main.tile[x2, y2 - 1].type == 388)
								{
									bool openDoor = WorldGen.ShiftTallGate(x2, y2 - 1, false);  //  open the door
									if (!openDoor)
									{
										npc.ai[3] = (float)boredom;
										npc.netUpdate = true;
									}
									if (Main.netMode == 2 && openDoor)
										NetMessage.SendData(19, -1, -1, null, 4, (float)x2, (float)(y2 - 1), 0f, 0, 0, 0);
								}
							}
						}  //  END server and door breaking
					} // END knock on door
				} // END trying to break door
				else // standing on solid tile but not in front of a passable door
				{
					if ((npc.velocity.X < 0f && npc.spriteDirection == -1) || (npc.velocity.X > 0f && npc.spriteDirection == 1))
					{  //  moving forward
						if (npc.height >= 32 && Main.tile[x2, y2 - 2].nactive() && Main.tileSolid[(int)Main.tile[x2, y2 - 2].type])
						{ // 3 blocks above ground level(head height) blocked
							if (Main.tile[x2, y2 - 3].nactive() && Main.tileSolid[(int)Main.tile[x2, y2 - 3].type])
							{ // 4 blocks above ground level(over head) blocked
								npc.velocity.Y = -8f; // jump with power 8 (for 4 block steps)
								npc.netUpdate = true;
							}
							else
							{
								npc.velocity.Y = -7f; // jump with power 7 (for 3 block steps)
								npc.netUpdate = true;
							}
						} // for everything else, head height clear:
						else if (Main.tile[x2, y2 - 1].nactive() && Main.tileSolid[(int)Main.tile[x2, y2 - 1].type])
						{ // 2 blocks above ground level(mid body height) blocked
							npc.velocity.Y = -6f; // jump with power 6 (for 2 block steps)
							npc.netUpdate = true;
						}
						else if(npc.position.Y + (float)npc.height - (float)(y2 * 16) > 20f && Main.tile[x2, y2].nactive() && !Main.tile[x2, y2].topSlope() && Main.tileSolid[(int)Main.tile[x2, y2].type])
						{ // 1 block above ground level(foot height) blocked
							npc.velocity.Y = -5f; // jump with power 5 (for 1 block steps)
							npc.netUpdate = true;
						}
						else if (leapReq > -1 && npc.directionY < 0 &&  (!Main.tile[x2, y2 + 1].nactive() || !Main.tileSolid[(int)Main.tile[x2, y2 + 1].type]) && (!Main.tile[x2 + npc.direction, y2 + 1].nactive() || !Main.tileSolid[(int)Main.tile[x2 + npc.direction, y2 + 1].type]))
						{ // rising? & jumps gaps & no solid tile ahead to step on for 2 spaces in front
							npc.velocity.Y = -8f; // jump with power 8
							npc.velocity.X *= 1.5f; // jump forward hard as well; we're trying to jump a gap
							npc.netUpdate = true;
						}
						else if (knockPower != 0) // standing on solid tile but not in front of a passable door, moving forward, didnt jump.  I assume recoil from hitting door is too small to move passable door out of range and trigger this
						{
							npc.localAI[1] = 0f;  //  reset door dmg counter
							npc.localAI[2] = 0f;  //  reset knock counter
						}
						if (npc.velocity.Y == 0f && !npc.justHit && npc.ai[3] == 1f)
							{npc.velocity.Y = -5f;}
					} // END moving forward, still: standing on solid tile but not in front of a passable door
					if (leapReq > 1 && npc.velocity.Y == 0f && Math.Abs(npc.Center.X - Main.player[npc.target].Center.X) < leapRangeX && Math.Abs(npc.Center.Y - Main.player[npc.target].Center.Y) < leapRangeY && (float)npc.direction*npc.velocity.X >= leapReq)
					{ // type that leaper & no jump/fall & near target & moving forward fast enough: hop code
						npc.velocity.X *= 2f; // burst forward
						if ((float)npc.direction*npc.velocity.X > leapSpeed) // but cap at leapSpeed
							{npc.velocity.X = (float)npc.direction*leapSpeed;}
						npc.velocity.Y = -leapHeight; // and jump of course
						npc.netUpdate = true;
					}
				}
			}
			else if (knockPower != 0)  //  not standing on a solid tile & can open/break doors
			{
				npc.localAI[1] = 0f;  //  reset door damage counter
				npc.localAI[2] = 0f;  //  reset knock counter
			}
        }
	}
}