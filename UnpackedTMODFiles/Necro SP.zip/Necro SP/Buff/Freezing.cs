public static void Effects(Player player) 
{
	player.controlUp = false;
	player.controlDown = false;
	player.controlLeft = false;
	player.controlRight = false;
	player.controlJump = false;
	player.noItems = true;
}

