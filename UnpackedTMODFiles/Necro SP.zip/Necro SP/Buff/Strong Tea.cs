public static void Effects(Player player) {
	player.statDefense += 15;
	player.meleeDamage += 0.20f;
	player.magicDamage += 0.20f;
	player.rangedDamage += 0.20f;
}