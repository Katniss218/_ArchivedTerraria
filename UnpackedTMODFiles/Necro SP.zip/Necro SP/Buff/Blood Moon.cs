public static void Effects(Player player, int buffIndex, int buffType, int buffTime) {
	Main.bloodMoon = true;
	player.enemySpawns = true;
}