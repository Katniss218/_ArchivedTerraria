public static void Effects(Player player, int buffIndex, int buffType, int buffTime) {
	player.magicCrit += 10;
	player.rangedCrit += 10;
	player.meleeCrit += 10;
}