public void Effects(Player player) {
    player.fireWalk = true;
	player.jumpBoost = true;
	if (player.controlLeft)
	{
		if (player.velocity.X > -4) player.velocity.X -= 0.25f;
		if (player.velocity.X < -4 && player.velocity.X > -8)
		{
			player.velocity.X -= 0.25f;
		}
	}
	if (player.controlRight)
	{
		if (player.velocity.X < 4) player.velocity.X += 0.25f;
		if (player.velocity.X > 4 && player.velocity.X < 8)
		{
			player.velocity.X += 0.25f;
		}
	}
	if (player.velocity.X > 4 || player.velocity.X < -4)
	{
	int i2 = (int)(player.position.X + (float)(player.width / 2) + (float)(8 * player.direction)) / 16;
	int j2 = (int)(player.position.Y + 2f) / 16;
	}
}
