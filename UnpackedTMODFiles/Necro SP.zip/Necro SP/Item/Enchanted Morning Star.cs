
public static void UseItem(Player player, int playerID) {


player.inventory[player.selectedItem].noMelee = true;

player.inventory[player.selectedItem].noMelee = false;
}
