public void Effects(Player player)
{
    player.statDefense += 8;
    player.noFallDmg = true;
}