public static void Effects(Player player) {
    player.lavaImmune=true;
	player.moveSpeed += 20;
	player.waterWalk=true;
}