public static void SetBonus(Player player) {
	player.setBonus = "+5% Magic Damage, +10% movement speed";
    player.magicDamage += 0.05f;
    player.moveSpeed += 0.10f;
   
}


