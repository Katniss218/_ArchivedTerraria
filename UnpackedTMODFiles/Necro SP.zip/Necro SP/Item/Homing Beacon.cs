public void UseItem(Player player, int playerID) { 
    NPC.NewNPC((int)player.position.X,(int)player.position.Y,"Plutarian Transporter",0);
}
