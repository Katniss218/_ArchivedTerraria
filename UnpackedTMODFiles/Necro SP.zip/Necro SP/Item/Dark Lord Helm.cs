public static void Effects(Player player) {
    player.magicDamage += 0.5f;
    player.magicCrit += 5;
    player.meleeDamage += 0.10f;
    player.meleeCrit += 10;
	player.rangedDamage += 0.15f;
    player.rangedCrit += 10;
}