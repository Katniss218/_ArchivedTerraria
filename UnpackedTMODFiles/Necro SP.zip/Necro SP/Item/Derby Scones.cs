public void UseItem(Player player, int playerID) {
	player.AddBuff("Critical Mind", 7200, true);
}