public void UseItem(Player player, int playerID) {
	player.AddBuff("Super Speed", 7200, true);
}