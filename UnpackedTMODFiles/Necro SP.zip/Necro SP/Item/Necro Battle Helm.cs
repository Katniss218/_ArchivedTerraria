public static void Effects(Player player) {
    player.meleeDamage += 0.5f;
    player.rangedDamage += 0.5f;
}