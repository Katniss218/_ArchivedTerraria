public static void Effects(Player player) {
	player.moveSpeed += 5;
	player.waterWalk=true;
}