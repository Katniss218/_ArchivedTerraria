public void UseItem(Player player, int playerID) { 
    NPC.NewNPC((int)player.position.X,(int)player.position.Y,"Frost King",0);
    NPC.NewNPC((int)player.position.X,(int)player.position.Y,"Frost King Right Arm",0);
    NPC.NewNPC((int)player.position.X,(int)player.position.Y,"Frost King Left Arm",0);
}

