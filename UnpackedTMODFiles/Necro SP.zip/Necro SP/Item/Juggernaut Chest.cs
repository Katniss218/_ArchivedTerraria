public static void SetBonus(Player player) {
	player.setBonus = "Ranged Dam +10% and Ranged Crit +8%";
	player.rangedDamage += 0.10f;
    player.rangedCrit += 8;
}
