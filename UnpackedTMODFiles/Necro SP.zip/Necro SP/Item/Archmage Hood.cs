public static void Effects(Player player) {
    player.magicDamage += 0.5f;
    player.magicCrit += 5;
}