public static void SetBonus(Player player) {
	player.setBonus = "+25% all Crit Stats";
	player.meleeCrit +=25;
	player.rangedCrit +=25;
    player.magicCrit +=25;
}

