public static void SetBonus(Player player) {
	player.setBonus = "+10 defense";
	player.statDefense += 10;
    player.moveSpeed -= 0.50f;
}
