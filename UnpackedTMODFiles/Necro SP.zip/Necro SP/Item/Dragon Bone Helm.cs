public static void Effects(Player player) {
	player.rangedDamage += 0.15f;
    player.rangedCrit += 10;
}