public void UseItem(Player player, int playerID){

NPC.NewNPC((int)Main.player[Main.myPlayer].position.X, (int)Main.player[Main.myPlayer].position.Y-300, Config.npcDefs.byName["Chinchilla Pet"].type, 0);



}