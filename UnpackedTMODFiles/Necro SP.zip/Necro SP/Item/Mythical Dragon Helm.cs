public static void Effects(Player player) {
    player.thorns = true; //player.AddBuff(14,100,false);
}
