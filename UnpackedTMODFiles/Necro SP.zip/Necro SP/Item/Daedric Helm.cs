public static void Effects(Player player) {
    player.meleeDamage += 0.10f;
    player.meleeCrit += 10;
}