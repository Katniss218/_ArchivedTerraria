public static void Effects(Player player) 
{
    player.noKnockback = true;
    player.noFallDmg = true;
    player.fireWalk = true;
}
