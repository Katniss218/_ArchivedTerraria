public static void Effects(Player player) {
    player.lavaImmune=true;
	player.moveSpeed += 10;
	player.waterWalk=true;
}