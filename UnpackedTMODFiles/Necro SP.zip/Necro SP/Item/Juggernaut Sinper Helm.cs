public static void Effects(Player player) {
	player.rangedDamage += 0.5f;
    player.rangedCrit += 5;
}