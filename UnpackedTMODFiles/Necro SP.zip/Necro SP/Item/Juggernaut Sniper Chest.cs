public static void Effects(Player player) {
	player.rangedDamage += 0.10f;
    player.rangedCrit += 10;
}