public void VanityEffects(Player P)
{
	P.findTreasure = true;
}
public void Effects(Player P)
{
	P.findTreasure = true;
}