public void UseItem(Player P, int PID) {
	if (!ModWorld.WraithInvasion) {
        ModWorld.StartWraithInvasion();
    }
    //else if (ModWorld.WraithInvasion) {
    //    ModWorld.EndWraithInvasion();
    //}
}