public void UpdateItem(int itemindex,ref bool LetUpdate,ref int MovementType,ref int LavaImmunity) 
{
	LavaImmunity = 2;
}