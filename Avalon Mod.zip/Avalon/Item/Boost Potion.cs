public void UseItem(Player player, int playerID) {
	player.AddBuff("Boost", 7200, true);
}