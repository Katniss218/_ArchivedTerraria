public void Effects(Player player) {
	player.gravControl = true;
	player.noFallDmg = true;
}