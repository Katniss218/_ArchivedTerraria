public void Effects(Player player) {
	player.rangedDamage += 0.2f;
	player.magicDamage += 0.2f;
	player.meleeDamage += 0.3f;
	player.meleeSpeed += 0.3f;
	player.statManaMax2 += 200;
}