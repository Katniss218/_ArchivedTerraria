public void UseItem(Player player, int playerID) {
	player.AddBuff("Exploration", 28800, true);
}