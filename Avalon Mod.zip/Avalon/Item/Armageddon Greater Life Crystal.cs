public void UseItem(Player player, int playerID)
{
	if (player.inventory[player.selectedItem].type == Config.itemDefs.byName["Armageddon Greater Life Crystal"].type && player.itemAnimation > 0 && player.itemTime == 0)
	{
		if (player.statLifeMax == 640)
		{
			player.statLifeMax += 60;
			player.statLife += 60;
		}
		if (Main.myPlayer == player.whoAmi)
		{
			player.HealEffect(60);
		}
	}
}
public bool CanUse(Player player, int pID)
{
	return (player.statLifeMax == 640);
	/*if (player.statLifeMax > 600 || player.statLifeMax < 600)
	{
		return false;
	}
	else return true;*/
}