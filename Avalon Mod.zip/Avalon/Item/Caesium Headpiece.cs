public void Effects(Player player) {
	player.pickSpeed += 0.12f;
	player.meleeSpeed += 0.12f;
	player.meleeDamage += 0.2f;
}