public void Effects(Player player) {
	player.rangedDamage += 0.05f;
	player.manaCost -= 0.05f;
}