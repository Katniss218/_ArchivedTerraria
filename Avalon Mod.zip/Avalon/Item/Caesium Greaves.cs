public void Effects(Player player) {
	player.magicDamage += 0.1f;
	player.rangedDamage += 0.1f;
	player.moveSpeed += 0.2f;
	player.doubleJump = true;
	player.statManaMax2 += 80;
}