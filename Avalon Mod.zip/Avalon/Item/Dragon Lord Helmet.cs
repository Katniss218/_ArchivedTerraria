public void Effects(Player player) {
	player.meleeDamage += 0.25f;
	player.rangedDamage += 0.25f;
	player.meleeCrit += 5;
	player.magicCrit += 5;
	player.rangedCrit += 5;
}