public void UseItem(Player player, int playerID) {
	player.AddBuff("Bee Sweet", 7200, true);
}