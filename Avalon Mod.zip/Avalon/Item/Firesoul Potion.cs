public static void UseItem(Player player, int playerID)
{
	player.AddBuff("Firesoul", 14400, false);
}