public void Effects(Player player) {
	player.moveSpeed += 0.15f;
	player.doubleJump = true;
	player.starCloak = true;
}