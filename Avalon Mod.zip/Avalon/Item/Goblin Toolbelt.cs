public void Effects(Player P)
{
	P.accWatch = 3;
	P.accCompass = 1;
	P.accDepthMeter = 1;
	P.blockRange += 2;
}