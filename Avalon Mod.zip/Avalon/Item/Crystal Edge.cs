public void DamageNPC(Player P,NPC N, ref int dmg, ref float kb)
{
	N.life -= 15;
	if (N.life < 1)
	{
		N.NPCLoot();
		N.checkDead();
		N.active = false;
	}
}