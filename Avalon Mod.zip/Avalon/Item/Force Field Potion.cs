public void UseItem(Player player, int playerID) {
	player.AddBuff("Force Field", 18000, true);
}