public void Effects(Player player) {
	player.manaCost -= 0.15f;
	player.magicDamage += 0.2f;
	//if (player.inventory[player.selectedItem].ranged)
	//{
	//	player.inventory[player.selectedItem].shootSpeed *= 1.15f;
	//}
}