public void Effects(Player player) {
	player.meleeDamage += 0.05f;
}