public static void Effects(Player player)
{
	player.lifeRegenTime = 0;
	player.lifeRegen = -5;
}
public static void NPCEffects(NPC N)
{
	N.lifeRegen = -6;
}

