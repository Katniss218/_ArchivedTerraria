public void Effects(Player player, int buffIndex, int buffType, int buffTime) {
	player.accDepthMeter = 1;
	player.accCompass = 1;
	player.accWatch = 3;
}