public void Effects(Player player) {
	player.immune = true;
}