public static void Effects(Player player)
{
	player.lifeRegenTime = 0;
	player.lifeRegen = 6;
}

