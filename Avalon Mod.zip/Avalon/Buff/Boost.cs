public void Effects(Player player, int buffIndex, int buffType, int buffTime) {
	player.magicCrit += 5;
	player.rangedCrit += 5;
	player.meleeCrit += 5;
}