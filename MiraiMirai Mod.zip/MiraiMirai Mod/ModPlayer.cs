using System;
using System.Collections.Generic;
using System.Text;

using Terraria;
using TAPI;

namespace Nymphaea.FutureDance {
    public class ModPlayer : TAPI.ModPlayer {
        
        public static List<int> spaceWeaponry = new List<int>(new int[] {
            /*Star Cannon*/ 197, /*Phasesabers*/ 198, 199, 200, 201, 202, 203, /*Laser Rifle*/ 514, /*Heat Ray*/ 1295
        });
        public static Item spacebattery;
        
        public override void Initialize() {
            // Get Space Battery reference
            spacebattery = ItemDef.byName["Nymphaea.FutureDance:batterySpace"];
            // Add Space Weapons
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberBlue"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberGreen"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberPurple"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberRed"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberWhite"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberYellow"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberBlue"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberGreen"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberPurple"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberRed"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberWhite"].type);
            spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberYellow"].type);
        }
        
        public override void MidUpdate() {
            // If Holding a Space Battery, apply effects
            for (int l=54;l<58;l++) {
                Item ammo = player.inventory[l];
                if(ammo.ammo == spacebattery.ammo) {
                    player.spaceGun = true;
                    
                    // Hallowed Space Battery effects
                    if(ammo.type != spacebattery.type) {
                        player.statLifeMax2 += 25;
                        player.statManaMax2 += 25;
                        // Melee
                        player.meleeDamage *= 1.05f;
                        player.meleeCrit += 5;
                        // Ranged
                        player.rangedDamage *= 1.05f;
                        player.rangedCrit += 5;
                        // Magic
                        player.magicDamage *= 1.03f;
                        player.magicCrit += 3;
                        player.manaCost -= 0.125f;
                        if(player.manaCost < 0f) {
                            player.manaCost = 0f;
                        }
                    }
                    
                    // Space Weaponry bonus
                    if(spaceWeaponry.Contains(player.heldItem.type)) {
                        if(player.heldItem.melee) {
                            // Increased melee damage and crit
                            player.meleeDamage *= 1.05f;
                            player.meleeCrit += 5;
                        } else if(player.heldItem.ranged) {
                            // Increased ranged damage and crit
                            player.rangedDamage *= 1.05f;
                            player.rangedCrit += 5;
                        } else if(player.heldItem.magic) {
                            // Increased magic damage and crit
                            player.magicDamage *= 1.03f;
                            player.magicCrit += 3;
                            // Decreased mana cost for magic weapons
                            player.manaCost -= 0.125f;
                            if(player.manaCost < 0f) {
                                player.manaCost = 0f;
                            }
                        }
                    }
                }
            }
        }
        
    }
}