using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;

using Terraria;
using TAPI;

namespace Nymphaea.FutureDance.Tiles {
    public class crucible : ModTileType {
        
        public override void ModifyLight(int x, int y, ref float r, ref float g, ref float b) {
            // Add Light
            //Lighting.AddLight(x, y, 0.83f, 0.6f, 0.5f);
            r = 0.83f;
            g = 0.6f;
            b = 0.5f;
            
            // Add Dust
            if (Main.tile[x, y].frameX == 18 && Main.tile[x, y].frameY == 36 && Main.rand.Next(20) == 0) {
                int dust = Dust.NewDust(new Vector2((float)(x * 16 + 4), (float)(y * 16 + 2)), 8, 6, 6, 0f, 0f, 100);
                if (Main.rand.Next(3) != 0) {
                    Main.dust[dust].noGravity = true;
                }
            }
        }
        
    }
}