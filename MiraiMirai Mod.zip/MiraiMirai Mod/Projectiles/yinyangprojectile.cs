using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;

using Terraria;
using TAPI;

namespace Nymphaea.FutureDance.Projectiles {
    public class yinyangprojectile : ModProjectile {
        
        public override void PostAI() {
            // Dust
            if(Main.netMode != 2 && ((int)Main.time & 1) > 0) {
                float speedX = projectile.velocity.X * (float)Main.rand.Next(5) * 0.2f;
                float speedY = projectile.velocity.Y * (float)Main.rand.Next(5) * 0.2f;
                int i = Dust.NewDust(projectile.position,projectile.width,projectile.height,31,speedX,speedY,80,default(Color),1.2f);
                Main.dust[i].noGravity = true;
                int j = Dust.NewDust(projectile.position,projectile.width,projectile.height,54,speedX,speedY,80,default(Color),1.2f);
                Main.dust[j].noGravity = true;
            }
            
            foreach (Item i in Main.item) {
                if (i.active && projectile.DistanceSQ(i.Centre) < 400) {
                    i.Centre = projectile.Centre;
                }
            }
        }
        
    }
}