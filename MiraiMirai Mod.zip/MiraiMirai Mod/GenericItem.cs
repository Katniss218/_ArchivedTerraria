using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;

using LitJson;
using Terraria;
using TAPI;

namespace Nymphaea.FutureDance.Items {
    public class GenericDebuff : ModItem {
        
        private int buff;
        private int time;
        
        public override void Initialize() {
            buff = (int) item.def.json["debuff"];
            time = (int) item.def.json["debuffTime"];
        }
        
        public override void DealtPVP(Player owner, Player p, int hitDir, int dmgDealt, bool crit) {
            p.AddBuff(buff, time, false);
        }
        
        public override void DealtNPC(Player owner, NPC npc, int hitDir, int dmgDealt, float knockback, bool crit) {
            npc.AddBuff(buff, time, false);
        }
        
    }
    
    public class GenericDebuffGlowing : GenericDebuff {
        
        private float R, G, B;
        
        public override void Initialize() {
            base.Initialize();
            JsonData glow = item.def.json["glow"];
            R = (float) glow[0];
            G = (float) glow[1];
            B = (float) glow[2];
        }
        
        public override void UseItemEffects(Player p, Rectangle rect) {
            Lighting.AddLight((int)((p.itemLocation.X + 6f + p.velocity.X) / 16f), (int)((p.itemLocation.Y - 14f) / 16f), R, G, B);
        }
        
    }

    public class GenericBoomerang : ModItem {
        
        public override bool CanUse(Player player) {
            for(int l = 0; l < Main.projectile.Length; l++) {
                Projectile proj = Main.projectile[l];
                if(proj.active && proj.owner == player.whoAmI && proj.type == item.shoot) {
                    return false;
                }
            }
            return true;
        }
        
    }
    
    public class GenericGun : ModItem {
        
        private int barrelCount = 1;
        private int barrelSpace;
        private int shootSound = -1;
        private int spread = 0;
        private int ammoChance = 0;
        
        private int barrel = 0;
        
        public override void Initialize() {
            if (item.def.json.Has("barrelCount")) {
                barrelCount = (int) item.def.json["barrelCount"];
                barrelSpace = (int) item.def.json["barrelSpace"];
            }
            if (item.def.json.Has("shootSound")) {
                shootSound = (int) item.def.json["shootSound"];
            }
            if (item.def.json.Has("spread")) {
                spread = (int) item.def.json["spread"];
            }
            if (item.def.json.Has("ammoChance")) {
                ammoChance = (int) item.def.json["ammoChance"];
            }
        }
        
        public override bool PreShoot(Player p, Vector2 pos, Vector2 speed, int type, int damage, float knockback) {
            Vector2 normal = new Vector2(-speed.Y, speed.X);
            normal.Normalize();
            
            // Spread
            speed += normal * (0.1f * Main.rand.Next(-spread, spread));
            
            // Barrel Offset
            if (barrelCount > 1) {
                normal *= barrelSpace;
                pos -= normal * ((float)(barrelCount - 1) / 2f);
                pos += normal * barrel;
                barrel++;
                if (barrel >= barrelCount) {
                    barrel = 0;
                }
            }
            
            // Fire Gun
            //Projectile.NewProjectile(pos, speed, type, damage, knockback, p.whoAmI);
            Projectile.NewProjectile(pos.X, pos.Y, speed.X, speed.Y, type, damage, knockback, p.whoAmI);
            if (shootSound >= 0) {
                Main.PlaySound(Main.soundItem[shootSound], (int)p.position.X, (int)p.position.Y, true, null, Single.NaN, 0.5f, Single.NaN);
            }
            
            return false;
        }
        
        public override bool ConsumeAmmo(Player p) {
            return !(ammoChance > 0 && Main.rand.Next(ammoChance) == 0);
        }
        
    }
}