using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;

using Terraria;
using TAPI;

namespace Nymphaea.FutureDance.Items {
    public class rubberMallet : ModItem {
        
        public override void DealtPVP(Player owner, Player p, int hitDir, int dmgDealt, bool crit) {
            p.velocity = new Vector2(hitDir * 12, -4);
        }
        
        public override void DealtNPC(Player owner, NPC npc, int hitDir, int dmgDealt, float knockback, bool crit) {
            npc.velocity = new Vector2(hitDir * 12, -4);
        }
        
    }
}