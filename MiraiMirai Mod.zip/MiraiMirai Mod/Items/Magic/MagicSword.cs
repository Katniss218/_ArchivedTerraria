using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;

using LitJson;
using Terraria;
using TAPI;

namespace Nymphaea.FutureDance.Items {
    public class MagicSword : ModItem {
        
        public override void DamagePVP(Player owner, Player p, int hitDir, ref int damage, ref bool crit, ref float critMult) {
            damage += p.statDefense/2;
        }
        
        public override void DamageNPC(Player owner, NPC npc, int hitDir, ref int damage, ref float knockback, ref bool crit, ref float critMult) {
            damage += npc.defense/2;
        }
        
    }
}