using System;
using System.Collections.Generic;
using System.Text;

using Terraria;
using TAPI;

namespace Nymphaea.FutureDance {
    public class ModBase : TAPI.ModBase {
    
        public override void OnAllModsLoaded() {
            // Vanilla item recipes
            AddRecipes();
            
            // Replace vanilla Timer textures
            if(!Main.dedServ) {
                Main.tileTexture[144] = textures["Vanilla/Tile_Timers"];
                Main.itemTexture[583] = textures["Vanilla/Item_Timer_1"];
                Main.itemTexture[584] = textures["Vanilla/Item_Timer_3"];
                Main.itemTexture[585] = textures["Vanilla/Item_Timer_5"];
            }
            
            // Get Space Battery reference
            ModPlayer.spacebattery = ItemDef.byName["Nymphaea.FutureDance:batterySpace"];
            
            // Add Space weapons
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberBlue"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberGreen"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberPurple"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberRed"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberWhite"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:blazesaberYellow"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberBlue"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberGreen"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberPurple"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberRed"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberWhite"].type);
            ModPlayer.spaceWeaponry.Add(ItemDef.byName["Nymphaea.FutureDance:glazesaberYellow"].type);
        }
        
        private void AddRecipes() {
            int index = 0;
            int scan;
            
            // Torch
            scan = /*Torch*/8;
            while (index < Main.recipe.Count) {
                if (Main.recipe[index++].createItem.type == scan) {
                    break;
                }
            }
            Recipe.newRecipe.createItem.SetDefaults(/*Torch*/8);
            Recipe.newRecipe.createItem.stack = 4;
            Recipe.newRecipe.requiredItem.Add(new Item().SetDefaults("Nymphaea.FutureDance:charcoal"));
            Recipe.newRecipe.requiredItem.Add(new Item().SetDefaults("g:Wood"));
            Recipe.InsertRecipe(index);
            
            // Extractinator
            scan = ItemDef.byName["Nymphaea.FutureDance:crushinator"].type;
            while (index < Main.recipe.Count) {
                if (Main.recipe[index++].createItem.type == scan) {
                    break;
                }
            }
            Recipe.newRecipe.createItem.SetDefaults(/*Extractinator*/997);
            Recipe.newRecipe.requiredItem.Add(new Item().SetDefaults("g:barSteel"));
            Recipe.newRecipe.requiredItem[0].stack = 50;
            Recipe.newRecipe.requiredItem.Add(new Item().SetDefaults(/*Wire*/530));
            Recipe.newRecipe.requiredItem[1].stack = 50;
            Recipe.newRecipe.requiredItem.Add(new Item().SetDefaults("g:gem"));
            Recipe.newRecipe.requiredItem[2].stack = 20;
            Recipe.InsertRecipe(index);
        }
        
    }
}
