using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;

using LitJson;
using Terraria;
using TAPI;

namespace Nymphaea.FutureDance.Projectiles {
    public class GenericDebuff : ModProjectile {
        
        private int buff;
        private int time;
        
        public override void Initialize() {
            buff = (int) projectile.def.json["debuff"];
            time = (int) projectile.def.json["debuffTime"];
        }
        
        public override void DealtPVP(Player p, int hitDir, int dmgDealt, bool crit) {
            p.AddBuff(buff, time, false);
        }
        
        public override void DealtNPC(NPC npc, int hitDir, int dmgDealt, float knockback, bool crit) {
            npc.AddBuff(buff, time, false);
        }
        
    }
    
    public class GenericDustyDebuff : GenericDebuff {
        
        private int dust;
        private int dustAlpha = 0;
        private float dustScale = 1f;
        
        public override void Initialize() {
            base.Initialize();
            dust = (int) projectile.def.json["dust"];
            if (projectile.def.json.Has("dustAlpha")) {
                dustAlpha = (int) projectile.def.json["dustAlpha"];
            }
            if (projectile.def.json.Has("dustScale")) {
                dustScale = (float) projectile.def.json["dustScale"];
            }
        }
        
        public override void PostAI() {
            float speedX = projectile.velocity.X * (float)Main.rand.Next(5) * 0.2f;
            float speedY = projectile.velocity.Y * (float)Main.rand.Next(5) * 0.2f;
            int i = Dust.NewDust(projectile.position,projectile.width,projectile.height,dust,speedX,speedY,dustAlpha,default(Color),dustScale);
            Main.dust[i].noGravity = true;
        }
        
    }
}