public static void Effects(Player player) 
{
	player.velocity.X = 0f;
	player.velocity.Y = 0f;
}

public static void NPCEffects(NPC npc) 
{
	npc.velocity.X = 0f;
	npc.velocity.Y = 0f;
}