public static void Effects(Player player) {
	player.meleeDamage += 0.20f;
    player.rangedDamage += 0.20f;
    player.magicDamage += 0.20f;
}