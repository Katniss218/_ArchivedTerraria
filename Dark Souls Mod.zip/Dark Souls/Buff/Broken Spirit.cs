public void UpdatePlayer(Player P) 
{ 
	P.noKnockback = false; 
}


//public void Effects(Player P,int buffIndex,int buffType,int buffTime)
//{
//   if(P.HasBuff("Broken Shield") != -1)
//{
//	P.noKnockback=false;
//}
//}

//leaving this here as a memory of my idiocy...