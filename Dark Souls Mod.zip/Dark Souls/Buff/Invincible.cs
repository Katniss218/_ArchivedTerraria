public static void Effects(Player player) 
{
	    player.immune = true;
}