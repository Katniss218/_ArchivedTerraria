public static void Effects(Player player) {
	player.statDefense += 13;
}