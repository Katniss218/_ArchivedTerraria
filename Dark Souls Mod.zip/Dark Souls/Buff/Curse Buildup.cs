//2 is on the server
//1 is on the client
//0 is singleplayer

// int derp = 0;
// int[] derp = new int[255];

//int level = 1;
//int lastrecord=0;

//derp[player.whoAmi] = 1;

int[] level = new int[255];
int[] lastrecord = new int[255];

//public void EffectsStart(Player P,int buffIndex,int buffType,int buffTime) 
//{
//	if (Main.netMode != 2)
//	{
//		lastrecord = buffTime-1;
//	}
//}
//public void Effects(Player P,int buffIndex,int buffType,int buffTime) 
//{
//	if (Main.netMode != 2)
//	{
//		if(lastrecord <= buffTime)
//		{
//			lastrecord = buffTime;
//			if(level < 1000) level++;
//		}

//		Main.buffTip[buffType] = "When the counter reaches 30, something bad happens. Curse buildup is at " + level;
	
//		if(level == 30)
//		{
//			if (P.statLifeMax > 20) 

//			{
//				if(P.whoAmi == Main.myPlayer)
//				{
//					Main.NewText("You have been cursed! -20 HP!");
//				}
//				P.AddBuff("Invincible", 600, false); //Invincible
//				P.AddBuff("Strong", 3600, false); //Strong!
//				P.statLifeMax -= 20;
//				level = 31;
//			}
//		}

//		if(level == 90)
//		{
//				if(P.whoAmi == Main.myPlayer)
//				{
//					Main.NewText("You feel powerful!");
//				}
//				P.AddBuff("Invincible", 600, false); //Invincible
//				P.AddBuff("Strong", 3600, false); //Strong!
 		
//				level = 91;
		
//		}
//	}

//}









//wasn't necessary 
public void EffectsStart(Player P,int buffIndex,int buffType,int buffTime) 
{
	if (Main.netMode != 2)
	{
		lastrecord[P.whoAmi] = buffTime-1;
	}
}
public void Effects(Player P,int buffIndex,int buffType,int buffTime) 
{
	if (Main.netMode != 2)
	{
		if(lastrecord[P.whoAmi] <= buffTime)
		{
			lastrecord[P.whoAmi] = buffTime;
			if(level[P.whoAmi] < 100) level[P.whoAmi]++;
		}

		Main.buffTip[buffType] = "When the counter reaches 50, something bad happens. Curse buildup is at " + level[P.whoAmi];
	
		if(level[P.whoAmi] == 50)
		{
			if (P.statLifeMax > 20) 

			{
				if(P.whoAmi == Main.myPlayer)
				{
					Main.NewText("You have been cursed! -20 HP!");
				
					P.AddBuff("Invincible", 600, false); //Invincible
					P.AddBuff("Strong", 3600, false); //Strong!
					P.statLifeMax -= 20;
					level[P.whoAmi] = 51;
				}
			}
		}

		if(level[P.whoAmi] == 99)
		{
				if(P.whoAmi == Main.myPlayer)
				{
					Main.NewText("You feel powerful!");
				
					P.AddBuff("Invincible", 600, false); //Invincible
					P.AddBuff("Strong", 3600, false); //Strong!
 		
					level[P.whoAmi] = 100;
				}
		
		}
	}

}