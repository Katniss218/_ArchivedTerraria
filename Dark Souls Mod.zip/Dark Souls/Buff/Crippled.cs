public void Effects(Player P,int buffIndex,int buffType,int buffTime)
{
    P.doubleJump = false;
	P.jumpAgain = false;
	P.canRocket = false;
	P.jumpBoost = false;
	P.wingTime = 0;
	//P.jumpHeight = 3f;
	//P.jumpSpeed = 1.5f;
        
}