public void Effects(Player player) {
	player.statDefense += 15;
	player.meleeDamage += 0.15f;
	player.meleeSpeed += 0.15f;
	player.pickSpeed += 0.15f;
	player.magicDamage += 0.15f;
	player.rangedDamage += 0.15f;
	player.meleeCrit += 2;
	player.magicCrit += 2;
	player.rangedCrit += 2;
}