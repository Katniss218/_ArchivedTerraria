/*public void Effects(Player P)
{
	foreach (Projectile Pr in Main.projectile)
	{
		if (Pr.owner == Main.myPlayer)
		{
			if (Pr.penetrate == Config.projDefs[Pr.type].penetrate && Pr.penetrate != -1) Pr.penetrate++;
		}
	}
}*/