public void UseItem(Player player, int playerID) {
	player.AddBuff("Crimson Drain", 18000, true);
}