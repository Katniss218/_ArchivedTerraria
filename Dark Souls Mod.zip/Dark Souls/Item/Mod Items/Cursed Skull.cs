public void UseItem(Player player, int playerID)
{
NPC.SpawnOnPlayer(playerID, "Skeletron Head");
}