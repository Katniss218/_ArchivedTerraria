
public void UseItem(Player player, int playerID)
{  

double num16 = (double)(Main.maxTilesY - 230);
    double num17 = (double)((int)((num16 - Main.worldSurface) / 6.0) * 6);
    num16 = Main.worldSurface + num17 - 5.0;
	bool underworld= (player.position.Y > num16*16);

if(!underworld) { Main.NewText("You can only use this in the Underworld."); }


	if (underworld)
	{ 
		NPC.SpawnOnPlayer(playerID, "The Rage");
	}
return;

}


