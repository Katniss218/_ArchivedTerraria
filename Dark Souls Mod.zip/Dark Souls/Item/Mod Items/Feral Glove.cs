public void Effects(Player player) {
	player.kbGlove = true;
	player.meleeSpeed += 0.15f;
}