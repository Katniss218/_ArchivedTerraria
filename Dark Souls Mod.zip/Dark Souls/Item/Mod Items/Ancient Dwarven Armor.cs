//See here for more player attributes: http://tconfig.wikia.com/wiki/Player_Attributes


public static void SetBonus(Player player) 
{
	
		foreach(Item I in player.armor)
		{
			if(I.type == Config.itemDefs.byName["Ancient Dwarven Helmet"].type)
			{
				player.setBonus = "+4 Defense, +7 Melee Damage, +7 Melee Speed";
				player.statDefense += 4;
				player.meleeDamage += 0.07f;
				player.meleeSpeed += 0.07f;
    
				break;
			}
		
			if(I.type == Config.itemDefs.byName["Ancient Dwarven Helmet II"].type)
			{
				player.setBonus = "+8 Defense, +9 Melee Damage, +9 Melee Speed";
				player.statDefense += 8;
				player.meleeDamage += 0.09f;
				player.meleeSpeed += 0.09f;
    
				break;
			}
		}
	
}

public static void Effects(Player player) {
	
		foreach(Item I in player.armor)
		{
			if(I.type == Config.itemDefs.byName["Ancient Dwarven Helmet"].type)
			{
				if(player.statLife <= 80) {
				player.lifeRegen += 4;

				int dust = Dust.NewDust(new Vector2((float) player.position.X, (float) player.position.Y), player.width, player.height, 21, (player.velocity.X) + (player.direction * 1), player.velocity.Y, 245, Color.Violet, 1.0f);
				 Main.dust[dust].noGravity = true;

				}
				else { player.lifeRegen += 1;
					}
    
				break;
			}
		
			if(I.type == Config.itemDefs.byName["Ancient Dwarven Helmet II"].type)
			{
				if(player.statLife <= 80) {
				player.lifeRegen += 6;

				int dust = Dust.NewDust(new Vector2((float) player.position.X, (float) player.position.Y), player.width, player.height, 21, (player.velocity.X) + (player.direction * 1), player.velocity.Y, 245, Color.Violet, 1.0f);
				 Main.dust[dust].noGravity = true;

				}
				else { player.lifeRegen += 3;
					}
    
				break;
			}
		}
	


}