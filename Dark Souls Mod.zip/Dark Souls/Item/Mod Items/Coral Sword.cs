public void DamageNPC(Player myPlayer,NPC npc, ref int damage, ref float knockback){
    if (npc.name=="Shark") damage *= 4;
    else if (npc.name=="Goldfish") damage *= 4;
    else if (npc.name=="Corrupt Goldfish") damage *= 4;
    else if (npc.name=="Jelly Fish") damage *= 4;
    else if (npc.name=="Piranha") damage *= 4;
    else if (npc.name=="Angler Fish") damage *= 4;
    else if (npc.name=="Shark") damage *= 4;
    else if (npc.name=="Sahagin Chief") damage *= 4;
    else if (npc.name=="Sahagin Prince") damage *= 4;
    else if (npc.name=="Quara Constrictor") damage *= 4;
    else if (npc.name=="Quara Hydromancer") damage *= 4;
    else if (npc.name=="Quara Mantassin") damage *= 4;
    else if (npc.name=="Quara Pincher") damage *= 4;
    else if (npc.name=="Quara Predator") damage *= 4;
}