public static void Effects(Player p) {
	p.meleeDamage += 0.25f;
}