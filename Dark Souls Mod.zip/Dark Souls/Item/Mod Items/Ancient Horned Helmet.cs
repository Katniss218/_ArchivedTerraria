//See here for more player attributes: http://tconfig.wikia.com/wiki/Player_Attributes
public static void Effects(Player player) {
    player.rangedCrit += 5;
    player.meleeCrit += 5;
    player.magicCrit += 5;
}