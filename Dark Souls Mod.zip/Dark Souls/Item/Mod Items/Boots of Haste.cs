public static void Effects(Player player) 
{
    player.moveSpeed += 0.2f;
}