public static void Effects(Player player) {
	
	player.statManaMax2 += 100;
}