//See here for more player attributes: http://tconfig.wikia.com/wiki/Player_Attributes
public static void SetBonus(Player player) {
	player.setBonus = "+6 defense, +10% Move Speed, +5% ranged dmg";
	    player.statDefense += 6;
	    player.moveSpeed += 0.1f;
	    player.rangedDamage += 0.05f;
}