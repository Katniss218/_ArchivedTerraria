public static void Effects(Player player) 
{
    player.noFallDmg = true;
    ModPlayer.dragoonBoots = true;
    //Player.jumpHeight += 5;
    //if (!Main.player[Main.myPlayer].controlDown)
    //{
    //    Player.jumpSpeed += 10f;
    //}
}
