public static void UseItem(Player player, int playerID) 
{
	player.AddBuff("Demon Drug", 10800, false);
}