public static void Effects(Player p) {

	p.rangedDamage += 0.25f;
}