public static void Effects(Player player) 
{
    player.manaCost -= 0.50f;
}