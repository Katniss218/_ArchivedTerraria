
public void UseItem(Player player, int playerID)
{  

bool zoneJ = player.zoneJungle;


	if (zoneJ)
	{ 
		NPC.SpawnOnPlayer(playerID, "The Hunter");

	}

if(!zoneJ) { Main.NewText("You can only use this in the Jungle."); }
return;
}

