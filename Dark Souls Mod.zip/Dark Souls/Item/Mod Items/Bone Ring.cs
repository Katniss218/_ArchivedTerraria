public static void Effects(Player player) 
{
    player.statDefense += 2;
	player.rangedDamage += 0.08f;
	player.rangedCrit += 8;
}