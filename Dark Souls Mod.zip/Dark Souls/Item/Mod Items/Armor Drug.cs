public static void UseItem(Player player, int playerID) 
{
	player.AddBuff("Armor Drug", 10800, false);
}