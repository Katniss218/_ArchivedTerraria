public void UseItem(Player player, int playerID) {
	player.AddBuff("Battlefront", 28800, true);
}