public void UseItem(Player player, int playerID)
{
//Main.NewText("Attraidies Illusion has awakened!", 175, 75, 255);
NPC.SpawnOnPlayer(playerID, "Attraidies Illusion");
}