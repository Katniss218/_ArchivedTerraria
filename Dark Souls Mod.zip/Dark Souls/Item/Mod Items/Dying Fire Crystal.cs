public void UseItem(Player player, int playerID)
{
    NPC.SpawnOnPlayer(playerID, "Fire Fiend Marilith");
}