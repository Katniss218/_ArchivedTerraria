public void UseItem(Player player, int playerID) {
	player.AddBuff("Boost", 14400, true);
}