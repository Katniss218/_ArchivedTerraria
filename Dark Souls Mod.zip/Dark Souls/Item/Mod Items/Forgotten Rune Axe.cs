public void DamageNPC(Player myPlayer,NPC npc, ref int damage, ref float knockback)
{
    if (npc.name=="Tim") damage *= 4;
    else if (npc.name=="Dark Caster") damage *= 4;
    else if (npc.name=="Goblin Sorcerer") damage *= 4;
    else if (npc.name=="Mindflayer King Servant") damage *= 4;
    else if (npc.name=="Piscodemon") damage *= 4;
    else if (npc.name=="Mindflayer King") damage *= 4;
    else if (npc.name=="Warlock") damage *= 4;
    else if (npc.name=="Necromancer") damage *= 4;
    else if (npc.name=="Attraidies Illusion") damage *= 4;
    else if (npc.name=="Disciple of Attraidies") damage *= 4;
    else if (npc.name=="Attraidies Mimic") damage *= 4;
    else if (npc.name=="Attraidies") damage *= 4;
    else if (npc.name=="Dark Elf Mage") damage *= 4;
    else if (npc.name=="Wyvern Mage") damage *= 4;
    else if (npc.name=="Shadow Mage") damage *= 4;
    else if (npc.name=="Dungeon Mage") damage *= 4;
    else if (npc.name=="Artorias") damage *= 4;
    else if (npc.name=="Witchking") damage *= 4;

}