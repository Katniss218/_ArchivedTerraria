public static void Effects(Player player) 
{
        player.magicDamage += 0.05f;
	player.statManaMax2 +=40;
}