//See here for more player attributes: http://tconfig.wikia.com/wiki/Player_Attributes
public static void Effects(Player player) {
    player.meleeSpeed += 0.09f;
   
}

public static void SetBonus(Player player) {
	player.setBonus = "Boosts all critical hits by 6%, +5% melee and ranged damage, +40 mana";
    player.meleeDamage += 0.09f;
	player.rangedDamage += 0.09f;
	player.statManaMax2 += 60;
	player.rangedCrit += 8;
    player.meleeCrit += 8;
    player.magicCrit += 8;
}

