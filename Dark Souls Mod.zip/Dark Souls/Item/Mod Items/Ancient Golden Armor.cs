//See here for more player attributes: http://tconfig.wikia.com/wiki/Player_Attributes
public static void Effects(Player player) {
    player.meleeSpeed += 0.07f;
   
}

public static void SetBonus(Player player) {
	player.setBonus = "Boosts all critical hits by 6%, +5% melee and ranged damage, +40 mana";
    player.meleeDamage += 0.05f;
	player.rangedDamage += 0.05f;
	player.statManaMax2 += 40;
	player.rangedCrit += 6;
    player.meleeCrit += 6;
    player.magicCrit += 6;
}

