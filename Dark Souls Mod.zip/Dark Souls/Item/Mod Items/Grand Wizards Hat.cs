public static void Effects(Player p) {

	p.magicDamage += 0.25f;
	p.statManaMax2 += 100;
}