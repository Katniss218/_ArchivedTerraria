public void Effects(Player player) {
	player.meleeDamage += 0.3f;
	player.rangedDamage += 0.3f;
	player.magicDamage += 0.3f;
	player.statDefense -= 10;
}